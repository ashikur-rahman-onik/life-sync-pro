# আমার ডায়েরি প্লাস — APK বিল্ড ও আপডেট গাইড

## একবারের সেটআপ (ফোন থেকেই করা যায়)
1. GitHub-এ **Public** repository বানান (আপডেট চেকের জন্য Public লাগবে — কোডে কোনো পাসওয়ার্ড নেই, সাইনিং কী থাকে Secrets-এ)।
2. repo-র একদম root-এ `amar-diary-plus.zip` আপলোড করুন (Add file → Upload files)।
3. **Add file → Create new file** → নামের ঘরে লিখুন `.github/workflows/build.yml` → `build.yml` ফাইলের পুরো লেখা পেস্ট করে Commit করুন।
4. **Settings → Secrets and variables → Actions → New repository secret** থেকে `KEYSTORE-SECRETS.txt` ফাইলের ২টি Secret যোগ করুন।
5. **Actions → Build APK → Run workflow** চাপুন। ৫–১০ মিনিট পর **Releases** পেজ থেকে `amar-diary.apk` নামিয়ে প্রথমবার ইনস্টল করুন।

## পরের আপডেট
নতুন zip আপলোড করে (একই নামে replace) commit করুন → APK নিজে বিল্ড হয়ে Release-এ যাবে → ফোনে অ্যাপ খুললে **"নতুন আপডেট পাওয়া গেছে"** দেখাবে → **এখনই আপডেট করুন** চাপুন। আনইনস্টল লাগবে না, ডেটা ঠিক থাকবে।

## জরুরি
- সব বিল্ড একই সাইনিং কী দিয়ে সাইন হয় — তাই আপডেট পুরনো অ্যাপের উপর বসে।
- কী ফাইল/Secret হারাবেন না।
- অ্যাপের ডেটা ফোনেই থাকে। **সেটিংস → ব্যাকআপ** থেকে মাঝে মাঝে ব্যাকআপ নিন।
