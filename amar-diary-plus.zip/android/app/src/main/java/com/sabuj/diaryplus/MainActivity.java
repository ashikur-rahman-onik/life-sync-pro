package com.sabuj.diaryplus;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
