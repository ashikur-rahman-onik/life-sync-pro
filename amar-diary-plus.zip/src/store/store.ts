import { useSyncExternalStore } from "react";
import { todayKey } from "@/lib/date";
import { emptyData } from "@/domain/defaults";
import type { AppData } from "@/domain/types";
import { normalizeData, pruneOld } from "./normalize";

const DATA_KEY = "amar_diary_plus_data_v1";

function loadInitial(): AppData {
  try {
    const raw = localStorage.getItem(DATA_KEY);
    if (!raw) return emptyData();
    try {
      return pruneOld(normalizeData(JSON.parse(raw)), todayKey());
    } catch {
      // Corrupt JSON: keep the raw text aside so nothing is ever silently lost.
      localStorage.setItem(`${DATA_KEY}_corrupt_${Date.now()}`, raw);
      return emptyData();
    }
  } catch {
    return emptyData();
  }
}

let state: AppData = loadInitial();
let saveFailed = false;
let timer: ReturnType<typeof setTimeout> | null = null;
const listeners = new Set<() => void>();

const emit = () => listeners.forEach((l) => l());

export const getState = (): AppData => state;
export const getSaveFailed = (): boolean => saveFailed;

export function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function flushSave(): void {
  if (timer) {
    clearTimeout(timer);
    timer = null;
  }
  let failed = false;
  try {
    localStorage.setItem(DATA_KEY, JSON.stringify(state));
  } catch {
    failed = true;
  }
  if (failed !== saveFailed) {
    saveFailed = failed;
    emit();
  }
}

export function setState(updater: (current: AppData) => AppData): void {
  state = updater(state);
  emit();
  if (timer) clearTimeout(timer);
  timer = setTimeout(flushSave, 250);
}

export function replaceAll(next: AppData): void {
  setState(() => normalizeData(next));
  flushSave();
}

export function resetAll(): void {
  setState(() => emptyData());
  flushSave();
}

if (typeof window !== "undefined") {
  window.addEventListener("pagehide", flushSave);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") flushSave();
  });
}

export function useAppData(): AppData {
  return useSyncExternalStore(subscribe, getState, getState);
}

export function useSaveFailed(): boolean {
  return useSyncExternalStore(subscribe, getSaveFailed, getSaveFailed);
}
