import { HashRouter, Navigate, Route, Routes } from "react-router-dom";
import BottomNav from "@/components/BottomNav";
import { FeedbackProvider } from "@/components/Feedback";
import LockGate from "@/components/LockGate";
import { useNativeBridge } from "@/native/useNativeBridge";
import { useSaveFailed } from "@/store/store";
import DiaryPage from "@/pages/Diary";
import EntryDetailPage from "@/pages/EntryDetail";
import HomePage from "@/pages/Home";
import MedicineFormPage from "@/pages/MedicineForm";
import MedicinePage from "@/pages/Medicine";
import NewEntryPage from "@/pages/NewEntry";
import PrescriptionFormPage from "@/pages/PrescriptionForm";
import SettingsPage from "@/pages/Settings";
import WaterPage from "@/pages/Water";

function Shell() {
  useNativeBridge();
  const saveFailed = useSaveFailed();
  return (
    <>
      <LockGate>
        {saveFailed && (
          <div className="safe-top bg-red-500 px-4 py-2 text-center text-xs font-semibold text-white">
            ⚠️ ডেটা সেভ করা যাচ্ছে না — ফোনের স্টোরেজ ভরে গেছে। ব্যাকআপ নিয়ে জায়গা খালি করুন।
          </div>
        )}
        <div className="mx-auto min-h-screen max-w-xl pb-28">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/diary" element={<DiaryPage />} />
            <Route path="/new" element={<NewEntryPage />} />
            <Route path="/entry/:id" element={<EntryDetailPage />} />
            <Route path="/water" element={<WaterPage />} />
            <Route path="/medicine" element={<MedicinePage />} />
            <Route path="/medicine/new" element={<MedicineFormPage />} />
            <Route path="/medicine/:id/edit" element={<MedicineFormPage />} />
            <Route path="/prescription/new" element={<PrescriptionFormPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
        <BottomNav />
      </LockGate>
    </>
  );
}

export default function App() {
  return (
    <HashRouter>
      <FeedbackProvider>
        <Shell />
      </FeedbackProvider>
    </HashRouter>
  );
}
