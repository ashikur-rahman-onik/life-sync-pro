import { useEffect, useSyncExternalStore } from "react";

export type ThemePref = "light" | "dark" | "system";
const KEY = "diary_theme";
const listeners = new Set<() => void>();

export function getThemePref(): ThemePref {
  try {
    const v = localStorage.getItem(KEY);
    return v === "light" || v === "dark" ? v : "system";
  } catch {
    return "system";
  }
}

export function isDarkNow(pref: ThemePref = getThemePref()): boolean {
  return pref === "dark" || (pref === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
}

export function applyTheme(pref: ThemePref = getThemePref()): void {
  document.documentElement.classList.toggle("dark", isDarkNow(pref));
  const meta = document.querySelector('meta[name="theme-color"]');
  meta?.setAttribute("content", isDarkNow(pref) ? "#1c1715" : "#b8876b");
}

export function setThemePref(pref: ThemePref): void {
  try {
    if (pref === "system") localStorage.removeItem(KEY);
    else localStorage.setItem(KEY, pref);
  } catch {
    /* storage unavailable — theme just won't persist */
  }
  applyTheme(pref);
  listeners.forEach((l) => l());
}

/** Current preference + keeps the page in sync when the phone switches light/dark. */
export function useThemePref(): ThemePref {
  const pref = useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => {
        listeners.delete(l);
      };
    },
    getThemePref,
    getThemePref,
  );
  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => applyTheme();
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  return pref;
}
