import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { App as CapApp } from "@capacitor/app";
import { pushBackHandler } from "@/lib/backStack";
import { getAutoLockSec, hasPin, removePin, verifyPin } from "@/lib/security";
import { toBn } from "@/lib/bn";
import { isNative } from "@/native/platform";
import { resetAll } from "@/store/store";
import { useConfirm } from "./Feedback";

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫"];

/** Locks the app behind the PIN, and re-locks after the app stayed in the background for a while. */
export default function LockGate({ children }: { children: ReactNode }) {
  const [locked, setLocked] = useState(() => hasPin());
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const hiddenAt = useRef<number | null>(null);
  const confirm = useConfirm();

  /* Re-lock after the configured time in the background. */
  useEffect(() => {
    const onHidden = () => {
      hiddenAt.current = Date.now();
    };
    const onVisible = () => {
      const at = hiddenAt.current;
      hiddenAt.current = null;
      const limit = getAutoLockSec();
      if (at !== null && hasPin() && limit >= 0 && Date.now() - at >= limit * 1000) {
        setPin("");
        setError("");
        setLocked(true);
      }
    };
    const onVisibility = () => (document.visibilityState === "hidden" ? onHidden() : onVisible());
    document.addEventListener("visibilitychange", onVisibility);

    let remove: (() => void) | undefined;
    if (isNative()) {
      void CapApp.addListener("appStateChange", ({ isActive }) => (isActive ? onVisible() : onHidden())).then((h) => {
        remove = () => void h.remove();
      });
    }
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      remove?.();
    };
  }, []);

  /* While locked, Android back should leave the app instead of going "behind" the lock. */
  useEffect(() => {
    if (!locked) return;
    return pushBackHandler(() => {
      if (isNative()) void CapApp.exitApp();
    });
  }, [locked]);

  const submit = useCallback(async (value: string) => {
    setBusy(true);
    try {
      const result = await verifyPin(value);
      if (result.ok) {
        setLocked(false);
        setPin("");
        setError("");
      } else {
        setPin("");
        setError(
          result.waitMs > 0
            ? `অনেকবার ভুল হয়েছে। ${toBn(Math.ceil(result.waitMs / 1000))} সেকেন্ড পরে আবার চেষ্টা করুন`
            : "পিন সঠিক নয়, আবার চেষ্টা করুন",
        );
      }
    } catch {
      setError("পিন যাচাই করা যায়নি");
      setPin("");
    } finally {
      setBusy(false);
    }
  }, []);

  const press = (key: string) => {
    if (busy) return;
    if (key === "⌫") {
      setPin((p) => p.slice(0, -1));
      return;
    }
    if (pin.length >= 4) return;
    setError("");
    const next = pin + key;
    setPin(next);
    if (next.length === 4) void submit(next);
  };

  const forgot = async () => {
    const ok = await confirm({
      title: "পিন ভুলে গেছেন?",
      message: "নিরাপত্তার জন্য পিন রিসেট করতে হলে অ্যাপের সব ডেটা (ডায়েরি, পানি, ওষুধ) মুছে যাবে। ব্যাকআপ থাকলে পরে রিস্টোর করতে পারবেন।",
      confirmText: "সব মুছে রিসেট করুন",
      danger: true,
    });
    if (!ok) return;
    resetAll();
    removePin();
    setLocked(false);
    setPin("");
  };

  if (!locked) return <>{children}</>;

  return (
    <div className="safe-top safe-bottom fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[var(--color-paper)] px-6 dark:bg-[var(--color-paper-dark)]">
      <div className="text-5xl">🔒</div>
      <h1 className="mt-4 text-lg font-semibold">ডায়েরি লক করা আছে</h1>
      <p className="mt-1 text-sm opacity-60">চালিয়ে যেতে ৪ ডিজিটের পিন দিন</p>

      <div className="mt-6 flex gap-3" aria-label={`${pin.length} ডিজিট দেওয়া হয়েছে`}>
        {[0, 1, 2, 3].map((i) => (
          <span key={i} className={`h-4 w-4 rounded-full border-2 border-[var(--color-accent)] ${pin.length > i ? "bg-[var(--color-accent)]" : "bg-transparent"}`} />
        ))}
      </div>
      <p className="mt-3 min-h-5 text-center text-xs font-medium text-red-500">{error}</p>

      <div className="mt-4 grid grid-cols-3 gap-4">
        {KEYS.map((key, i) =>
          key === "" ? (
            <span key={i} />
          ) : (
            <button
              key={i}
              type="button"
              onClick={() => press(key)}
              className="flex h-16 w-16 items-center justify-center rounded-full bg-white/70 text-xl font-medium shadow-sm active:scale-95 dark:bg-white/10"
            >
              {key === "⌫" ? key : toBn(key)}
            </button>
          ),
        )}
      </div>

      <button type="button" onClick={() => void forgot()} className="mt-8 text-xs font-medium text-[var(--color-accent)]">
        পিন ভুলে গেছি
      </button>
    </div>
  );
}
