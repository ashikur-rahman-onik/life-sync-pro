package com.sabuj.lifesynepro;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
