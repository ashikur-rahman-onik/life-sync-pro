import { describe, expect, it } from "vitest";
import { buildEntryPages, headerLines, paginate, splitPhotos, type PageLayout } from "../src/domain/pagination";
import type { Attachment, DiaryEntry } from "../src/domain/types";

/** Fake page: 20 characters per line, 10px per line. */
const measure = (s: string) => Math.max(1, s.split("\n").reduce((n, line) => n + Math.max(1, Math.ceil(line.length / 20)), 0)) * 10;

describe("paginate", () => {
  it("keeps short text on one page", () => {
    expect(paginate("hello world", measure, 50, 50)).toEqual(["hello world"]);
    expect(paginate("", measure, 50, 50)).toEqual([""]);
  });
  it("splits long text at word boundaries so every page fits and nothing is lost", () => {
    const words = Array.from({ length: 120 }, (_, i) => `word${i}`);
    const text = words.join(" ");
    const pages = paginate(text, measure, 40, 60); // first page 4 lines, others 6 lines
    expect(pages.length).toBeGreaterThan(2);
    expect(measure(pages[0])).toBeLessThanOrEqual(40);
    for (const p of pages.slice(1)) expect(measure(p)).toBeLessThanOrEqual(60);
    expect(pages.join(" ").replace(/\s+/g, " ")).toBe(text);
  });
  it("cuts a word longer than a page by characters instead of looping forever", () => {
    const pages = paginate("x".repeat(500), measure, 30, 30);
    expect(pages.length).toBeGreaterThan(4);
    expect(pages.every((p) => measure(p) <= 30)).toBe(true);
    expect(pages.join("")).toBe("x".repeat(500));
  });
  it("respects line breaks", () => {
    const text = Array.from({ length: 12 }, (_, i) => `line ${i}`).join("\n");
    const pages = paginate(text, measure, 50, 50);
    expect(pages).toHaveLength(3);
    expect(pages[0].split("\n")).toHaveLength(5);
  });
});

describe("photos", () => {
  it("fills the text page first, then groups the rest", () => {
    expect(splitPhotos([1, 2, 3, 4, 5, 6, 7], 2, 4)).toEqual({ onTextPage: [1, 2], pages: [[3, 4, 5, 6], [7]] });
    expect(splitPhotos([1, 2], 0, 4)).toEqual({ onTextPage: [], pages: [[1, 2]] });
    expect(splitPhotos([], 3, 4)).toEqual({ onTextPage: [], pages: [] });
  });
});

describe("buildEntryPages", () => {
  const layout: PageLayout = { measure, lineHeight: 10, restLines: 12, photoFootprint: 40, photosPerRow: 2, photosPerPage: 4 };
  const img = (id: string): Attachment => ({ id, name: id, kind: "image", mime: "image/jpeg", bytes: 1, url: `https://x/${id}.jpg`, localKey: null });
  const file: Attachment = { id: "f", name: "doc.pdf", kind: "file", mime: "application/pdf", bytes: 1, url: "https://x/doc.pdf", localKey: null };
  const entry = (over: Partial<DiaryEntry>): DiaryEntry => ({ id: "e", title: "", content: "", mood: "good", tags: [], favorite: false, attachments: [], entryDate: "2026-10-28", createdAt: "", updatedAt: "", ...over });

  it("reserves lines for the date and title", () => {
    expect(headerLines("")).toBe(2);
    expect(headerLines("ছোট")).toBe(3);
    expect(headerLines("এটা একটা অনেক লম্বা শিরোনাম")).toBe(4);
  });
  it("puts a short entry with one photo on a single page", () => {
    const pages = buildEntryPages(entry({ content: "আজ ভালো দিন", attachments: [img("a")] }), layout);
    expect(pages).toHaveLength(1);
    expect(pages[0].photos).toHaveLength(1);
    expect(pages[0].isFirst).toBe(true);
  });
  it("moves photos to extra pages when the text fills the page, and adds a files page", () => {
    const long = Array.from({ length: 80 }, (_, i) => `word${i}`).join(" ");
    const pages = buildEntryPages(entry({ content: long, attachments: [img("a"), img("b"), img("c"), img("d"), img("e"), file] }), layout);
    const kinds = pages.map((p) => p.kind);
    expect(kinds[0]).toBe("text");
    expect(kinds).toContain("photos");
    expect(kinds[kinds.length - 1]).toBe("files");
    expect(pages.flatMap((p) => p.photos)).toHaveLength(5);
    expect(pages.map((p) => p.index)).toEqual(pages.map((_, i) => i));
    expect(new Set(pages.map((p) => p.total))).toEqual(new Set([pages.length]));
  });
  it("supports photo-only entries", () => {
    const pages = buildEntryPages(entry({ content: "", attachments: [img("a"), img("b")] }), layout);
    expect(pages).toHaveLength(1);
    expect(pages[0].photos).toHaveLength(2);
  });
});
