import { describe, expect, it } from "vitest";
import { emptyData } from "../src/domain/defaults";
import { diffData, emptyShadow, mapOf, sameMap, stable } from "../src/firebase/diff";
import type { DiaryEntry } from "../src/domain/types";

const entry = (id: string, content = "x"): DiaryEntry => ({ id, title: "", content, mood: "good", tags: [], favorite: false, attachments: [], entryDate: "2026-10-28", createdAt: "2026-10-28T00:00:00.000Z", updatedAt: "2026-10-28T00:00:00.000Z" });

describe("stable json", () => {
  it("ignores key order", () => {
    expect(stable({ b: 1, a: [{ d: 1, c: 2 }] })).toBe(stable({ a: [{ c: 2, d: 1 }], b: 1 }));
    expect(stable({ a: null })).not.toBe(stable({ a: 0 }));
  });
});

describe("diffData", () => {
  it("writes nothing when Firestore already matches", () => {
    const data = emptyData();
    data.entries = [entry("a")];
    const first = diffData(emptyShadow(), data);
    const again = diffData(first.next, data);
    expect(again.ops).toEqual([]);
  });

  it("sets new and changed docs, deletes removed docs", () => {
    const data = emptyData();
    data.entries = [entry("a"), entry("b")];
    const { next } = diffData(emptyShadow(), data);

    const changed = { ...data, entries: [entry("a", "edited"), entry("c")] };
    const ops = diffData(next, changed).ops.filter((o) => o.collection === "entries");
    expect(ops.map((o) => `${o.kind}:${o.id}`).sort()).toEqual(["delete:b", "set:a", "set:c"]);
  });

  it("writes settings only when they change", () => {
    const data = emptyData();
    const { next } = diffData(emptyShadow(), data);
    expect(diffData(next, data).ops.filter((o) => o.collection === "settings")).toEqual([]);
    const changed = { ...data, settings: { ...data.settings, medRemindersOn: false } };
    expect(diffData(next, changed).ops.filter((o) => o.collection === "settings")).toHaveLength(1);
  });

  it("does not echo back what came from the server", () => {
    const data = emptyData();
    data.entries = [entry("z")];
    const shadow = emptyShadow();
    shadow.entries = mapOf(data.entries);
    shadow.containers = mapOf(data.containers);
    shadow.settings = stable(data.settings);
    expect(diffData(shadow, data).ops).toEqual([]);
    expect(sameMap(mapOf(data.entries), shadow.entries)).toBe(true);
  });
});
