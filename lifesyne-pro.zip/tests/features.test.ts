import { describe, expect, it } from "vitest";
import { emptyData } from "../src/domain/defaults";
import { habitLogMap, habitStats, isScheduled } from "../src/domain/habits";
import { planReminders, shiftOn } from "../src/domain/reminders";
import { nextDate, occurrenceDates } from "../src/domain/schedule";
import { intervalTimes } from "../src/domain/water";
import { normalizeData } from "../src/store/normalize";
import type { Habit, Medicine, Reminder } from "../src/domain/types";

function rem(over: Partial<Reminder> = {}): Reminder {
  return { id: "r1", title: "টেস্ট", note: "", icon: "⏰", categoryId: "personal", type: "daily", date: "2026-10-28", times: ["08:00"], weekdays: [], intervalDays: 2, endDate: null, style: "normal", snoozeMin: 10, earlyMin: 0, active: true, createdAt: "2026-10-28T00:00:00.000Z", ...over };
}
function habit(over: Partial<Habit> = {}): Habit {
  return { id: "h1", name: "ব্যায়াম", icon: "🏃", color: "#2b7de9", target: 1, weekdays: [], times: [], reminderOn: false, style: "normal", startDate: "2026-10-01", archived: false, createdAt: "", ...over };
}
const med = (over: Partial<Medicine> = {}): Medicine => ({ id: "m1", name: "নাপা", form: "tablet", slots: [{ id: "a", label: "", time: "08:00", qty: 1 }], relation: "after", startDate: "2026-10-28", endDate: null, weekdays: [], stock: null, notes: "", doctor: "", prescriptionId: null, active: true, createdAt: "", ...over });

describe("occurrence dates", () => {
  it("once / daily / weekly / interval", () => {
    expect(occurrenceDates(rem({ type: "once", date: "2026-11-05" }), "2026-10-28", "2026-12-01")).toEqual(["2026-11-05"]);
    expect(occurrenceDates(rem({ type: "daily" }), "2026-10-28", "2026-10-31")).toHaveLength(4);
    // 28 Oct 2026 is a Wednesday (3); Fridays = 5
    expect(occurrenceDates(rem({ type: "weekly", weekdays: [5] }), "2026-10-28", "2026-11-14")).toEqual(["2026-10-30", "2026-11-06", "2026-11-13"]);
    expect(occurrenceDates(rem({ type: "weekly", weekdays: [] }), "2026-10-28", "2026-11-12")).toEqual(["2026-10-28", "2026-11-04", "2026-11-11"]);
    expect(occurrenceDates(rem({ type: "interval", intervalDays: 3 }), "2026-10-30", "2026-11-09")).toEqual(["2026-10-31", "2026-11-03", "2026-11-06", "2026-11-09"]);
  });
  it("monthly clamps to the last day of short months", () => {
    const r = rem({ type: "monthly", date: "2026-01-31" });
    expect(occurrenceDates(r, "2026-02-01", "2026-04-30")).toEqual(["2026-02-28", "2026-03-31", "2026-04-30"]);
  });
  it("yearly handles birthdays and 29 Feb", () => {
    expect(occurrenceDates(rem({ type: "yearly", date: "2000-12-05" }), "2026-10-28", "2027-12-31")).toEqual(["2026-12-05", "2027-12-05"]);
    expect(occurrenceDates(rem({ type: "yearly", date: "2024-02-29" }), "2026-01-01", "2028-12-31")).toEqual(["2026-02-28", "2027-02-28", "2028-02-29"]);
  });
  it("respects end date, inactive and next date", () => {
    expect(occurrenceDates(rem({ endDate: "2026-10-29" }), "2026-10-28", "2026-11-30")).toHaveLength(2);
    expect(occurrenceDates(rem({ active: false }), "2026-10-28", "2026-11-30")).toEqual([]);
    expect(nextDate(rem({ type: "yearly", date: "2000-12-05" }), "2026-10-28")).toBe("2026-12-05");
    expect(nextDate(rem({ type: "once", date: "2026-01-01" }), "2026-10-28")).toBeNull();
  });
});

describe("habits", () => {
  const counts = (dates: string[], n = 1) => habitLogMap(dates.map((d) => ({ id: `h1|${d}`, key: `h1|${d}`, habitId: "h1", date: d, count: n })));
  it("counts the current streak, skipping days the habit is off", () => {
    const h = habit();
    const s = habitStats(h, counts(["2026-10-26", "2026-10-27", "2026-10-28"]), "2026-10-28");
    expect(s.streak).toBe(3);
    expect(s.best).toBe(3);
  });
  it("keeps yesterday's streak while today is still open", () => {
    expect(habitStats(habit(), counts(["2026-10-26", "2026-10-27"]), "2026-10-28").streak).toBe(2);
    expect(habitStats(habit(), counts(["2026-10-25", "2026-10-27"]), "2026-10-28").streak).toBe(1);
  });
  it("supports weekday-only habits and counts targets", () => {
    const h = habit({ weekdays: [1, 3], target: 3 }); // Mon, Wed
    expect(isScheduled(h, "2026-10-27")).toBe(false);
    expect(isScheduled(h, "2026-10-28")).toBe(true);
    expect(habitStats(h, counts(["2026-10-26", "2026-10-28"], 3), "2026-10-28").streak).toBe(2);
    expect(habitStats(h, counts(["2026-10-26", "2026-10-28"], 2), "2026-10-28").streak).toBe(0);
  });
});

describe("planner: new features", () => {
  const now = new Date(2026, 9, 28, 9, 0);
  const base = () => {
    const d = emptyData();
    d.settings.water.remindersOn = false;
    return d;
  };

  it("repeats daily reminders and plans sparse ones far ahead", () => {
    const d = base();
    d.reminders = [rem({ id: "a", times: ["07:00", "19:00"] }), rem({ id: "b", type: "yearly", date: "2000-12-05", times: ["09:00"] })];
    const plan = planReminders(d, now).filter((n) => n.kind === "reminder");
    expect(plan.filter((n) => n.on)).toHaveLength(2);
    const birthday = plan.filter((n) => n.at);
    expect(birthday).toHaveLength(1); // next 5 Dec only; the one after is beyond 400 days
    expect(birthday[0].at?.getMonth()).toBe(11);
  });
  it("adds an early heads-up and uses the reminder's sound style", () => {
    const d = base();
    d.reminders = [rem({ earlyMin: 30, style: "alarm", times: ["08:00"] })];
    const plan = planReminders(d, now).filter((n) => n.kind === "reminder");
    expect(plan).toHaveLength(2);
    expect(plan.every((n) => n.style === "alarm")).toBe(true);
    expect(plan.map((n) => n.on?.hour).sort()).toEqual([7, 8]);
  });
  it("shifts weekly times across midnight", () => {
    expect(shiftOn({ weekday: 1, hour: 0, minute: 10 }, -30)).toEqual({ weekday: 7, hour: 23, minute: 40 });
    expect(shiftOn({ hour: 23, minute: 50 }, 20)).toEqual({ hour: 0, minute: 10 });
  });
  it("plans habit reminders only when switched on", () => {
    const d = base();
    d.habits = [habit({ times: ["06:00"], reminderOn: true }), habit({ id: "h2", times: ["07:00"], reminderOn: false }), habit({ id: "h3", times: ["08:00"], reminderOn: true, archived: true })];
    expect(planReminders(d, now).filter((n) => n.kind === "habit")).toHaveLength(1);
  });
  it("adds follow-up nudges only for doses not yet taken", () => {
    const d = base();
    d.settings.notify.medFollowUps = 2;
    d.settings.notify.medFollowEveryMin = 10;
    d.medicines = [med({ slots: [{ id: "a", label: "", time: "09:30", qty: 1 }] })];
    const followups = () => planReminders(d, now).filter((n) => n.extra.followup);
    expect(followups()).toHaveLength(4); // 2 today + 2 tomorrow
    d.doseLogs = [{ id: "x", key: "m1|a|2026-10-28", medicineId: "m1", medicineName: "", slotId: "a", date: "2026-10-28", status: "taken", at: "", qty: 1 }];
    expect(followups()).toHaveLength(2);
  });
  it("plans water by interval and by custom times", () => {
    const d = emptyData();
    d.settings.profile = { name: "", age: 30, weightKg: 70, activity: "low", hotWeather: false };
    d.settings.water.mode = "custom";
    d.settings.water.customTimes = ["09:00", "15:00"];
    expect(planReminders(d, now).filter((n) => n.kind === "water")).toHaveLength(2);
    d.settings.water.mode = "interval";
    d.settings.water.intervalMin = 120;
    expect(planReminders(d, now).filter((n) => n.kind === "water").length).toBe(intervalTimes("07:00", "23:00", 120).length);
    expect(intervalTimes("07:00", "23:00", 120)).toEqual(["09:00", "11:00", "13:00", "15:00", "17:00", "19:00", "21:00"]);
  });
  it("snoozes reminders and medicines", () => {
    const d = base();
    d.reminders = [rem({ type: "once", date: "2026-11-30" })];
    d.snoozes = [{ id: "s", kind: "reminder", refId: "r1", slotId: "08:00", date: "2026-10-28", time: "08:00", at: new Date(2026, 9, 28, 9, 20).toISOString() }];
    expect(planReminders(d, now).filter((n) => n.extra.snooze === "1")).toHaveLength(1);
  });
  it("normalises legacy snoozes and drops broken reminders", () => {
    const data = normalizeData({
      medicines: [{ id: "m1", name: "x", slots: [{ id: "a", time: "08:00", qty: 1 }] }],
      snoozes: [{ id: "z", medicineId: "m1", slotId: "a", date: "2026-10-28", time: "08:00", at: "2026-10-28T03:00:00.000Z" }],
      reminders: [{ title: "ok", times: ["08:00"] }, { title: "no times", times: [] }, { title: "", times: ["08:00"] }],
    });
    expect(data.snoozes[0]).toMatchObject({ kind: "med", refId: "m1" });
    expect(data.reminders).toHaveLength(1);
    expect(data.settings.categories.length).toBeGreaterThan(3);
  });
});
