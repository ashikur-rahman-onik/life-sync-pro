import { describe, expect, it } from "vitest";
import { allAttachments, formatBytes, patchAttachmentIn, pendingAttachments } from "../src/domain/attachments";
import { emptyData } from "../src/domain/defaults";
import { chronological, filterEntries, onThisDay, pageNumbers } from "../src/domain/diary";
import { categoryTotals, formatTaka, groupByDay, inMonth, parseAmount, summarize } from "../src/domain/ledger";
import { promptOfTheDay } from "../src/domain/prompts";
import type { Attachment, DiaryEntry, LedgerEntry } from "../src/domain/types";
import { diffData, emptyShadow } from "../src/firebase/diff";
import { createLockRecord, isDiaryPath, verifyDiaryPassword } from "../src/lib/diaryLock";
import { generatePassword, passwordStrength } from "../src/lib/password";
import { normalizeData } from "../src/store/normalize";

const att = (id: string, over: Partial<Attachment> = {}): Attachment => ({ id, name: `${id}.jpg`, kind: "image", mime: "image/jpeg", bytes: 2048, url: null, localKey: `att-${id}`, ...over });
const entry = (id: string, entryDate: string, over: Partial<DiaryEntry> = {}): DiaryEntry => ({ id, title: "", content: "x", mood: "good", tags: [], favorite: false, attachments: [], entryDate, createdAt: `${entryDate}T10:00:00.000Z`, updatedAt: "", ...over });
const led = (id: string, date: string, type: "income" | "expense", amount: number, categoryId = "food"): LedgerEntry => ({ id, date, type, amount, categoryId, note: "", createdAt: `${date}T10:00:00.000Z` });

describe("ledger", () => {
  it("formats taka with South Asian grouping and Bangla digits", () => {
    expect(formatTaka(0)).toBe("৳ ০");
    expect(formatTaka(950)).toBe("৳ ৯৫০");
    expect(formatTaka(1250)).toBe("৳ ১,২৫০");
    expect(formatTaka(1234567)).toBe("৳ ১২,৩৪,৫৬৭");
    expect(formatTaka(1500.5)).toBe("৳ ১,৫০০.৫০");
    expect(formatTaka(-300)).toBe("−৳ ৩০০");
  });
  it("parses typed amounts (Bangla digits, commas, symbols)", () => {
    expect(parseAmount("১২৫০")).toBe(1250);
    expect(parseAmount("৳ 1,250.5")).toBe(1250.5);
    expect(parseAmount("")).toBeNull();
    expect(parseAmount("0")).toBeNull();
    expect(parseAmount("abc")).toBeNull();
  });
  it("summarises, groups by day and totals by category", () => {
    const list = [led("a", "2026-10-28", "income", 5000, "salary"), led("b", "2026-10-28", "expense", 300), led("c", "2026-10-29", "expense", 700, "bills"), led("d", "2026-11-01", "expense", 50)];
    expect(summarize(list)).toEqual({ income: 5000, expense: 1050, balance: 3950 });
    expect(inMonth(list, "2026-10")).toHaveLength(3);
    const days = groupByDay(inMonth(list, "2026-10"));
    expect(days.map((d) => d.date)).toEqual(["2026-10-29", "2026-10-28"]);
    expect(days[1].summary.balance).toBe(4700);
    const cats = categoryTotals(list, "expense", emptyData().settings.ledgerCategories);
    expect(cats[0].id).toBe("bills");
    expect(cats[0].category?.name).toBe("বিল");
  });
});

describe("passwords", () => {
  it("generates strong random passwords with every character type", () => {
    for (let i = 0; i < 40; i++) {
      const p = generatePassword(14);
      expect(p).toHaveLength(14);
      expect(p).toMatch(/[a-z]/);
      expect(p).toMatch(/[A-Z]/);
      expect(p).toMatch(/\d/);
      expect(p).toMatch(/[^A-Za-z0-9]/);
    }
    expect(generatePassword(3)).toHaveLength(8);
    expect(generatePassword(99)).toHaveLength(40);
    expect(generatePassword()).not.toBe(generatePassword());
  });
  it("rates strength", () => {
    expect(passwordStrength("").score).toBe(0);
    expect(passwordStrength("abc").score).toBeLessThanOrEqual(1);
    expect(passwordStrength("password").score).toBeLessThanOrEqual(1);
    expect(passwordStrength("Tr0ub4dor&3xYz!").score).toBe(4);
  });
});

describe("diary lock", () => {
  it("accepts the right password and rejects wrong ones", async () => {
    const record = await createLockRecord("সিক্রেট123");
    expect(record.hash).toHaveLength(64);
    expect((await verifyDiaryPassword(record, "সিক্রেট123")).ok).toBe(true);
    expect((await verifyDiaryPassword(record, "wrong")).ok).toBe(false);
  });
  it("uses a different salt every time", async () => {
    const [a, b] = await Promise.all([createLockRecord("same"), createLockRecord("same")]);
    expect(a.salt).not.toBe(b.salt);
    expect(a.hash).not.toBe(b.hash);
  });
  it("knows which routes are private", () => {
    for (const p of ["/diary", "/diary/vault", "/new", "/entry/abc"]) expect(isDiaryPath(p)).toBe(true);
    for (const p of ["/", "/water", "/reminders", "/settings", "/diaryfoo"]) expect(isDiaryPath(p)).toBe(false);
  });
});

describe("attachments", () => {
  const data = () => {
    const d = emptyData();
    d.entries = [entry("e1", "2026-10-28", { attachments: [att("a1"), att("a2", { url: "https://res.cloudinary.com/x/image/upload/v1/a2.jpg", localKey: null })] })];
    d.vault = [{ id: "v1", title: "NID", note: "", tag: "id", attachments: [att("a3")], createdAt: "", updatedAt: "" }];
    d.settings.diary.coverImage = att("cover");
    return d;
  };
  it("finds every attachment and the ones still waiting to upload", () => {
    expect(allAttachments(data())).toHaveLength(4);
    expect(pendingAttachments(data()).map((a) => a.id).sort()).toEqual(["a1", "a3", "cover"]);
  });
  it("patches an attachment wherever it lives", () => {
    let d = patchAttachmentIn(data(), "a1", { url: "https://x/y.jpg", localKey: null });
    d = patchAttachmentIn(d, "cover", { url: "https://x/c.jpg", localKey: null });
    expect(d.entries[0].attachments[0].url).toBe("https://x/y.jpg");
    expect(d.settings.diary.coverImage?.localKey).toBeNull();
    expect(pendingAttachments(d).map((a) => a.id)).toEqual(["a3"]);
  });
  it("formats sizes", () => {
    expect(formatBytes(500)).toBe("1 KB");
    expect(formatBytes(2048)).toBe("2 KB");
    expect(formatBytes(3 * 1024 * 1024)).toBe("3.0 MB");
  });
  it("normalises attachments: needs a https link or a local copy", () => {
    const d = normalizeData({
      entries: [{ content: "", attachments: [{ id: "x", url: "http://insecure/a.jpg" }, { id: "y", url: "https://ok/a.jpg", kind: "image", name: "a.jpg" }, { id: "z", localKey: "k", name: "f.pdf" }] }],
    });
    expect(d.entries).toHaveLength(1); // empty text is fine when photos are attached
    expect(d.entries[0].attachments.map((a) => a.id)).toEqual(["y", "z"]);
    expect(normalizeData({ entries: [{ content: "", attachments: [] }] }).entries).toHaveLength(0);
  });
});

describe("diary pages", () => {
  const list = [entry("a", "2024-10-28"), entry("b", "2025-10-28"), entry("c", "2026-10-27", { favorite: true }), entry("d", "2026-10-28")];
  it("numbers pages in writing order and orders them for page turning", () => {
    expect(pageNumbers(list).get("a")).toBe(1);
    expect(pageNumbers(list).get("d")).toBe(4);
    expect(chronological([...list].reverse()).map((e) => e.id)).toEqual(["a", "b", "c", "d"]);
  });
  it("finds memories from the same day in earlier years", () => {
    expect(onThisDay(list, "2026-10-28").map((m) => `${m.entry.id}:${m.yearsAgo}`)).toEqual(["b:1", "a:2"]);
    expect(onThisDay(list, "2026-01-01")).toEqual([]);
  });
  it("filters favourites and gives a daily prompt", () => {
    expect(filterEntries(list, "", null, true).map((e) => e.id)).toEqual(["c"]);
    expect(promptOfTheDay("2026-10-28")).toBe(promptOfTheDay("2026-10-28"));
    expect(promptOfTheDay("2026-10-28").length).toBeGreaterThan(5);
  });
});

describe("new collections sync and normalise", () => {
  it("writes vault, passwords and ledger docs", () => {
    const d = emptyData();
    d.passwords = [{ id: "p1", title: "FB", username: "u", password: "pw", url: "", note: "", tag: "social", createdAt: "", updatedAt: "" }];
    d.ledger = [led("l1", "2026-10-28", "expense", 100)];
    const ops = diffData(emptyShadow(), d).ops.filter((o) => ["passwords", "ledger"].includes(o.collection));
    expect(ops.map((o) => o.collection).sort()).toEqual(["ledger", "passwords"]);
  });
  it("drops invalid records and keeps valid ones", () => {
    const d = normalizeData({
      vault: [{ title: "ok" }, { title: "" }],
      passwords: [{ title: "x", password: "y" }, { password: "no title" }],
      ledger: [{ amount: 50, type: "income", date: "2026-10-28" }, { amount: -5 }, { amount: "abc" }],
      settings: { diary: { lock: { salt: "aa", hash: "bb", iterations: 5 }, coverColor: "red", paper: "weird" } },
    });
    expect(d.vault).toHaveLength(1);
    expect(d.passwords).toHaveLength(1);
    expect(d.ledger).toHaveLength(1);
    expect(d.settings.diary.lock).toBeNull(); // iterations too low to be a real record
    expect(d.settings.diary.coverColor).toBe("#5b3a29");
    expect(d.settings.diary.paper).toBe("ruled");
    expect(d.settings.ledgerCategories.length).toBeGreaterThan(5);
  });
});
