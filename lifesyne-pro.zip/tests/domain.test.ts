import { describe, expect, it } from "vitest";
import { addDays, dateKey, diffDays, isValidDateKey, minutesToTime, weekdayOf } from "../src/lib/date";
import { formatDateBn, formatMl, formatTimeBn, toBn } from "../src/lib/bn";
import { calcWaterGoalMl, planWaterTimes, waterHistory } from "../src/domain/water";
import {
  adherence,
  buildPresetSlots,
  dosesForDate,
  doseStatus,
  endDateFromDays,
  evenSlots,
  logMap,
  stockInfo,
  validateMedicine,
} from "../src/domain/medicine";
import { planReminders } from "../src/domain/reminders";
import { diaryStats } from "../src/domain/diary";
import { emptyData } from "../src/domain/defaults";
import { normalizeData } from "../src/store/normalize";
import type { DoseLog, Medicine } from "../src/domain/types";

const meals = { breakfast: "08:00", lunch: "13:30", dinner: "21:00", bed: "22:30" };

function med(over: Partial<Medicine> = {}): Medicine {
  return {
    id: "m1",
    name: "নাপা",
    form: "tablet",
    slots: [{ id: "morning", label: "সকাল", time: "08:00", qty: 1 }],
    relation: "after",
    startDate: "2026-10-28",
    endDate: null,
    weekdays: [],
    stock: null,
    notes: "",
    doctor: "",
    prescriptionId: null,
    active: true,
    createdAt: "2026-10-28T00:00:00.000Z",
    ...over,
  };
}

describe("dates", () => {
  it("uses local date, not UTC", () => {
    // 1 AM local on 28 Oct must still be 28 Oct (toISOString would say the 27th in UTC+6).
    expect(dateKey(new Date(2026, 9, 28, 1, 0))).toBe("2026-10-28");
  });
  it("adds days across months and DST-safe diff", () => {
    expect(addDays("2026-10-30", 3)).toBe("2026-11-02");
    expect(addDays("2026-03-01", -1)).toBe("2026-02-28");
    expect(diffDays("2026-10-01", "2026-10-31")).toBe(30);
  });
  it("validates", () => {
    expect(isValidDateKey("2026-02-30")).toBe(false);
    expect(isValidDateKey("2026-10-28")).toBe(true);
    expect(weekdayOf("2026-10-28")).toBe(3);
    expect(minutesToTime(-30)).toBe("23:30");
  });
});

describe("bangla formatting", () => {
  it("formats numbers, time, date and volume", () => {
    expect(toBn(2026)).toBe("২০২৬");
    expect(formatTimeBn("08:05")).toBe("সকাল ৮:০৫");
    expect(formatTimeBn("00:30")).toBe("রাত ১২:৩০");
    expect(formatTimeBn("13:30")).toBe("দুপুর ১:৩০");
    expect(formatDateBn("2026-10-28")).toBe("২৮ অক্টোবর ২০২৬");
    expect(formatMl(250)).toBe("২৫০ মি.লি.");
    expect(formatMl(1500)).toBe("১.৫ লিটার");
    expect(formatMl(2500)).toBe("২.৫ লিটার");
  });
});

describe("water", () => {
  it("calculates the daily goal from age, weight, activity and weather", () => {
    expect(calcWaterGoalMl({ age: 30, weightKg: 70, activity: "low", hotWeather: false })).toBe(2450);
    expect(calcWaterGoalMl({ age: 30, weightKg: 70, activity: "moderate", hotWeather: true })).toBe(3300);
    expect(calcWaterGoalMl({ age: 60, weightKg: 60, activity: "low", hotWeather: false })).toBe(1900);
    expect(calcWaterGoalMl({ age: 7, weightKg: 22, activity: "low", hotWeather: false })).toBe(1400);
    expect(calcWaterGoalMl({ age: null, weightKg: 70, activity: "low", hotWeather: false })).toBeNull();
    expect(calcWaterGoalMl({ age: 30, weightKg: 300, activity: "high", hotWeather: true })).toBe(4500);
  });
  it("spreads reminder times between wake and sleep", () => {
    const t = planWaterTimes("07:00", "23:00", 8);
    expect(t).toHaveLength(8);
    expect(t[0]).toBe("07:30");
    expect(t[t.length - 1]).toBe("22:00");
    expect([...t].sort()).toEqual(t);
  });
  it("handles a sleep time after midnight", () => {
    const t = planWaterTimes("09:00", "01:00", 4);
    expect(t).toHaveLength(4);
  });
  it("builds a 7-day history", () => {
    const h = waterHistory([{ id: "a", date: "2026-10-28", at: "", ml: 500, containerName: "" }], "2026-10-28", 7);
    expect(h).toHaveLength(7);
    expect(h[6]).toEqual({ date: "2026-10-28", ml: 500 });
    expect(h[0].date).toBe("2026-10-22");
  });
});

describe("medicine slots", () => {
  it("builds 1+0+1 with before/after meal offsets", () => {
    const slots = buildPresetSlots({ morning: 1, noon: 0, night: 1, bed: 0 }, meals, "before");
    expect(slots.map((s) => s.time)).toEqual(["07:30", "20:30"]);
    const after = buildPresetSlots({ morning: 2, noon: 1, night: 1, bed: 1 }, meals, "after");
    expect(after.map((s) => s.time)).toEqual(["08:15", "13:45", "21:15", "22:30"]);
    expect(after[0].qty).toBe(2);
  });
  it("builds every-8-hours slots sorted by time", () => {
    expect(evenSlots("06:00", 8, 1).map((s) => s.time)).toEqual(["06:00", "14:00", "22:00"]);
    expect(evenSlots("22:00", 12, 1).map((s) => s.time)).toEqual(["10:00", "22:00"]);
  });
  it("computes course end date", () => {
    expect(endDateFromDays("2026-10-28", 7)).toBe("2026-11-03");
  });
  it("validates", () => {
    expect(validateMedicine(med())).toBeNull();
    expect(validateMedicine(med({ name: " " }))).not.toBeNull();
    expect(validateMedicine(med({ slots: [] }))).not.toBeNull();
    expect(validateMedicine(med({ endDate: "2026-10-01" }))).not.toBeNull();
  });
});

describe("dose planning, status and adherence", () => {
  it("respects start/end/weekdays", () => {
    const m = med({ endDate: "2026-10-30", weekdays: [3, 4] }); // Wed, Thu
    expect(dosesForDate([m], "2026-10-28")).toHaveLength(1); // Wed
    expect(dosesForDate([m], "2026-10-29")).toHaveLength(1); // Thu
    expect(dosesForDate([m], "2026-10-30")).toHaveLength(0); // Fri
    expect(dosesForDate([m], "2026-10-27")).toHaveLength(0); // before start
    expect(dosesForDate([med({ active: false })], "2026-10-28")).toHaveLength(0);
  });
  it("derives status", () => {
    const [d] = dosesForDate([med()], "2026-10-28");
    expect(doseStatus(d, undefined, "2026-10-28", 7 * 60)).toBe("upcoming");
    expect(doseStatus(d, undefined, "2026-10-28", 8 * 60 + 30)).toBe("due");
    expect(doseStatus(d, undefined, "2026-10-28", 10 * 60 + 1)).toBe("missed");
    expect(doseStatus(d, undefined, "2026-10-29", 0)).toBe("missed");
    const log = { status: "taken" } as DoseLog;
    expect(doseStatus(d, log, "2026-10-28", 7 * 60)).toBe("taken");
  });
  it("computes adherence ignoring pending doses", () => {
    const m = med({ startDate: "2026-10-26" });
    const logs: DoseLog[] = [{ id: "1", key: "m1|morning|2026-10-26", medicineId: "m1", medicineName: "", slotId: "morning", date: "2026-10-26", status: "taken", at: "", qty: 1 }];
    // 26 taken, 27 missed, 28 (today 07:00) upcoming => 50%
    const a = adherence([m], logs, "2026-10-28", 7, 7 * 60);
    expect(a).toEqual({ taken: 1, skipped: 0, missed: 1, percent: 50 });
    expect(adherence([], [], "2026-10-28", 7, 0).percent).toBeNull();
  });
});

describe("stock", () => {
  it("warns when stock cannot finish the course", () => {
    const m = med({ stock: 5, endDate: "2026-11-03" }); // 7 days × 1
    const info = stockInfo(m, "2026-10-28", logMap([]));
    expect(info.warning).toBe("short");
    expect(info.missing).toBe(2);
  });
  it("does not warn when enough", () => {
    expect(stockInfo(med({ stock: 7, endDate: "2026-11-03" }), "2026-10-28", logMap([])).warning).toBeNull();
  });
  it("warns low for ongoing medicine with ≤3 days left", () => {
    expect(stockInfo(med({ stock: 3 }), "2026-10-28", logMap([])).warning).toBe("low");
    expect(stockInfo(med({ stock: 30 }), "2026-10-28", logMap([])).warning).toBeNull();
    expect(stockInfo(med({ stock: null }), "2026-10-28", logMap([])).warning).toBeNull();
  });
});

describe("reminder planning", () => {
  const now = new Date(2026, 9, 28, 9, 0);

  it("plans repeating reminders for ongoing medicine and water", () => {
    const d = emptyData();
    d.settings.profile = { name: "", age: 30, weightKg: 70, activity: "low", hotWeather: false };
    d.medicines = [med({ slots: [{ id: "a", label: "", time: "08:00", qty: 1 }, { id: "b", label: "", time: "20:00", qty: 1 }] })];
    const plan = planReminders(d, now);
    const meds = plan.filter((n) => n.kind === "med");
    expect(meds).toHaveLength(2);
    expect(meds.every((n) => n.on && !n.at)).toBe(true);
    expect(plan.filter((n) => n.kind === "water").length).toBeGreaterThanOrEqual(8);
    expect(new Set(plan.map((n) => n.id)).size).toBe(plan.length);
  });

  it("plans one weekly reminder per weekday (Sunday = 1)", () => {
    const d = emptyData();
    d.settings.water.remindersOn = false;
    d.medicines = [med({ weekdays: [0, 3] })];
    const meds = planReminders(d, now).filter((n) => n.kind === "med");
    expect(meds.map((n) => n.on?.weekday).sort()).toEqual([1, 4]);
  });

  it("plans dated one-off reminders only in the future", () => {
    const d = emptyData();
    d.settings.water.remindersOn = false;
    d.medicines = [med({ endDate: "2026-10-30" })]; // 28th 08:00 already passed at 09:00
    const meds = planReminders(d, now).filter((n) => n.kind === "med");
    expect(meds).toHaveLength(2); // 29th and 30th
    expect(meds.every((n) => n.at && n.at.getTime() > now.getTime())).toBe(true);
  });

  it("includes active snoozes and skips inactive/disabled", () => {
    const d = emptyData();
    d.settings.water.remindersOn = false;
    d.medicines = [med()];
    d.snoozes = [{ id: "z", kind: "med" as const, refId: "m1", slotId: "morning", date: "2026-10-28", time: "08:00", at: new Date(2026, 9, 28, 9, 10).toISOString() }];
    expect(planReminders(d, now).filter((n) => n.extra.snooze === "1")).toHaveLength(1);
    d.settings.medRemindersOn = false;
    expect(planReminders(d, now).filter((n) => n.kind === "med")).toHaveLength(0);
  });

  it("keeps the total under the Android alarm limit", () => {
    const d = emptyData();
    d.settings.water.remindersOn = false;
    d.medicines = Array.from({ length: 30 }, (_, i) =>
      med({ id: `m${i}`, endDate: "2026-12-31", slots: [1, 2, 3, 4].map((n) => ({ id: `s${n}`, label: "", time: `0${n}:00`, qty: 1 })) }),
    );
    expect(planReminders(d, now).length).toBeLessThanOrEqual(400);
  });
});

describe("diary stats", () => {
  const e = (entryDate: string, mood = "good") => ({ id: entryDate, title: "", content: "x", mood, tags: [], favorite: false, attachments: [], entryDate, createdAt: "", updatedAt: "" });
  it("counts streak from yesterday when today is empty", () => {
    const s = diaryStats([e("2026-10-27"), e("2026-10-26"), e("2026-10-24")], "2026-10-28");
    expect(s.streak).toBe(2);
    expect(s.entriesThisMonth).toBe(3);
  });
  it("counts today too", () => {
    expect(diaryStats([e("2026-10-28"), e("2026-10-27")], "2026-10-28").streak).toBe(2);
    expect(diaryStats([], "2026-10-28").streak).toBe(0);
  });
});

describe("normalizeData", () => {
  it("survives garbage and fills defaults", () => {
    const d = normalizeData({ entries: [null, { content: "" }, { content: "hello", entryDate: "bad" }], medicines: [{ name: "x" }], settings: 5 });
    expect(d.entries).toHaveLength(1);
    expect(isValidDateKey(d.entries[0].entryDate)).toBe(true);
    expect(d.medicines).toHaveLength(0);
    expect(d.containers.length).toBeGreaterThan(0);
    expect(normalizeData("nope").entries).toEqual([]);
  });
  it("round-trips valid data", () => {
    const d = emptyData();
    d.medicines = [med()];
    const again = normalizeData(JSON.parse(JSON.stringify(d)));
    expect(again.medicines[0].name).toBe("নাপা");
    expect(again.settings).toEqual(d.settings);
  });
});
