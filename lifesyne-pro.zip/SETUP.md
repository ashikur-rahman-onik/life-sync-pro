# LifeSyne Pro — Firebase, APK বিল্ড ও আপডেট গাইড

## ১) Firebase সেটআপ (একবার, প্রজেক্ট: lifesyne-pro)
1. **Authentication → Get started → Sign-in method → Email/Password → Enable**।
2. **Firestore Database → Create database** (Production mode, Region: asia-south1 বা asia-southeast1)।
3. **Firestore → Rules** ট্যাবে নিচেরটা পেস্ট করে **Publish**:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```
(এই লেখা অ্যাপের সেটিংস → "Firestore Rules" থেকেও কপি করা যায়।)

## ১.৫) Cloudinary (ছবি/ফাইলের জন্য, একবার)
1. cloudinary.com-এ লগইন করে ড্যাশবোর্ড থেকে **Cloud name** দেখুন।
2. Settings → Upload → Upload presets → Add upload preset → **Signing mode: Unsigned** → Save, preset-এর নাম মনে রাখুন।
3. অ্যাপের **সেটিংস → ফাইল স্টোরেজ**-এ Cloud name ও Upload preset বসিয়ে **সেভ** ও **সংযোগ টেস্ট** চাপুন।

## ২) GitHub থেকে APK বিল্ড (ফোন থেকেই করা যায়)
1. GitHub-এ **Public** repository বানান (আপডেট চেকের জন্য Public লাগবে — কোডে কোনো পাসওয়ার্ড নেই, সাইনিং কী থাকে Secrets-এ)।
2. repo-র root-এ `lifesyne-pro.zip` আপলোড করুন।
3. **Add file → Create new file** → নাম `.github/workflows/build.yml` → `build.yml`-এর লেখা পেস্ট করে Commit করুন।
4. **Settings → Secrets and variables → Actions** থেকে `KEYSTORE-SECRETS.txt`-এর ২টি Secret যোগ করুন।
5. **Actions → Build APK → Run workflow**। ৫–১০ মিনিট পর **Releases** পেজ থেকে `lifesyne-pro.apk` নামিয়ে প্রথমবার ইনস্টল করুন।

## ৩) পরের আপডেট
নতুন zip একই নামে আপলোড (replace) করে commit করুন → APK নিজে বিল্ড হয়ে Release-এ যাবে → ফোনে অ্যাপ খুললে **"নতুন আপডেট পাওয়া গেছে"** দেখাবে → **এখনই আপডেট করুন** চাপুন। আনইনস্টল লাগবে না, ডেটা ঠিক থাকবে (ডেটা Firebase-এও আছে)।

## জরুরি
- সব বিল্ড একই সাইনিং কী দিয়ে সাইন হয়, তাই আপডেট পুরনো অ্যাপের উপর বসে। কী/Secret হারাবেন না।
- ডেটা Firestore-এ জমা হয়; ইন্টারনেট না থাকলে ফোনে সেভ থাকে, অনলাইনে এলে নিজে সিঙ্ক হয়।
