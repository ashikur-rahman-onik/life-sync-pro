export interface DiaryEntry {
  id: string;
  title: string;
  content: string;
  mood: string;
  tags: string[];
  entryDate: string; // YYYY-MM-DD (local)
  createdAt: string; // ISO
  updatedAt: string; // ISO
}

export type Activity = "low" | "moderate" | "high";

export interface Profile {
  name: string;
  age: number | null;
  weightKg: number | null;
  activity: Activity;
  hotWeather: boolean;
}

export interface Container {
  id: string;
  name: string;
  ml: number;
  icon: string;
}

export interface WaterLog {
  id: string;
  date: string; // YYYY-MM-DD (local)
  at: string; // ISO
  ml: number;
  containerName: string;
}

export type MedForm = "tablet" | "capsule" | "syrup" | "injection" | "drops" | "other";
export type MealRelation = "before" | "after" | "with" | "any";

export interface DoseSlot {
  id: string;
  label: string; // সকাল / দুপুর / রাত / ঘুমানোর আগে / custom
  time: string; // HH:MM
  qty: number; // units per dose (tablets, ml, drops…)
}

export interface Medicine {
  id: string;
  name: string;
  form: MedForm;
  slots: DoseSlot[];
  relation: MealRelation;
  startDate: string;
  endDate: string | null; // null = ongoing
  weekdays: number[]; // 0=Sun … 6=Sat; empty = every day
  stock: number | null; // remaining units, null = not tracked
  notes: string;
  doctor: string;
  prescriptionId: string | null;
  active: boolean;
  createdAt: string;
}

export interface Prescription {
  id: string;
  doctor: string;
  date: string;
  note: string;
  createdAt: string;
}

export interface DoseLog {
  id: string;
  key: string; // medicineId|slotId|date
  medicineId: string;
  medicineName: string;
  slotId: string;
  date: string;
  status: "taken" | "skipped";
  at: string; // ISO
  qty: number;
}

export interface Snooze {
  id: string;
  medicineId: string;
  slotId: string;
  date: string;
  time: string; // original slot time HH:MM
  at: string; // ISO — when the snoozed reminder fires
}

export interface Settings {
  profile: Profile;
  water: {
    goalOverrideMl: number | null;
    wake: string;
    sleep: string;
    remindersOn: boolean;
    defaultContainerId: string | null;
  };
  meals: { breakfast: string; lunch: string; dinner: string; bed: string };
  medRemindersOn: boolean;
  diaryReminder: { on: boolean; time: string };
}

export interface AppData {
  version: 1;
  settings: Settings;
  entries: DiaryEntry[];
  containers: Container[];
  waterLogs: WaterLog[];
  medicines: Medicine[];
  prescriptions: Prescription[];
  doseLogs: DoseLog[];
  snoozes: Snooze[];
}
