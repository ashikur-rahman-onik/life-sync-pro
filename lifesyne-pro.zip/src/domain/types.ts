export interface DiaryEntry {
  id: string;
  title: string;
  content: string;
  mood: string;
  tags: string[];
  entryDate: string; // YYYY-MM-DD (local)
  createdAt: string; // ISO
  updatedAt: string; // ISO
}

export type Activity = "low" | "moderate" | "high";

export interface Profile {
  name: string;
  age: number | null;
  weightKg: number | null;
  activity: Activity;
  hotWeather: boolean;
}

export interface Container {
  id: string;
  name: string;
  ml: number;
  icon: string;
}

export interface WaterLog {
  id: string;
  date: string; // YYYY-MM-DD (local)
  at: string; // ISO
  ml: number;
  containerName: string;
}

export type MedForm = "tablet" | "capsule" | "syrup" | "injection" | "drops" | "other";
export type MealRelation = "before" | "after" | "with" | "any";

export interface DoseSlot {
  id: string;
  label: string; // সকাল / দুপুর / রাত / ঘুমানোর আগে / custom
  time: string; // HH:MM
  qty: number; // units per dose (tablets, ml, drops…)
}

export interface Medicine {
  id: string;
  name: string;
  form: MedForm;
  slots: DoseSlot[];
  relation: MealRelation;
  startDate: string;
  endDate: string | null; // null = ongoing
  weekdays: number[]; // 0=Sun … 6=Sat; empty = every day
  stock: number | null; // remaining units, null = not tracked
  notes: string;
  doctor: string;
  prescriptionId: string | null;
  active: boolean;
  createdAt: string;
}

export interface Prescription {
  id: string;
  doctor: string;
  date: string;
  note: string;
  createdAt: string;
}

export interface DoseLog {
  id: string;
  key: string; // medicineId|slotId|date
  medicineId: string;
  medicineName: string;
  slotId: string;
  date: string;
  status: "taken" | "skipped";
  at: string; // ISO
  qty: number;
}

export interface Snooze {
  id: string;
  kind: "med" | "reminder";
  refId: string; // medicine id or reminder id
  slotId: string; // medicine slot id, or the reminder time (HH:MM)
  date: string;
  time: string; // original time HH:MM
  at: string; // ISO — when the snoozed reminder fires
}

/* ---------- custom reminders & alarms ---------- */

/** normal = phone's default sound, chime = soft tune, alarm = long loud alarm tone */
export type NotifyStyle = "normal" | "chime" | "alarm";
export type RepeatType = "once" | "daily" | "weekly" | "monthly" | "yearly" | "interval";

export interface Category {
  id: string;
  name: string;
  icon: string;
}

export interface Reminder {
  id: string;
  title: string;
  note: string;
  icon: string;
  categoryId: string;
  type: RepeatType;
  date: string; // once: the date · others: first day (also gives the day of month / year for monthly & yearly)
  times: string[]; // HH:MM, one or more per day
  weekdays: number[]; // weekly: 0=Sun … 6=Sat (empty = weekday of `date`)
  intervalDays: number; // interval: every N days
  endDate: string | null;
  style: NotifyStyle;
  snoozeMin: number;
  earlyMin: number; // extra heads-up N minutes before (0 = off)
  active: boolean;
  createdAt: string;
}

export interface ReminderLog {
  id: string; // = key
  key: string; // reminderId|time|date
  reminderId: string;
  title: string;
  date: string;
  time: string;
  status: "done" | "skipped";
  at: string;
}

export interface Habit {
  id: string;
  name: string;
  icon: string;
  color: string;
  target: number; // times per day needed to count as done
  weekdays: number[]; // empty = every day
  times: string[]; // reminder times
  reminderOn: boolean;
  style: NotifyStyle;
  startDate: string;
  archived: boolean;
  createdAt: string;
}

export interface HabitLog {
  id: string; // = key
  key: string; // habitId|date
  habitId: string;
  date: string;
  count: number;
}

export type WaterMode = "even" | "interval" | "custom";

export interface Settings {
  profile: Profile;
  water: {
    goalOverrideMl: number | null;
    wake: string;
    sleep: string;
    remindersOn: boolean;
    defaultContainerId: string | null;
    mode: WaterMode; // even = spread by goal · interval = every N minutes · custom = my own times
    intervalMin: number;
    customTimes: string[];
  };
  notify: {
    medStyle: NotifyStyle;
    waterStyle: NotifyStyle;
    diaryStyle: NotifyStyle;
    reminderStyle: NotifyStyle; // default for new reminders
    medSnoozeMin: number;
    medEarlyMin: number; // heads-up before a dose (0 = off)
    medFollowUps: number; // how many "did you take it?" nudges (0 = off)
    medFollowEveryMin: number;
  };
  categories: Category[];
  showQuotes: boolean;
  meals: { breakfast: string; lunch: string; dinner: string; bed: string };
  medRemindersOn: boolean;
  diaryReminder: { on: boolean; time: string };
}

export interface AppData {
  version: 1;
  settings: Settings;
  entries: DiaryEntry[];
  containers: Container[];
  waterLogs: WaterLog[];
  medicines: Medicine[];
  prescriptions: Prescription[];
  doseLogs: DoseLog[];
  snoozes: Snooze[];
  reminders: Reminder[];
  reminderLogs: ReminderLog[];
  habits: Habit[];
  habitLogs: HabitLog[];
}
