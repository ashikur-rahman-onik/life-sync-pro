import { todayKey } from "@/lib/date";
import { uid } from "@/lib/id";
import { buildPresetSlots } from "./medicine";
import type { Medicine, Settings } from "./types";

export function newMedicine(settings: Settings, over: Partial<Medicine> = {}): Medicine {
  const relation = over.relation ?? "after";
  return {
    id: uid(),
    name: "",
    form: "tablet",
    slots: buildPresetSlots({ morning: 1, noon: 0, night: 0, bed: 0 }, settings.meals, relation),
    relation,
    startDate: todayKey(),
    endDate: null,
    weekdays: [],
    stock: null,
    notes: "",
    doctor: "",
    prescriptionId: null,
    active: true,
    createdAt: new Date().toISOString(),
    ...over,
  };
}
