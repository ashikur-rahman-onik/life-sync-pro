import { timeToMinutes } from "@/lib/date";
import { isDone, isScheduled, habitKey, habitLogMap } from "./habits";
import { doseKey, dosesForDate, FORM_ICONS, formatDose, logMap, RELATION_LABELS, timeStatus, type DoseStatus } from "./medicine";
import { occurrenceDates } from "./schedule";
import { effectiveWaterGoal } from "./reminders";
import { waterTotalForDate } from "./water";
import type { AppData, Habit, Medicine, DoseSlot, Reminder } from "./types";

export type AgendaItem =
  | { kind: "med"; key: string; time: string; status: DoseStatus; title: string; subtitle: string; icon: string; medicine: Medicine; slot: DoseSlot; date: string }
  | { kind: "reminder"; key: string; time: string; status: DoseStatus; title: string; subtitle: string; icon: string; reminder: Reminder; date: string }
  | { kind: "habit"; key: string; time: null; status: "done" | "open"; title: string; subtitle: string; icon: string; habit: Habit; count: number; date: string };

/** Everything planned for `today`: medicine doses, reminders and habits, in time order. */
export function buildAgenda(data: AppData, today: string, nowMin: number): AgendaItem[] {
  const items: AgendaItem[] = [];

  const doseLogs = logMap(data.doseLogs);
  for (const d of dosesForDate(data.medicines, today)) {
    items.push({
      kind: "med",
      key: d.key,
      time: d.time,
      status: timeStatus(today, d.time, doseLogs.get(d.key)?.status, today, nowMin),
      title: d.medicine.name,
      subtitle: `${formatDose(d.slot.qty, d.medicine.form)}${d.medicine.relation !== "any" ? ` · ${RELATION_LABELS[d.medicine.relation]}` : ""}`,
      icon: FORM_ICONS[d.medicine.form],
      medicine: d.medicine,
      slot: d.slot,
      date: today,
    });
  }

  const reminderLogs = new Map(data.reminderLogs.map((l) => [l.key, l.status]));
  for (const r of data.reminders) {
    if (occurrenceDates(r, today, today).length === 0) continue;
    for (const time of r.times) {
      const key = `${r.id}|${time}|${today}`;
      items.push({ kind: "reminder", key, time, status: timeStatus(today, time, reminderLogs.get(key), today, nowMin), title: r.title, subtitle: r.note, icon: r.icon, reminder: r, date: today });
    }
  }

  const counts = habitLogMap(data.habitLogs);
  const habits: AgendaItem[] = [];
  for (const h of data.habits) {
    if (!isScheduled(h, today)) continue;
    const count = counts.get(habitKey(h.id, today)) ?? 0;
    habits.push({ kind: "habit", key: `${h.id}|${today}`, time: null, status: isDone(h, count) ? "done" : "open", title: h.name, subtitle: h.target > 1 ? `${count}/${h.target}` : "", icon: h.icon, habit: h, count, date: today });
  }

  items.sort((a, b) => timeToMinutes((a as { time: string }).time) - timeToMinutes((b as { time: string }).time));
  return [...items, ...habits];
}

export const isFinished = (i: AgendaItem): boolean => i.status === "taken" || i.status === "skipped" || i.status === "done";

export interface DayScore {
  percent: number | null;
  parts: { label: string; icon: string; percent: number }[];
}

/** Average of today's water, medicine, habit and diary progress (only the parts that apply). */
export function dayScore(data: AppData, today: string): DayScore {
  const parts: DayScore["parts"] = [];

  const goal = effectiveWaterGoal(data.settings);
  if (goal !== null) parts.push({ label: "পানি", icon: "💧", percent: Math.min(100, Math.round((waterTotalForDate(data.waterLogs, today) / goal) * 100)) });

  const doses = dosesForDate(data.medicines, today);
  if (doses.length > 0) {
    const logs = logMap(data.doseLogs);
    const taken = doses.filter((d) => logs.get(doseKey(d.medicine.id, d.slot.id, today))?.status === "taken").length;
    parts.push({ label: "ওষুধ", icon: "💊", percent: Math.round((taken / doses.length) * 100) });
  }

  const habits = data.habits.filter((h) => isScheduled(h, today));
  if (habits.length > 0) {
    const counts = habitLogMap(data.habitLogs);
    const done = habits.filter((h) => isDone(h, counts.get(habitKey(h.id, today)) ?? 0)).length;
    parts.push({ label: "অভ্যাস", icon: "🔁", percent: Math.round((done / habits.length) * 100) });
  }

  parts.push({ label: "ডায়েরি", icon: "📔", percent: data.entries.some((e) => e.entryDate === today) ? 100 : 0 });

  const percent = parts.length === 0 ? null : Math.round(parts.reduce((s, p) => s + p.percent, 0) / parts.length);
  return { percent, parts };
}
