import type { Attachment, DiaryEntry } from "./types";

/**
 * Splits `text` into chunks that each fit on one book page.
 * `measure(s)` returns the rendered height of `s`; `firstMax` / `restMax` are the heights available
 * on the first page (it carries the date and title) and on the following pages.
 */
export function paginate(text: string, measure: (s: string) => number, firstMax: number, restMax: number): string[] {
  const out: string[] = [];
  let rest = text;
  let limit = firstMax;

  while (rest.length > 0) {
    if (measure(rest) <= limit) {
      out.push(rest);
      break;
    }
    // end index (exclusive) of every word, including the whitespace after it
    const ends: number[] = [];
    for (const m of rest.matchAll(/\S+\s*/g)) ends.push((m.index ?? 0) + m[0].length);

    let fit = -1;
    let a = 0;
    let b = ends.length - 1;
    while (a <= b) {
      const mid = (a + b) >> 1;
      if (measure(rest.slice(0, ends[mid])) <= limit) {
        fit = mid;
        a = mid + 1;
      } else b = mid - 1;
    }

    let cut = fit >= 0 ? ends[fit] : 0;
    if (cut === 0) {
      // a single very long word: cut it by characters
      let lo = 1;
      let hi = Math.max(1, rest.length - 1);
      cut = 1;
      while (lo <= hi) {
        const mid = (lo + hi) >> 1;
        if (measure(rest.slice(0, mid)) <= limit) {
          cut = mid;
          lo = mid + 1;
        } else hi = mid - 1;
      }
    }
    out.push(rest.slice(0, cut).replace(/\s+$/, ""));
    rest = rest.slice(cut).replace(/^\s+/, "");
    limit = restMax;
  }
  return out.length > 0 ? out : [""];
}

/** How many photos fit on the last text page, and how the rest are grouped onto photo pages. */
export function splitPhotos<T>(items: T[], capacityOnTextPage: number, perPage: number): { onTextPage: T[]; pages: T[][] } {
  const onTextPage = items.slice(0, Math.max(0, capacityOnTextPage));
  const rest = items.slice(onTextPage.length);
  const pages: T[][] = [];
  for (let i = 0; i < rest.length; i += perPage) pages.push(rest.slice(i, i + perPage));
  return { onTextPage, pages };
}

export interface PageSpec {
  entry: DiaryEntry;
  kind: "text" | "photos" | "files";
  /** 0-based position inside this diary entry */
  index: number;
  total: number;
  isFirst: boolean;
  text: string;
  photos: Attachment[];
  files: Attachment[];
}

export interface PageLayout {
  /** height of text on a page, per line count */
  measure: (s: string) => number;
  lineHeight: number;
  /** lines available for text on a page without a header */
  restLines: number;
  /** a polaroid row (photo + gap) and photos per row */
  photoFootprint: number;
  photosPerRow: number;
  photosPerPage: number;
}

/** Lines used by the date/mood block and the title at the top of an entry's first page. */
export function headerLines(title: string): number {
  const titleLines = title.trim() === "" ? 0 : title.trim().length > 18 ? 2 : 1;
  return 2 + titleLines;
}

/** All book pages of one diary entry: text pages, photos (on the last text page when they fit), then extra photo/file pages. */
export function buildEntryPages(entry: DiaryEntry, layout: PageLayout): PageSpec[] {
  const { lineHeight: lh, restLines } = layout;
  const firstLines = Math.max(2, restLines - headerLines(entry.title));
  const firstMax = firstLines * lh + 1;
  const restMax = Math.max(3, restLines) * lh + 1;

  const chunks = paginate(entry.content, layout.measure, firstMax, restMax);
  const lastMax = chunks.length === 1 ? firstMax : restMax;
  const used = entry.content.trim() === "" ? 0 : layout.measure(chunks[chunks.length - 1]);
  const free = lastMax - used - lh * 0.5;
  const rows = Math.max(0, Math.floor(free / layout.photoFootprint));

  const images = entry.attachments.filter((a) => a.kind === "image");
  const files = entry.attachments.filter((a) => a.kind !== "image");
  const { onTextPage, pages: photoPages } = splitPhotos(images, rows * layout.photosPerRow, layout.photosPerPage);

  const specs: Omit<PageSpec, "index" | "total" | "isFirst">[] = chunks.map((text, i) => ({
    entry,
    kind: "text",
    text,
    photos: i === chunks.length - 1 ? onTextPage : [],
    files: [],
  }));
  for (const photos of photoPages) specs.push({ entry, kind: "photos", text: "", photos, files: [] });
  if (files.length > 0) specs.push({ entry, kind: "files", text: "", photos: [], files });

  return specs.map((s, i) => ({ ...s, index: i, total: specs.length, isFirst: i === 0 }));
}
