import type { AppData, Attachment } from "./types";

/** Every attachment in the app (diary pages, vault, diary cover). */
export function allAttachments(data: AppData): Attachment[] {
  const list: Attachment[] = [];
  for (const e of data.entries) list.push(...e.attachments);
  for (const v of data.vault) list.push(...v.attachments);
  if (data.settings.diary.coverImage) list.push(data.settings.diary.coverImage);
  return list;
}

/** Attachments saved only on this phone so far. */
export const pendingAttachments = (data: AppData): Attachment[] => allAttachments(data).filter((a) => a.url === null && a.localKey !== null);

/** Replaces fields of the attachment with this id wherever it is used. */
export function patchAttachmentIn(data: AppData, id: string, patch: Partial<Attachment>): AppData {
  const fix = (list: Attachment[]) => (list.some((a) => a.id === id) ? list.map((a) => (a.id === id ? { ...a, ...patch } : a)) : list);
  const cover = data.settings.diary.coverImage;
  return {
    ...data,
    entries: data.entries.map((e) => (e.attachments.some((a) => a.id === id) ? { ...e, attachments: fix(e.attachments) } : e)),
    vault: data.vault.map((v) => (v.attachments.some((a) => a.id === id) ? { ...v, attachments: fix(v.attachments) } : v)),
    settings: cover?.id === id ? { ...data.settings, diary: { ...data.settings.diary, coverImage: { ...cover, ...patch } } } : data.settings,
  };
}

export const formatBytes = (bytes: number): string => (bytes >= 1024 * 1024 ? `${(bytes / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`);
