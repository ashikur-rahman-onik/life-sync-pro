import { addDays, diffDays, weekdayOf } from "@/lib/date";
import type { Habit, HabitLog } from "./types";

export const habitKey = (habitId: string, date: string): string => `${habitId}|${date}`;

export function habitLogMap(logs: HabitLog[]): Map<string, number> {
  return new Map(logs.map((l) => [l.key, l.count]));
}

export function isScheduled(h: Habit, date: string): boolean {
  if (h.archived || date < h.startDate) return false;
  return h.weekdays.length === 0 || h.weekdays.includes(weekdayOf(date));
}

export const isDone = (h: Habit, count: number): boolean => count >= h.target;

export interface HabitStats {
  streak: number;
  best: number;
  rate30: number | null; // % of scheduled days done in the last 30 days
  last14: { date: string; state: "done" | "missed" | "off" | "pending" }[];
}

const MAX_SCAN = 730;

export function habitStats(h: Habit, counts: Map<string, number>, today: string): HabitStats {
  const done = (date: string) => isDone(h, counts.get(habitKey(h.id, date)) ?? 0);

  // current streak: consecutive scheduled days done, ending today (or yesterday if today is still open)
  let streak = 0;
  let cursor = isScheduled(h, today) && !done(today) ? addDays(today, -1) : today;
  for (let i = 0; i < MAX_SCAN && cursor >= h.startDate; i++, cursor = addDays(cursor, -1)) {
    if (!isScheduled(h, cursor)) continue;
    if (!done(cursor)) break;
    streak++;
  }

  // best streak over the whole history
  let best = 0;
  let run = 0;
  const startScan = diffDays(h.startDate, today) > MAX_SCAN ? addDays(today, -MAX_SCAN) : h.startDate;
  for (let d = startScan; d <= today; d = addDays(d, 1)) {
    if (!isScheduled(h, d)) continue;
    if (done(d)) {
      run++;
      best = Math.max(best, run);
    } else if (d !== today) {
      run = 0;
    }
  }

  let scheduled = 0;
  let completed = 0;
  for (let i = 0; i < 30; i++) {
    const d = addDays(today, -i);
    if (!isScheduled(h, d)) continue;
    if (d === today && !done(d)) continue;
    scheduled++;
    if (done(d)) completed++;
  }

  const last14 = Array.from({ length: 14 }, (_, i) => {
    const date = addDays(today, i - 13);
    const state: HabitStats["last14"][number]["state"] = !isScheduled(h, date) ? "off" : done(date) ? "done" : date === today ? "pending" : "missed";
    return { date, state };
  });

  return { streak, best, rate30: scheduled === 0 ? null : Math.round((completed / scheduled) * 100), last14 };
}
