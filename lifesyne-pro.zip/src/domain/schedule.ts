import { formatDateBn, formatTimeBn, MONTHS_BN, toBn, WEEKDAYS_SHORT_BN } from "@/lib/bn";
import { addDays, diffDays, parseDateKey, pad, weekdayOf } from "@/lib/date";
import type { Reminder, RepeatType } from "./types";

export const REPEAT_LABELS: Record<RepeatType, string> = {
  once: "একবার",
  daily: "প্রতিদিন",
  weekly: "সপ্তাহে",
  monthly: "প্রতি মাসে",
  yearly: "প্রতি বছর",
  interval: "কয়েক দিন পরপর",
};

const MAX_SCAN_DAYS = 800;

export const daysInMonth = (year: number, month: number): number => new Date(year, month, 0).getDate();

const keyOf = (y: number, m: number, d: number): string => `${y}-${pad(m)}-${pad(d)}`;

/** Weekdays a weekly reminder fires on (falls back to the weekday of its start date). */
export function effectiveWeekdays(r: Pick<Reminder, "weekdays" | "date">): number[] {
  return r.weekdays.length > 0 ? r.weekdays : [weekdayOf(r.date)];
}

/**
 * Dates (inclusive range, ascending) on which the reminder happens.
 * Monthly reminders on the 31st fire on the last day of shorter months;
 * a yearly 29 Feb fires on 28 Feb in non-leap years.
 */
export function occurrenceDates(r: Reminder, from: string, to: string): string[] {
  if (!r.active) return [];
  if (r.type === "once") return r.date >= from && r.date <= to ? [r.date] : [];

  const first = from > r.date ? from : r.date;
  const last = r.endDate !== null && r.endDate < to ? r.endDate : to;
  if (first > last) return [];
  const span = Math.min(diffDays(first, last), MAX_SCAN_DAYS);
  const stop = addDays(first, span);
  const out: string[] = [];

  switch (r.type) {
    case "daily":
      for (let d = first; d <= stop; d = addDays(d, 1)) out.push(d);
      break;
    case "weekly": {
      const days = effectiveWeekdays(r);
      for (let d = first; d <= stop; d = addDays(d, 1)) if (days.includes(weekdayOf(d))) out.push(d);
      break;
    }
    case "interval": {
      const n = Math.max(1, r.intervalDays);
      const k = Math.ceil(diffDays(r.date, first) / n);
      for (let d = addDays(r.date, k * n); d <= stop; d = addDays(d, n)) out.push(d);
      break;
    }
    case "monthly": {
      const day = parseDateKey(r.date).getDate();
      const f = parseDateKey(first);
      const l = parseDateKey(stop);
      for (let y = f.getFullYear(), m = f.getMonth() + 1; y < l.getFullYear() || (y === l.getFullYear() && m <= l.getMonth() + 1); m === 12 ? (y++, (m = 1)) : m++) {
        const d = keyOf(y, m, Math.min(day, daysInMonth(y, m)));
        if (d >= first && d <= stop) out.push(d);
      }
      break;
    }
    case "yearly": {
      const start = parseDateKey(r.date);
      const month = start.getMonth() + 1;
      const day = start.getDate();
      for (let y = parseDateKey(first).getFullYear(); y <= parseDateKey(stop).getFullYear(); y++) {
        const d = keyOf(y, month, Math.min(day, daysInMonth(y, month)));
        if (d >= first && d <= stop) out.push(d);
      }
      break;
    }
  }
  return out;
}

export const occursOn = (r: Reminder, date: string): boolean => occurrenceDates(r, date, date).length > 0;

/** Rarely-repeating reminders are scheduled far ahead; busy ones only a couple of weeks. */
export function isSparse(r: Reminder): boolean {
  return r.type === "once" || r.type === "monthly" || r.type === "yearly" || (r.type === "interval" && r.intervalDays >= 7);
}

/** Next date on/after `from` when the reminder happens, or null. */
export function nextDate(r: Reminder, from: string): string | null {
  const end = r.type === "yearly" ? addDays(from, 370) : addDays(from, MAX_SCAN_DAYS);
  return occurrenceDates(r, from, end)[0] ?? null;
}

/** "আজ" / "কাল" / "N দিন পর" helper input. */
export const daysUntil = (from: string, to: string): number => diffDays(from, to);

/** Human-readable schedule, e.g. "প্রতি মাসে ৫ তারিখে · সকাল ১০:০০". */
export function describeSchedule(r: Reminder): string {
  const times = r.times.map(formatTimeBn).join(", ");
  const d = parseDateKey(r.date);
  let when: string;
  switch (r.type) {
    case "once":
      when = formatDateBn(r.date, { weekday: true });
      break;
    case "daily":
      when = "প্রতিদিন";
      break;
    case "weekly":
      when = `প্রতি ${effectiveWeekdays(r).map((w) => WEEKDAYS_SHORT_BN[w]).join(", ")}`;
      break;
    case "monthly":
      when = `প্রতি মাসের ${toBn(d.getDate())} তারিখে`;
      break;
    case "yearly":
      when = `প্রতি বছর ${toBn(d.getDate())} ${MONTHS_BN[d.getMonth()]}`;
      break;
    default:
      when = `প্রতি ${toBn(r.intervalDays)} দিন পরপর`;
  }
  return `${when} · ${times}`;
}

/** "আজ", "কাল", "৫ দিন পর" */
export function countdownLabel(from: string, to: string): string {
  const n = diffDays(from, to);
  return n === 0 ? "আজ" : n === 1 ? "কাল" : `${toBn(n)} দিন পর`;
}
