import type { Reminder } from "./types";

export interface ReminderTemplate {
  label: string;
  patch: Partial<Pick<Reminder, "title" | "icon" | "type" | "times" | "categoryId" | "style" | "earlyMin" | "weekdays">>;
}

/** One-tap starting points for the reminder form. */
export const REMINDER_TEMPLATES: ReminderTemplate[] = [
  { label: "⏰ অ্যালার্ম ঘড়ি", patch: { title: "ঘুম থেকে ওঠা", icon: "⏰", type: "daily", times: ["06:00"], style: "alarm", categoryId: "personal" } },
  { label: "🎂 জন্মদিন", patch: { title: "জন্মদিন", icon: "🎂", type: "yearly", times: ["09:00"], style: "chime", categoryId: "family", earlyMin: 1440 } },
  { label: "💡 মাসিক বিল", patch: { title: "বিল দেওয়া", icon: "💡", type: "monthly", times: ["10:00"], categoryId: "money", earlyMin: 1440 } },
  { label: "📅 মিটিং", patch: { title: "মিটিং", icon: "📅", type: "once", times: ["10:00"], categoryId: "work", earlyMin: 30 } },
  { label: "🏃 রোজ ব্যায়াম", patch: { title: "ব্যায়াম", icon: "🏃", type: "daily", times: ["06:30"], categoryId: "health" } },
  { label: "😴 ঘুমানোর সময়", patch: { title: "ঘুমাতে যান", icon: "😴", type: "daily", times: ["22:30"], style: "chime", categoryId: "health" } },
  { label: "🔌 ফোন চার্জ", patch: { title: "ফোন চার্জে দিন", icon: "🔌", type: "daily", times: ["21:00"], categoryId: "personal" } },
  { label: "🧹 সাপ্তাহিক পরিষ্কার", patch: { title: "ঘর পরিষ্কার", icon: "🧹", type: "weekly", weekdays: [5], times: ["09:00"], categoryId: "family" } },
];

export interface HabitTemplate {
  name: string;
  icon: string;
  color: string;
  target: number;
  times: string[];
}

export const HABIT_TEMPLATES: HabitTemplate[] = [
  { name: "পানি পান", icon: "💧", color: "#3b9ae1", target: 8, times: [] },
  { name: "ব্যায়াম", icon: "🏃", color: "#e8762b", target: 1, times: ["06:30"] },
  { name: "বই পড়া", icon: "📖", color: "#7c5cd6", target: 1, times: ["21:00"] },
  { name: "হাঁটা", icon: "🚶", color: "#16a05d", target: 1, times: ["17:30"] },
  { name: "মেডিটেশন", icon: "🧘", color: "#0e9aa7", target: 1, times: ["06:00"] },
  { name: "ফল খাওয়া", icon: "🍎", color: "#e0508f", target: 1, times: [] },
  { name: "আগে ঘুমানো", icon: "😴", color: "#2b7de9", target: 1, times: ["22:30"] },
  { name: "কৃতজ্ঞতা লেখা", icon: "🙏", color: "#d99a1e", target: 1, times: ["21:30"] },
];

export const HABIT_COLORS = ["#2b7de9", "#16a05d", "#7c5cd6", "#e8762b", "#e0508f", "#0e9aa7", "#d99a1e", "#ef4444"];

