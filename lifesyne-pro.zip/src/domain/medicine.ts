import { addDays, addMinutesToTime, diffDays, isValidDateKey, isValidTime, timeToMinutes, weekdayOf } from "@/lib/date";
import { formatNumberHalf, toBn } from "@/lib/bn";
import type { DoseLog, DoseSlot, MealRelation, MedForm, Medicine, Settings } from "./types";

export const FORM_LABELS: Record<MedForm, string> = {
  tablet: "ট্যাবলেট",
  capsule: "ক্যাপসুল",
  syrup: "সিরাপ",
  injection: "ইনজেকশন",
  drops: "ড্রপ",
  other: "অন্যান্য",
};

export const FORM_ICONS: Record<MedForm, string> = {
  tablet: "💊",
  capsule: "💊",
  syrup: "🧪",
  injection: "💉",
  drops: "💧",
  other: "🩹",
};

export const RELATION_LABELS: Record<MealRelation, string> = {
  before: "খাবারের আগে",
  after: "খাবারের পরে",
  with: "খাবারের সাথে",
  any: "যেকোনো সময়",
};

/** Step used by the +/- buttons for each form. */
export const QTY_STEP: Record<MedForm, number> = {
  tablet: 0.5,
  capsule: 1,
  syrup: 2.5,
  injection: 1,
  drops: 1,
  other: 1,
};

export const DEFAULT_QTY: Record<MedForm, number> = {
  tablet: 1,
  capsule: 1,
  syrup: 5,
  injection: 1,
  drops: 2,
  other: 1,
};

function qtyNumber(qty: number, form: MedForm): string {
  return form === "tablet" || form === "capsule" ? formatNumberHalf(qty) : toBn(String(qty));
}

/** "১টি ট্যাবলেট", "৫ মি.লি.", "২ ফোঁটা" */
export function formatDose(qty: number, form: MedForm): string {
  const n = qtyNumber(qty, form);
  switch (form) {
    case "tablet":
      return `${n}টি ট্যাবলেট`;
    case "capsule":
      return `${n}টি ক্যাপসুল`;
    case "injection":
      return `${n}টি ইনজেকশন`;
    case "syrup":
      return `${n} মি.লি.`;
    case "drops":
      return `${n} ফোঁটা`;
    default:
      return `${n} ডোজ`;
  }
}

/** Stock label: "২০টি", "১০০ মি.লি." */
export function formatStock(stock: number, form: MedForm): string {
  const n = qtyNumber(stock, form);
  if (form === "syrup") return `${n} মি.লি.`;
  if (form === "drops") return `${n} ফোঁটা`;
  return `${n}টি`;
}

/* ------------------------------------------------------------------ */
/* Dose slots (the "১+০+১" prescription pattern)                       */
/* ------------------------------------------------------------------ */

export type PresetId = "morning" | "noon" | "night" | "bed";

export const SLOT_PRESETS: { id: PresetId; label: string; meal: keyof Settings["meals"] }[] = [
  { id: "morning", label: "সকাল", meal: "breakfast" },
  { id: "noon", label: "দুপুর", meal: "lunch" },
  { id: "night", label: "রাত", meal: "dinner" },
  { id: "bed", label: "ঘুমানোর আগে", meal: "bed" },
];

/** Minutes relative to the meal time: 30 min before, shortly after, with the meal. */
const RELATION_OFFSET_MIN: Record<MealRelation, number> = { before: -30, after: 15, with: 0, any: 0 };

export function presetSlotTime(id: PresetId, meals: Settings["meals"], relation: MealRelation): string {
  const preset = SLOT_PRESETS.find((p) => p.id === id);
  if (!preset) return "08:00";
  const base = meals[preset.meal];
  return id === "bed" ? base : addMinutesToTime(base, RELATION_OFFSET_MIN[relation]);
}

export function buildPresetSlots(
  counts: Record<PresetId, number>,
  meals: Settings["meals"],
  relation: MealRelation,
): DoseSlot[] {
  return SLOT_PRESETS.filter((p) => counts[p.id] > 0).map((p) => ({
    id: p.id,
    label: p.label,
    time: presetSlotTime(p.id, meals, relation),
    qty: counts[p.id],
  }));
}

/** Every N hours starting at `firstTime` (e.g. antibiotics every 8 hours). */
export function evenSlots(firstTime: string, everyHours: number, qty: number): DoseSlot[] {
  const count = Math.max(1, Math.floor(24 / Math.max(1, everyHours)));
  return Array.from({ length: count }, (_, i) => ({
    id: `e${i}`,
    label: "নির্দিষ্ট সময়",
    time: addMinutesToTime(firstTime, i * everyHours * 60),
    qty,
  })).sort((a, b) => timeToMinutes(a.time) - timeToMinutes(b.time));
}

/* ------------------------------------------------------------------ */
/* Planned doses & status                                              */
/* ------------------------------------------------------------------ */

export interface PlannedDose {
  key: string;
  medicine: Medicine;
  slot: DoseSlot;
  date: string;
  time: string;
}

export const doseKey = (medicineId: string, slotId: string, date: string): string => `${medicineId}|${slotId}|${date}`;

export function isActiveOn(m: Medicine, date: string): boolean {
  if (!m.active) return false;
  if (date < m.startDate) return false;
  if (m.endDate !== null && date > m.endDate) return false;
  return m.weekdays.length === 0 || m.weekdays.includes(weekdayOf(date));
}

export function dosesForDate(medicines: Medicine[], date: string): PlannedDose[] {
  const out: PlannedDose[] = [];
  for (const medicine of medicines) {
    if (!isActiveOn(medicine, date)) continue;
    for (const slot of medicine.slots) {
      out.push({ key: doseKey(medicine.id, slot.id, date), medicine, slot, date, time: slot.time });
    }
  }
  return out.sort((a, b) => timeToMinutes(a.time) - timeToMinutes(b.time) || a.medicine.name.localeCompare(b.medicine.name, "bn"));
}

export type DoseStatus = "taken" | "skipped" | "missed" | "due" | "upcoming";

/** A dose counts as "missed" this many minutes after its scheduled time. */
export const MISSED_AFTER_MIN = 120;

export function doseStatus(dose: PlannedDose, log: DoseLog | undefined, today: string, nowMin: number): DoseStatus {
  if (log) return log.status;
  if (dose.date < today) return "missed";
  if (dose.date > today) return "upcoming";
  const t = timeToMinutes(dose.time);
  if (nowMin < t) return "upcoming";
  return nowMin >= t + MISSED_AFTER_MIN ? "missed" : "due";
}

export function logMap(logs: DoseLog[]): Map<string, DoseLog> {
  return new Map(logs.map((l) => [l.key, l]));
}

export interface Adherence {
  taken: number;
  skipped: number;
  missed: number;
  percent: number | null;
}

/** Adherence over the last `days` days ending today (future/ongoing doses are ignored). */
export function adherence(medicines: Medicine[], logs: DoseLog[], today: string, days: number, nowMin: number): Adherence {
  const map = logMap(logs);
  let taken = 0;
  let skipped = 0;
  let missed = 0;
  for (let i = 0; i < days; i++) {
    const date = addDays(today, -i);
    for (const dose of dosesForDate(medicines, date)) {
      const status = doseStatus(dose, map.get(dose.key), today, nowMin);
      if (status === "taken") taken++;
      else if (status === "skipped") skipped++;
      else if (status === "missed") missed++;
    }
  }
  const total = taken + skipped + missed;
  return { taken, skipped, missed, percent: total === 0 ? null : Math.round((taken / total) * 100) };
}

/* ------------------------------------------------------------------ */
/* Course length & stock                                               */
/* ------------------------------------------------------------------ */

export const endDateFromDays = (start: string, days: number): string => addDays(start, Math.max(1, days) - 1);

export const daysInCourse = (start: string, end: string): number => diffDays(start, end) + 1;

export interface StockInfo {
  warning: "low" | "short" | null;
  daysLeft: number | null;
  missing: number;
}

export function dailyQty(m: Medicine): number {
  const perDay = m.slots.reduce((sum, s) => sum + s.qty, 0);
  const daysPerWeek = m.weekdays.length === 0 ? 7 : m.weekdays.length;
  return (perDay * daysPerWeek) / 7;
}

/** Quantity still needed until the course ends (today's untaken doses + all later days). */
function qtyNeededUntilEnd(m: Medicine, today: string, logs: Map<string, DoseLog>): number {
  if (m.endDate === null) return 0;
  let needed = 0;
  const first = m.startDate > today ? m.startDate : today;
  const last = diffDays(first, m.endDate) > 366 ? addDays(first, 366) : m.endDate;
  for (let date = first; date <= last; date = addDays(date, 1)) {
    if (!isActiveOn(m, date)) continue;
    for (const slot of m.slots) {
      if (date === today && logs.has(doseKey(m.id, slot.id, date))) continue;
      needed += slot.qty;
    }
  }
  return needed;
}

export function stockInfo(m: Medicine, today: string, logs: Map<string, DoseLog>): StockInfo {
  const none: StockInfo = { warning: null, daysLeft: null, missing: 0 };
  if (m.stock === null || !m.active) return none;

  const daily = dailyQty(m);
  const daysLeft = daily > 0 ? Math.floor(m.stock / daily) : null;

  if (m.endDate !== null) {
    if (m.endDate < today) return { ...none, daysLeft };
    const needed = qtyNeededUntilEnd(m, today, logs);
    return m.stock < needed ? { warning: "short", daysLeft, missing: needed - m.stock } : { ...none, daysLeft };
  }
  return { warning: daysLeft !== null && daysLeft <= 3 ? "low" : null, daysLeft, missing: 0 };
}

/* ------------------------------------------------------------------ */
/* Validation                                                          */
/* ------------------------------------------------------------------ */

export function validateMedicine(m: Medicine): string | null {
  if (!m.name.trim()) return "ওষুধের নাম লিখুন";
  if (m.slots.length === 0) return "কমপক্ষে একটি সময় বেছে নিন";
  for (const s of m.slots) {
    if (!isValidTime(s.time)) return "সময় সঠিক নয়";
    if (!(s.qty > 0)) return "ডোজের পরিমাণ ০ এর বেশি হতে হবে";
  }
  const times = m.slots.map((s) => s.time);
  if (new Set(times).size !== times.length) return "একই সময় দুইবার দেওয়া হয়েছে";
  if (!isValidDateKey(m.startDate)) return "শুরুর তারিখ সঠিক নয়";
  if (m.endDate !== null && (!isValidDateKey(m.endDate) || m.endDate < m.startDate)) return "শেষের তারিখ শুরুর আগে হতে পারে না";
  if (m.stock !== null && !(m.stock >= 0)) return "স্টক সঠিক নয়";
  return null;
}

export function sortSlots(slots: DoseSlot[]): DoseSlot[] {
  return [...slots].sort((a, b) => timeToMinutes(a.time) - timeToMinutes(b.time));
}

