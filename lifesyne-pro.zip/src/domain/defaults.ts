import type { AppData, Container, Settings } from "./types";

export const DEFAULT_CONTAINERS: Container[] = [
  { id: "c-small", name: "ছোট গ্লাস", ml: 150, icon: "🥛" },
  { id: "c-glass", name: "গ্লাস", ml: 250, icon: "🥛" },
  { id: "c-big", name: "বড় গ্লাস", ml: 350, icon: "🥤" },
  { id: "c-bottle", name: "ছোট বোতল", ml: 500, icon: "🧴" },
  { id: "c-liter", name: "বড় বোতল", ml: 1000, icon: "🍶" },
];

export function defaultSettings(): Settings {
  return {
    profile: { name: "", age: null, weightKg: null, activity: "low", hotWeather: true },
    water: { goalOverrideMl: null, wake: "07:00", sleep: "23:00", remindersOn: true, defaultContainerId: "c-glass" },
    meals: { breakfast: "08:00", lunch: "13:30", dinner: "21:00", bed: "22:30" },
    medRemindersOn: true,
    diaryReminder: { on: false, time: "21:30" },
  };
}

export function emptyData(): AppData {
  return {
    version: 1,
    settings: defaultSettings(),
    entries: [],
    containers: DEFAULT_CONTAINERS.map((c) => ({ ...c })),
    waterLogs: [],
    medicines: [],
    prescriptions: [],
    doseLogs: [],
    snoozes: [],
  };
}
