import { addDays } from "@/lib/date";
import { diaryStats } from "./diary";
import { habitLogMap, habitStats } from "./habits";
import { dosesForDate, logMap } from "./medicine";
import { effectiveWaterGoal } from "./reminders";
import type { AppData } from "./types";

export interface Badge {
  id: string;
  icon: string;
  title: string;
  description: string;
  progress: number;
  target: number;
}

const MAX_SCAN = 120;

/** Consecutive days (ending today, or yesterday if today is still open) where `ok(date)` is true. */
function streakOf(today: string, ok: (date: string) => boolean): number {
  let streak = 0;
  let cursor = ok(today) ? today : addDays(today, -1);
  for (let i = 0; i < MAX_SCAN && ok(cursor); i++, cursor = addDays(cursor, -1)) streak++;
  return streak;
}

export function computeBadges(data: AppData, today: string): Badge[] {
  const diary = diaryStats(data.entries, today);

  const goal = effectiveWaterGoal(data.settings);
  const waterDays = new Set<string>();
  if (goal !== null) {
    const totals = new Map<string, number>();
    for (const l of data.waterLogs) totals.set(l.date, (totals.get(l.date) ?? 0) + l.ml);
    for (const [d, ml] of totals) if (ml >= goal) waterDays.add(d);
  }
  const waterStreak = streakOf(today, (d) => waterDays.has(d));

  const doseLogs = logMap(data.doseLogs);
  const perfectMedStreak = streakOf(today, (d) => {
    const doses = dosesForDate(data.medicines, d);
    return doses.length > 0 && doses.every((x) => doseLogs.get(x.key)?.status === "taken");
  });

  const counts = habitLogMap(data.habitLogs);
  const bestHabit = data.habits.reduce((best, h) => Math.max(best, habitStats(h, counts, today).best), 0);
  const remindersDone = data.reminderLogs.filter((l) => l.status === "done").length;
  const medsTaken = data.doseLogs.filter((l) => l.status === "taken").length;

  const make = (id: string, icon: string, title: string, description: string, progress: number, target: number): Badge => ({
    id, icon, title, description, progress: Math.min(progress, target), target,
  });

  return [
    make("first-entry", "📔", "প্রথম পাতা", "প্রথম ডায়েরি এন্ট্রি লিখুন", diary.total, 1),
    make("diary-7", "✍️", "লেখক", "টানা ৭ দিন ডায়েরি লিখুন", diary.streak, 7),
    make("diary-30", "📚", "ত্রিশ পাতা", "মোট ৩০টি এন্ট্রি লিখুন", diary.total, 30),
    make("water-1", "💧", "প্রথম লক্ষ্য", "একদিন পানির লক্ষ্য পূরণ করুন", waterDays.size, 1),
    make("water-7", "🌊", "পানির বন্ধু", "টানা ৭ দিন পানির লক্ষ্য পূরণ করুন", waterStreak, 7),
    make("med-10", "💊", "নিয়মিত", "১০টি ডোজ সময়মতো খান", medsTaken, 10),
    make("med-7", "🛡️", "নিখুঁত সপ্তাহ", "টানা ৭ দিন সব ডোজ খান", perfectMedStreak, 7),
    make("habit-7", "🔥", "অভ্যাসের আগুন", "কোনো অভ্যাসে টানা ৭ দিন", bestHabit, 7),
    make("habit-30", "🏆", "চ্যাম্পিয়ন", "কোনো অভ্যাসে টানা ৩০ দিন", bestHabit, 30),
    make("reminder-10", "⏰", "গোছানো মানুষ", "১০টি রিমাইন্ডার সম্পন্ন করুন", remindersDone, 10),
  ];
}
