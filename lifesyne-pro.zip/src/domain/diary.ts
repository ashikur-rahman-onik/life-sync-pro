import { addDays } from "@/lib/date";
import type { DiaryEntry } from "./types";

export function sortEntries(entries: DiaryEntry[]): DiaryEntry[] {
  return [...entries].sort((a, b) => (a.entryDate === b.entryDate ? b.createdAt.localeCompare(a.createdAt) : b.entryDate.localeCompare(a.entryDate)));
}

export function filterEntries(entries: DiaryEntry[], search: string, mood: string | null, onlyFavorites = false): DiaryEntry[] {
  const q = search.trim().toLowerCase();
  return entries.filter((e) => {
    if (mood && e.mood !== mood) return false;
    if (onlyFavorites && !e.favorite) return false;
    if (!q) return true;
    return e.title.toLowerCase().includes(q) || e.content.toLowerCase().includes(q) || e.tags.some((t) => t.toLowerCase().includes(q));
  });
}

export interface DiaryStats {
  total: number;
  streak: number;
  daysWritten: number;
  entriesThisMonth: number;
  moodCounts: Record<string, number>;
}

export function diaryStats(entries: DiaryEntry[], today: string): DiaryStats {
  const dates = new Set(entries.map((e) => e.entryDate));
  const moodCounts: Record<string, number> = {};
  for (const e of entries) moodCounts[e.mood] = (moodCounts[e.mood] ?? 0) + 1;

  // Streak: consecutive days with an entry, ending today (or yesterday if nothing is written yet today).
  let streak = 0;
  let cursor = dates.has(today) ? today : addDays(today, -1);
  while (dates.has(cursor)) {
    streak++;
    cursor = addDays(cursor, -1);
  }

  const monthPrefix = today.slice(0, 7);
  const entriesThisMonth = [...dates].filter((d) => d.startsWith(monthPrefix)).length;

  return { total: entries.length, streak, daysWritten: dates.size, entriesThisMonth, moodCounts };
}

/** Groups already-sorted entries by YYYY-MM, keeping order. */
export function groupByMonth(entries: DiaryEntry[]): [string, DiaryEntry[]][] {
  const map = new Map<string, DiaryEntry[]>();
  for (const e of entries) {
    const key = e.entryDate.slice(0, 7);
    const list = map.get(key);
    if (list) list.push(e);
    else map.set(key, [e]);
  }
  return [...map.entries()];
}

/** "Page 1, 2, 3…" in the order the pages were written. */
export function pageNumbers(entries: DiaryEntry[]): Map<string, number> {
  const ordered = [...entries].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  return new Map(ordered.map((e, i) => [e.id, i + 1]));
}

/** Pages written on this calendar day in earlier years ("এক বছর আগে আজকের দিনে…"). */
export function onThisDay(entries: DiaryEntry[], today: string): { entry: DiaryEntry; yearsAgo: number }[] {
  const monthDay = today.slice(5);
  const year = Number(today.slice(0, 4));
  return entries
    .filter((e) => e.entryDate.slice(5) === monthDay && Number(e.entryDate.slice(0, 4)) < year)
    .map((entry) => ({ entry, yearsAgo: year - Number(entry.entryDate.slice(0, 4)) }))
    .sort((a, b) => a.yearsAgo - b.yearsAgo);
}

/** Pages ordered oldest → newest, for the "previous / next page" buttons. */
export const chronological = (entries: DiaryEntry[]): DiaryEntry[] =>
  [...entries].sort((a, b) => (a.entryDate === b.entryDate ? a.createdAt.localeCompare(b.createdAt) : a.entryDate.localeCompare(b.entryDate)));
