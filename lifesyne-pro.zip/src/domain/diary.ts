import { addDays } from "@/lib/date";
import type { DiaryEntry } from "./types";

export function sortEntries(entries: DiaryEntry[]): DiaryEntry[] {
  return [...entries].sort((a, b) => (a.entryDate === b.entryDate ? b.createdAt.localeCompare(a.createdAt) : b.entryDate.localeCompare(a.entryDate)));
}

export function filterEntries(entries: DiaryEntry[], search: string, mood: string | null): DiaryEntry[] {
  const q = search.trim().toLowerCase();
  return entries.filter((e) => {
    if (mood && e.mood !== mood) return false;
    if (!q) return true;
    return e.title.toLowerCase().includes(q) || e.content.toLowerCase().includes(q) || e.tags.some((t) => t.toLowerCase().includes(q));
  });
}

export interface DiaryStats {
  total: number;
  streak: number;
  daysWritten: number;
  entriesThisMonth: number;
  moodCounts: Record<string, number>;
}

export function diaryStats(entries: DiaryEntry[], today: string): DiaryStats {
  const dates = new Set(entries.map((e) => e.entryDate));
  const moodCounts: Record<string, number> = {};
  for (const e of entries) moodCounts[e.mood] = (moodCounts[e.mood] ?? 0) + 1;

  // Streak: consecutive days with an entry, ending today (or yesterday if nothing is written yet today).
  let streak = 0;
  let cursor = dates.has(today) ? today : addDays(today, -1);
  while (dates.has(cursor)) {
    streak++;
    cursor = addDays(cursor, -1);
  }

  const monthPrefix = today.slice(0, 7);
  const entriesThisMonth = [...dates].filter((d) => d.startsWith(monthPrefix)).length;

  return { total: entries.length, streak, daysWritten: dates.size, entriesThisMonth, moodCounts };
}

/** Groups already-sorted entries by YYYY-MM, keeping order. */
export function groupByMonth(entries: DiaryEntry[]): [string, DiaryEntry[]][] {
  const map = new Map<string, DiaryEntry[]>();
  for (const e of entries) {
    const key = e.entryDate.slice(0, 7);
    const list = map.get(key);
    if (list) list.push(e);
    else map.set(key, [e]);
  }
  return [...map.entries()];
}
