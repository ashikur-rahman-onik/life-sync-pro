export interface Tag {
  id: string;
  name: string;
  icon: string;
}

export const VAULT_TAGS: Tag[] = [
  { id: "id", name: "আইডি/পরিচয়", icon: "🪪" },
  { id: "bank", name: "ব্যাংক/টাকা", icon: "🏦" },
  { id: "study", name: "পড়াশোনা", icon: "🎓" },
  { id: "work", name: "কাজ/ব্যবসা", icon: "💼" },
  { id: "medical", name: "চিকিৎসা", icon: "🩺" },
  { id: "photo", name: "ছবি/স্মৃতি", icon: "🖼️" },
  { id: "other", name: "অন্যান্য", icon: "📁" },
];

export const PASSWORD_TAGS: Tag[] = [
  { id: "social", name: "সোশ্যাল", icon: "💬" },
  { id: "email", name: "ইমেইল", icon: "✉️" },
  { id: "bank", name: "ব্যাংক/পেমেন্ট", icon: "🏦" },
  { id: "work", name: "কাজ", icon: "💼" },
  { id: "shopping", name: "শপিং", icon: "🛒" },
  { id: "other", name: "অন্যান্য", icon: "🔑" },
];

export const tagOf = (tags: Tag[], id: string): Tag => tags.find((t) => t.id === id) ?? tags[tags.length - 1];
