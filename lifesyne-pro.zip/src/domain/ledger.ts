import { fromBn, toBn } from "@/lib/bn";
import type { LedgerCategory, LedgerEntry } from "./types";

/** ৳ with Bangla digits and South Asian grouping: 1234567 → "৳ ১২,৩৪,৫৬৭" */
export function formatTaka(amount: number): string {
  const rounded = Math.round(amount * 100) / 100;
  const negative = rounded < 0;
  const [intPart, frac] = Math.abs(rounded).toFixed(2).split(".");
  const last3 = intPart.slice(-3);
  const rest = intPart.slice(0, -3);
  const grouped = rest ? `${rest.replace(/\B(?=(\d{2})+(?!\d))/g, ",")},${last3}` : last3;
  return `${negative ? "−" : ""}৳ ${toBn(grouped)}${frac === "00" ? "" : `.${toBn(frac)}`}`;
}

export interface MonthSummary {
  income: number;
  expense: number;
  balance: number;
}

export function summarize(entries: LedgerEntry[]): MonthSummary {
  let income = 0;
  let expense = 0;
  for (const e of entries) {
    if (e.type === "income") income += e.amount;
    else expense += e.amount;
  }
  return { income, expense, balance: income - expense };
}

export const inMonth = (entries: LedgerEntry[], month: string): LedgerEntry[] => entries.filter((e) => e.date.startsWith(month));

/** Entries newest day first, each day with its own totals. */
export function groupByDay(entries: LedgerEntry[]): { date: string; entries: LedgerEntry[]; summary: MonthSummary }[] {
  const map = new Map<string, LedgerEntry[]>();
  for (const e of [...entries].sort((a, b) => (a.date === b.date ? b.createdAt.localeCompare(a.createdAt) : b.date.localeCompare(a.date)))) {
    map.set(e.date, [...(map.get(e.date) ?? []), e]);
  }
  return [...map.entries()].map(([date, list]) => ({ date, entries: list, summary: summarize(list) }));
}

/** Spending (or income) per category, biggest first. */
export function categoryTotals(entries: LedgerEntry[], type: "income" | "expense", categories: LedgerCategory[]): { category: LedgerCategory | null; id: string; total: number }[] {
  const totals = new Map<string, number>();
  for (const e of entries) if (e.type === type) totals.set(e.categoryId, (totals.get(e.categoryId) ?? 0) + e.amount);
  return [...totals.entries()]
    .map(([id, total]) => ({ id, total, category: categories.find((c) => c.id === id) ?? null }))
    .sort((a, b) => b.total - a.total);
}

/** "১,২৫০.৫০" / "1250" → 1250.5 (null if it is not a positive amount). */
export function parseAmount(text: string): number | null {
  const n = parseFloat(fromBn(text).replace(/[,\s৳]/g, ""));
  return Number.isFinite(n) && n > 0 && n < 1e12 ? Math.round(n * 100) / 100 : null;
}
