import { addDays, dateKey, timeToMinutes } from "@/lib/date";
import { formatMl } from "@/lib/bn";
import { hashToInt } from "@/lib/id";
import { formatDose, isActiveOn, RELATION_LABELS } from "./medicine";
import { calcWaterGoalMl, glassesNeeded, planWaterTimes } from "./water";
import type { AppData, Medicine, DoseSlot, Settings } from "./types";

export type ReminderChannel = "medicine" | "water" | "diary";
export type ReminderKind = "water" | "med" | "diary";

export interface PlannedNotification {
  id: number;
  channel: ReminderChannel;
  title: string;
  body: string;
  actionTypeId?: "MED_DOSE" | "WATER";
  /** One-off notification time. */
  at?: Date;
  /** Repeating notification (weekday: 1 = Sunday … 7 = Saturday, as Capacitor expects). */
  on?: { weekday?: number; hour: number; minute: number };
  extra: Record<string, string>;
}

/** How many days ahead dated courses are scheduled (refreshed every time the app opens). */
export const ONE_OFF_HORIZON_DAYS = 14;
/** Android keeps roughly 500 alarms per app; stay safely below. */
export const MAX_NOTIFICATIONS = 400;

export const effectiveWaterGoal = (s: Settings): number | null => s.water.goalOverrideMl ?? calcWaterGoalMl(s.profile);

function hm(time: string): { hour: number; minute: number } {
  const m = timeToMinutes(time);
  return { hour: Math.floor(m / 60), minute: m % 60 };
}

function atTime(date: string, time: string): Date {
  const [y, mo, d] = date.split("-").map(Number);
  const { hour, minute } = hm(time);
  return new Date(y, mo - 1, d, hour, minute, 0, 0);
}

function medBody(m: Medicine, slot: DoseSlot): string {
  const rel = m.relation === "any" ? "" : ` (${RELATION_LABELS[m.relation]})`;
  return `${m.name} — ${formatDose(slot.qty, m.form)}${rel}`;
}

export function planReminders(data: AppData, now: Date = new Date()): PlannedNotification[] {
  const { settings } = data;
  const today = dateKey(now);
  const used = new Set<number>();
  const makeId = (seed: string): number => {
    let id = hashToInt(seed) + 10_000;
    while (used.has(id)) id++;
    used.add(id);
    return id;
  };

  const repeating: PlannedNotification[] = [];
  const oneOff: PlannedNotification[] = [];

  /* ---- Water ---- */
  const goal = effectiveWaterGoal(settings);
  if (settings.water.remindersOn && goal !== null) {
    const container = data.containers.find((c) => c.id === settings.water.defaultContainerId) ?? data.containers[0];
    const glassMl = container?.ml ?? 250;
    const glassName = container?.name ?? "গ্লাস";
    const times = planWaterTimes(settings.water.wake, settings.water.sleep, glassesNeeded(goal, glassMl));
    times.forEach((time, i) => {
      repeating.push({
        id: makeId(`water:${i}`),
        channel: "water",
        title: "💧 পানি খাওয়ার সময়",
        body: `এক ${glassName} (${formatMl(glassMl)}) পানি খান। আজকের লক্ষ্য ${formatMl(goal)}।`,
        actionTypeId: "WATER",
        on: hm(time),
        extra: { kind: "water", time },
      });
    });
  }

  /* ---- Diary ---- */
  if (settings.diaryReminder.on) {
    repeating.push({
      id: makeId("diary"),
      channel: "diary",
      title: "📝 ডায়েরি লেখার সময়",
      body: "আজকের দিনটা কেমন গেল? কয়েক লাইন লিখে রাখুন।",
      on: hm(settings.diaryReminder.time),
      extra: { kind: "diary" },
    });
  }

  /* ---- Medicines ---- */
  if (settings.medRemindersOn) {
    const horizonEnd = addDays(today, ONE_OFF_HORIZON_DAYS);

    for (const m of data.medicines) {
      if (!m.active) continue;
      const ongoing = m.endDate === null;

      if (ongoing && m.startDate <= today) {
        for (const slot of m.slots) {
          const base = { channel: "medicine" as const, title: "💊 ওষুধ খাওয়ার সময়", body: medBody(m, slot), actionTypeId: "MED_DOSE" as const };
          const extra = { kind: "med", medId: m.id, slotId: slot.id, time: slot.time };
          if (m.weekdays.length === 0) {
            repeating.push({ ...base, id: makeId(`med:${m.id}:${slot.id}`), on: hm(slot.time), extra });
          } else {
            for (const wd of m.weekdays) {
              repeating.push({ ...base, id: makeId(`med:${m.id}:${slot.id}:w${wd}`), on: { weekday: wd + 1, ...hm(slot.time) }, extra });
            }
          }
        }
        continue;
      }

      const first = m.startDate > today ? m.startDate : today;
      const last = m.endDate !== null && m.endDate < horizonEnd ? m.endDate : horizonEnd;
      for (let date = first; date <= last; date = addDays(date, 1)) {
        if (!isActiveOn(m, date)) continue;
        for (const slot of m.slots) {
          const at = atTime(date, slot.time);
          if (at.getTime() <= now.getTime()) continue;
          oneOff.push({
            id: makeId(`med:${m.id}:${slot.id}:${date}`),
            channel: "medicine",
            title: "💊 ওষুধ খাওয়ার সময়",
            body: medBody(m, slot),
            actionTypeId: "MED_DOSE",
            at,
            extra: { kind: "med", medId: m.id, slotId: slot.id, time: slot.time, date },
          });
        }
      }
    }

    for (const s of data.snoozes) {
      const m = data.medicines.find((x) => x.id === s.medicineId);
      const slot = m?.slots.find((x) => x.id === s.slotId);
      const at = new Date(s.at);
      if (!m || !slot || !m.active || at.getTime() <= now.getTime()) continue;
      oneOff.push({
        id: makeId(`snooze:${s.id}`),
        channel: "medicine",
        title: "⏰ ওষুধ খাওয়ার রিমাইন্ডার",
        body: medBody(m, slot),
        actionTypeId: "MED_DOSE",
        at,
        extra: { kind: "med", medId: m.id, slotId: slot.id, time: s.time, date: s.date, snooze: "1" },
      });
    }
  }

  oneOff.sort((a, b) => (a.at?.getTime() ?? 0) - (b.at?.getTime() ?? 0));
  return [...repeating, ...oneOff].slice(0, MAX_NOTIFICATIONS);
}

/** Stable fingerprint so identical plans are not rescheduled again and again. */
export function planSignature(plan: PlannedNotification[]): string {
  return JSON.stringify(
    plan.map((n) => [n.id, n.channel, n.title, n.body, n.at?.getTime() ?? null, n.on ?? null, n.extra]),
  );
}
