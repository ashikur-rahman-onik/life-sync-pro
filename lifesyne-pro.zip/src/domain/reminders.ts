import { addDays, dateKey, timeToMinutes } from "@/lib/date";
import { formatMl, toBn } from "@/lib/bn";
import { hashToInt } from "@/lib/id";
import { doseKey, dosesForDate, formatDose, isActiveOn, RELATION_LABELS } from "./medicine";
import { isSparse, occurrenceDates, effectiveWeekdays } from "./schedule";
import { calcWaterGoalMl, glassesNeeded, intervalTimes, planWaterTimes } from "./water";
import type { AppData, DoseSlot, Medicine, NotifyStyle, Settings } from "./types";

export type ReminderKind = "water" | "med" | "diary" | "reminder" | "habit";

export interface PlannedNotification {
  id: number;
  kind: ReminderKind;
  style: NotifyStyle;
  title: string;
  body: string;
  actionTypeId?: "MED_DOSE" | "WATER" | "REMINDER" | "HABIT";
  /** One-off notification time. */
  at?: Date;
  /** Repeating notification (weekday: 1 = Sunday … 7 = Saturday, as Capacitor expects). */
  on?: { weekday?: number; hour: number; minute: number };
  extra: Record<string, string>;
}

type On = NonNullable<PlannedNotification["on"]>;

/** Days ahead that busy schedules are planned (refreshed every time the app opens). */
export const ONE_OFF_HORIZON_DAYS = 14;
/** Rare schedules (monthly, yearly, birthdays…) are planned much further ahead. */
export const SPARSE_HORIZON_DAYS = 400;
const MAX_OCCURRENCES_PER_REMINDER = 30;
/** Android keeps roughly 500 alarms per app; stay safely below. */
export const MAX_NOTIFICATIONS = 400;

export const effectiveWaterGoal = (s: Settings): number | null => s.water.goalOverrideMl ?? calcWaterGoalMl(s.profile);

function hm(time: string): On {
  const m = timeToMinutes(time);
  return { hour: Math.floor(m / 60), minute: m % 60 };
}

function atTime(date: string, time: string): Date {
  const [y, mo, d] = date.split("-").map(Number);
  const { hour, minute } = hm(time);
  return new Date(y, mo - 1, d, hour, minute, 0, 0);
}

/** Moves a repeating time by some minutes, adjusting the weekday when it crosses midnight. */
export function shiftOn(on: On, deltaMin: number): On {
  const total = on.hour * 60 + on.minute + deltaMin;
  const dayShift = Math.floor(total / 1440);
  const m = ((total % 1440) + 1440) % 1440;
  const out: On = { hour: Math.floor(m / 60), minute: m % 60 };
  if (on.weekday !== undefined) out.weekday = ((((on.weekday - 1 + dayShift) % 7) + 7) % 7) + 1;
  return out;
}

function medBody(m: Medicine, slot: DoseSlot): string {
  const rel = m.relation === "any" ? "" : ` (${RELATION_LABELS[m.relation]})`;
  return `${m.name} — ${formatDose(slot.qty, m.form)}${rel}`;
}

export function planReminders(data: AppData, now: Date = new Date()): PlannedNotification[] {
  const { settings } = data;
  const today = dateKey(now);
  const used = new Set<number>();
  const makeId = (seed: string): number => {
    let id = hashToInt(seed) + 10_000;
    while (used.has(id)) id++;
    used.add(id);
    return id;
  };

  const repeating: PlannedNotification[] = [];
  const oneOff: PlannedNotification[] = [];

  /** Adds a repeating notification at `on`, plus its optional early heads-up. */
  const addRepeating = (n: Omit<PlannedNotification, "id" | "on">, seed: string, on: On, earlyMin = 0, earlyTitle = "", earlyBody = "") => {
    repeating.push({ ...n, id: makeId(seed), on });
    if (earlyMin > 0) {
      repeating.push({ ...n, id: makeId(`${seed}:early`), title: earlyTitle, body: earlyBody, actionTypeId: undefined, on: shiftOn(on, -earlyMin), extra: { ...n.extra, early: "1" } });
    }
  };

  /* ---- Water ---- */
  const goal = effectiveWaterGoal(settings);
  const w = settings.water;
  if (w.remindersOn && (w.mode !== "even" || goal !== null)) {
    const container = data.containers.find((c) => c.id === w.defaultContainerId) ?? data.containers[0];
    const glassMl = container?.ml ?? 250;
    const glassName = container?.name ?? "গ্লাস";
    const times =
      w.mode === "custom" ? w.customTimes : w.mode === "interval" ? intervalTimes(w.wake, w.sleep, w.intervalMin) : planWaterTimes(w.wake, w.sleep, glassesNeeded(goal ?? 2000, glassMl));
    times.forEach((time, i) => {
      addRepeating(
        {
          kind: "water",
          style: settings.notify.waterStyle,
          title: "💧 পানি খাওয়ার সময়",
          body: `এক ${glassName} (${formatMl(glassMl)}) পানি খান।${goal !== null ? ` আজকের লক্ষ্য ${formatMl(goal)}।` : ""}`,
          actionTypeId: "WATER",
          extra: { kind: "water", time },
        },
        `water:${w.mode}:${i}`,
        hm(time),
      );
    });
  }

  /* ---- Diary ---- */
  if (settings.diaryReminder.on) {
    addRepeating(
      { kind: "diary", style: settings.notify.diaryStyle, title: "📝 ডায়েরি লেখার সময়", body: "আজকের দিনটা কেমন গেল? কয়েক লাইন লিখে রাখুন।", extra: { kind: "diary" } },
      "diary",
      hm(settings.diaryReminder.time),
    );
  }

  /* ---- Medicines ---- */
  if (settings.medRemindersOn) {
    const nt = settings.notify;
    const horizonEnd = addDays(today, ONE_OFF_HORIZON_DAYS);

    for (const m of data.medicines) {
      if (!m.active) continue;
      const ongoing = m.endDate === null;

      if (ongoing && m.startDate <= today) {
        for (const slot of m.slots) {
          const base = { kind: "med" as const, style: nt.medStyle, title: "💊 ওষুধ খাওয়ার সময়", body: medBody(m, slot), actionTypeId: "MED_DOSE" as const, extra: { kind: "med", medId: m.id, slotId: slot.id, time: slot.time } };
          const early = [nt.medEarlyMin, "💊 ওষুধের সময় হয়ে আসছে", `${toBn(nt.medEarlyMin)} মিনিট পরে: ${medBody(m, slot)}`] as const;
          if (m.weekdays.length === 0) {
            addRepeating(base, `med:${m.id}:${slot.id}`, hm(slot.time), ...early);
          } else {
            for (const wd of m.weekdays) addRepeating(base, `med:${m.id}:${slot.id}:w${wd}`, { weekday: wd + 1, ...hm(slot.time) }, ...early);
          }
        }
        continue;
      }

      const first = m.startDate > today ? m.startDate : today;
      const last = m.endDate !== null && m.endDate < horizonEnd ? m.endDate : horizonEnd;
      for (let date = first; date <= last; date = addDays(date, 1)) {
        if (!isActiveOn(m, date)) continue;
        for (const slot of m.slots) {
          const at = atTime(date, slot.time);
          const extra = { kind: "med", medId: m.id, slotId: slot.id, time: slot.time, date };
          if (at.getTime() > now.getTime()) {
            oneOff.push({ id: makeId(`med:${m.id}:${slot.id}:${date}`), kind: "med", style: nt.medStyle, title: "💊 ওষুধ খাওয়ার সময়", body: medBody(m, slot), actionTypeId: "MED_DOSE", at, extra });
          }
          const earlyAt = new Date(at.getTime() - nt.medEarlyMin * 60_000);
          if (nt.medEarlyMin > 0 && earlyAt.getTime() > now.getTime()) {
            oneOff.push({ id: makeId(`med:${m.id}:${slot.id}:${date}:early`), kind: "med", style: nt.medStyle, title: "💊 ওষুধের সময় হয়ে আসছে", body: `${toBn(nt.medEarlyMin)} মিনিট পরে: ${medBody(m, slot)}`, at: earlyAt, extra: { ...extra, early: "1" } });
          }
        }
      }
    }

    // "Did you take it?" nudges for today's and tomorrow's doses that are not marked yet.
    if (nt.medFollowUps > 0) {
      const taken = new Set(data.doseLogs.map((l) => l.key));
      for (const date of [today, addDays(today, 1)]) {
        for (const dose of dosesForDate(data.medicines, date)) {
          if (taken.has(doseKey(dose.medicine.id, dose.slot.id, date))) continue;
          for (let k = 1; k <= nt.medFollowUps; k++) {
            const at = new Date(atTime(date, dose.time).getTime() + k * nt.medFollowEveryMin * 60_000);
            if (at.getTime() <= now.getTime()) continue;
            oneOff.push({
              id: makeId(`med:${dose.medicine.id}:${dose.slot.id}:${date}:follow${k}`),
              kind: "med",
              style: nt.medStyle,
              title: "❓ ওষুধ খেয়েছেন তো?",
              body: medBody(dose.medicine, dose.slot),
              actionTypeId: "MED_DOSE",
              at,
              extra: { kind: "med", medId: dose.medicine.id, slotId: dose.slot.id, time: dose.time, date, followup: String(k) },
            });
          }
        }
      }
    }
  }

  /* ---- Custom reminders & alarms ---- */
  for (const r of data.reminders) {
    if (!r.active) continue;
    const body = r.note.trim() || "সময় হয়েছে";
    const title = `${r.icon} ${r.title}`;
    const repeatsForever = (r.type === "daily" || r.type === "weekly") && r.endDate === null && r.date <= today;

    if (repeatsForever) {
      const days = r.type === "weekly" ? effectiveWeekdays(r) : [null];
      for (const time of r.times) {
        for (const wd of days) {
          addRepeating(
            { kind: "reminder", style: r.style, title, body, actionTypeId: "REMINDER", extra: { kind: "reminder", reminderId: r.id, time } },
            `rem:${r.id}:${time}:${wd ?? "d"}`,
            wd === null ? hm(time) : { weekday: wd + 1, ...hm(time) },
            r.earlyMin,
            `⏳ ${r.title}`,
            `${toBn(r.earlyMin)} মিনিট পরে — ${body}`,
          );
        }
      }
      continue;
    }

    const horizon = addDays(today, isSparse(r) ? SPARSE_HORIZON_DAYS : ONE_OFF_HORIZON_DAYS);
    const dates = occurrenceDates(r, today, horizon);
    let count = 0;
    for (const date of dates) {
      for (const time of r.times) {
        if (count >= MAX_OCCURRENCES_PER_REMINDER) break;
        const at = atTime(date, time);
        const extra = { kind: "reminder", reminderId: r.id, time, date };
        if (at.getTime() > now.getTime()) {
          oneOff.push({ id: makeId(`rem:${r.id}:${time}:${date}`), kind: "reminder", style: r.style, title, body, actionTypeId: "REMINDER", at, extra });
          count++;
        }
        const earlyAt = new Date(at.getTime() - r.earlyMin * 60_000);
        if (r.earlyMin > 0 && earlyAt.getTime() > now.getTime()) {
          oneOff.push({ id: makeId(`rem:${r.id}:${time}:${date}:early`), kind: "reminder", style: r.style, title: `⏳ ${r.title}`, body: `${toBn(r.earlyMin)} মিনিট পরে — ${body}`, at: earlyAt, extra: { ...extra, early: "1" } });
        }
      }
    }
  }

  /* ---- Habits ---- */
  for (const h of data.habits) {
    if (h.archived || !h.reminderOn || h.startDate > today) continue;
    for (const time of h.times) {
      const days = h.weekdays.length === 0 ? [null] : h.weekdays;
      for (const wd of days) {
        addRepeating(
          {
            kind: "habit",
            style: h.style,
            title: `${h.icon} ${h.name}`,
            body: h.target > 1 ? `আজ ${toBn(h.target)} বার করার লক্ষ্য — এখনই শুরু করুন!` : "আজকের অভ্যাসটা করার সময় হয়েছে!",
            actionTypeId: "HABIT",
            extra: { kind: "habit", habitId: h.id, time },
          },
          `habit:${h.id}:${time}:${wd ?? "d"}`,
          wd === null ? hm(time) : { weekday: wd + 1, ...hm(time) },
        );
      }
    }
  }

  /* ---- Snoozed reminders ---- */
  for (const z of data.snoozes) {
    const at = new Date(z.at);
    if (at.getTime() <= now.getTime()) continue;
    if (z.kind === "med") {
      const m = data.medicines.find((x) => x.id === z.refId);
      const slot = m?.slots.find((x) => x.id === z.slotId);
      if (!m || !slot || !m.active || !settings.medRemindersOn) continue;
      oneOff.push({ id: makeId(`snooze:${z.id}`), kind: "med", style: settings.notify.medStyle, title: "⏰ ওষুধ খাওয়ার রিমাইন্ডার", body: medBody(m, slot), actionTypeId: "MED_DOSE", at, extra: { kind: "med", medId: m.id, slotId: slot.id, time: z.time, date: z.date, snooze: "1" } });
    } else {
      const r = data.reminders.find((x) => x.id === z.refId);
      if (!r || !r.active) continue;
      oneOff.push({ id: makeId(`snooze:${z.id}`), kind: "reminder", style: r.style, title: `⏰ ${r.icon} ${r.title}`, body: r.note.trim() || "আবার মনে করিয়ে দিচ্ছি", actionTypeId: "REMINDER", at, extra: { kind: "reminder", reminderId: r.id, time: z.time, date: z.date, snooze: "1" } });
    }
  }

  oneOff.sort((a, b) => (a.at?.getTime() ?? 0) - (b.at?.getTime() ?? 0));
  return [...repeating, ...oneOff].slice(0, MAX_NOTIFICATIONS);
}

/** Stable fingerprint so identical plans are not rescheduled again and again. */
export function planSignature(plan: PlannedNotification[]): string {
  return JSON.stringify(plan.map((n) => [n.id, n.kind, n.style, n.title, n.body, n.at?.getTime() ?? null, n.on ?? null, n.extra]));
}
