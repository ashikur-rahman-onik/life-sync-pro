import { addDays, minutesToTime, timeToMinutes } from "@/lib/date";
import type { Activity, Profile, WaterLog } from "./types";

export const ACTIVITY_LABELS: Record<Activity, string> = {
  low: "কম (বসে/হালকা কাজ)",
  moderate: "মাঝারি (হাঁটাহাঁটি/ঘরের কাজ)",
  high: "বেশি (ব্যায়াম/কায়িক শ্রম)",
};

const ACTIVITY_EXTRA_ML: Record<Activity, number> = { low: 0, moderate: 350, high: 700 };
const HOT_WEATHER_EXTRA_ML = 500;
const MIN_GOAL_ML = 1000;
const MAX_GOAL_ML = 4500;

const roundTo = (n: number, step: number) => Math.round(n / step) * step;

/**
 * Daily water target in ml from age/weight/activity/weather.
 * General guideline (not medical advice): adults ≈ 35 ml/kg, easing with age,
 * plus extra for activity and hot weather. Returns null if age/weight are missing.
 */
export function calcWaterGoalMl(p: Pick<Profile, "age" | "weightKg" | "activity" | "hotWeather">): number | null {
  const { age, weightKg } = p;
  if (age === null || weightKg === null || !(age > 0) || !(weightKg > 0)) return null;

  let base: number;
  if (age < 4) base = 1100;
  else if (age < 9) base = 1400;
  else if (age < 14) base = 1900;
  else if (age < 19) base = Math.min(2600, Math.max(1900, weightKg * 35));
  else if (age <= 55) base = weightKg * 35;
  else if (age <= 65) base = weightKg * 32;
  else base = weightKg * 30;

  const total = base + ACTIVITY_EXTRA_ML[p.activity] + (p.hotWeather ? HOT_WEATHER_EXTRA_ML : 0);
  return Math.min(MAX_GOAL_ML, Math.max(MIN_GOAL_ML, roundTo(total, 50)));
}

export function glassesNeeded(goalMl: number, glassMl: number): number {
  if (glassMl <= 0) return 0;
  return Math.ceil(goalMl / glassMl);
}

/** Evenly spaced reminder times between wake-up (+30 min) and bed time (−60 min). */
export function planWaterTimes(wake: string, sleep: string, count: number): string[] {
  const n = Math.min(16, Math.max(2, Math.round(count)));
  const wakeMin = timeToMinutes(wake);
  let sleepMin = timeToMinutes(sleep);
  if (sleepMin <= wakeMin) sleepMin += 1440;

  const start = wakeMin + 30;
  const end = Math.max(start + 60, sleepMin - 60);
  const step = (end - start) / (n - 1);

  const times: string[] = [];
  for (let i = 0; i < n; i++) {
    const t = minutesToTime(roundTo(start + i * step, 5));
    if (!times.includes(t)) times.push(t);
  }
  return times;
}

/** Every `everyMin` minutes from wake-up until bed time (at most 24 reminders). */
export function intervalTimes(wake: string, sleep: string, everyMin: number): string[] {
  const step = Math.max(15, Math.round(everyMin));
  const start = timeToMinutes(wake);
  let end = timeToMinutes(sleep);
  if (end <= start) end += 1440;
  const times: string[] = [];
  for (let t = start + step; t <= end - 30 && times.length < 24; t += step) {
    const time = minutesToTime(t);
    if (!times.includes(time)) times.push(time);
  }
  return times;
}

export function waterTotalForDate(logs: WaterLog[], date: string): number {
  let total = 0;
  for (const l of logs) if (l.date === date) total += l.ml;
  return total;
}

/** Last `days` days ending at `endDate` (oldest → newest). */
export function waterHistory(logs: WaterLog[], endDate: string, days: number) {
  const totals = new Map<string, number>();
  for (const l of logs) totals.set(l.date, (totals.get(l.date) ?? 0) + l.ml);
  const out: { date: string; ml: number }[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const date = addDays(endDate, -i);
    out.push({ date, ml: totals.get(date) ?? 0 });
  }
  return out;
}
