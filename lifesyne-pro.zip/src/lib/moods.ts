export const MOODS = [
  { key: "great", emoji: "😄", label: "চমৎকার", color: "#22c55e" },
  { key: "good", emoji: "🙂", label: "ভালো", color: "#84cc16" },
  { key: "neutral", emoji: "😐", label: "সাধারণ", color: "#eab308" },
  { key: "bad", emoji: "😔", label: "খারাপ", color: "#f97316" },
  { key: "terrible", emoji: "😢", label: "কষ্টের", color: "#ef4444" },
] as const;

export type MoodKey = (typeof MOODS)[number]["key"];

export function getMood(key: string) {
  return MOODS.find((m) => m.key === key) ?? MOODS[2];
}
