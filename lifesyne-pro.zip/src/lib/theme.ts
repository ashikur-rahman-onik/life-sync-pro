import { useEffect, useSyncExternalStore } from "react";

export type ThemePref = "light" | "dark" | "system";
const KEY = "diary_theme";
const listeners = new Set<() => void>();

export function getThemePref(): ThemePref {
  try {
    const v = localStorage.getItem(KEY);
    return v === "light" || v === "dark" ? v : "system";
  } catch {
    return "system";
  }
}

export function isDarkNow(pref: ThemePref = getThemePref()): boolean {
  return pref === "dark" || (pref === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
}

export function applyTheme(pref: ThemePref = getThemePref()): void {
  document.documentElement.classList.toggle("dark", isDarkNow(pref));
  const meta = document.querySelector('meta[name="theme-color"]');
  meta?.setAttribute("content", isDarkNow(pref) ? "#0e1520" : "#f4f8fd");
}

export function setThemePref(pref: ThemePref): void {
  try {
    if (pref === "system") localStorage.removeItem(KEY);
    else localStorage.setItem(KEY, pref);
  } catch {
    /* storage unavailable — theme just won't persist */
  }
  applyTheme(pref);
  listeners.forEach((l) => l());
}

/** Current preference + keeps the page in sync when the phone switches light/dark. */
export function useThemePref(): ThemePref {
  const pref = useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => {
        listeners.delete(l);
      };
    },
    getThemePref,
    getThemePref,
  );
  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => applyTheme();
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  return pref;
}

/* ------------------------------ Accent colour & text size ------------------------------ */

export const ACCENTS = [
  { value: "#2b7de9", label: "নীল" },
  { value: "#16a05d", label: "সবুজ" },
  { value: "#7c5cd6", label: "বেগুনি" },
  { value: "#e8762b", label: "কমলা" },
  { value: "#e0508f", label: "গোলাপি" },
  { value: "#0e9aa7", label: "টিল" },
] as const;

export const TEXT_SIZES = [
  { value: 90, label: "ছোট" },
  { value: 100, label: "সাধারণ" },
  { value: 112, label: "বড়" },
  { value: 125, label: "অনেক বড়" },
] as const;

const ACCENT_KEY = "diary_accent";
const SIZE_KEY = "diary_text_size";

function read(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function write(key: string, value: string | null): void {
  try {
    if (value === null) localStorage.removeItem(key);
    else localStorage.setItem(key, value);
  } catch {
    /* storage unavailable — the choice just won't persist */
  }
}

export function getAccent(): string {
  const v = read(ACCENT_KEY);
  return ACCENTS.some((a) => a.value === v) ? (v as string) : ACCENTS[0].value;
}

export function getTextSize(): number {
  const n = Number(read(SIZE_KEY));
  return TEXT_SIZES.some((s) => s.value === n) ? n : 100;
}

export function applyAppearance(): void {
  const root = document.documentElement;
  root.style.setProperty("--color-accent", getAccent());
  root.style.fontSize = `${getTextSize()}%`;
}

export function setAccent(value: string): void {
  write(ACCENT_KEY, value === ACCENTS[0].value ? null : value);
  applyAppearance();
}

export function setTextSize(value: number): void {
  write(SIZE_KEY, value === 100 ? null : String(value));
  applyAppearance();
}
