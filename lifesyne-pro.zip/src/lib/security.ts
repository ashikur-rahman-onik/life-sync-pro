/**
 * PIN lock. The PIN is never stored — only a salted SHA-256 hash.
 * Wrong attempts are rate-limited (5 tries, then an increasing wait).
 */
const KEY = "amar_security_v1";
const MAX_FREE_ATTEMPTS = 5;

interface SecurityRecord {
  salt: string;
  hash: string;
  autoLockSec: number; // seconds in background before locking; -1 = never
  fails: number;
  lockedUntil: number; // epoch ms
}

function read(): SecurityRecord | null {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? "null") as Partial<SecurityRecord> | null;
    if (!raw || typeof raw.hash !== "string" || typeof raw.salt !== "string") return null;
    return {
      salt: raw.salt,
      hash: raw.hash,
      autoLockSec: typeof raw.autoLockSec === "number" ? raw.autoLockSec : 60,
      fails: Number(raw.fails) || 0,
      lockedUntil: Number(raw.lockedUntil) || 0,
    };
  } catch {
    return null;
  }
}

function write(rec: SecurityRecord): void {
  localStorage.setItem(KEY, JSON.stringify(rec));
}

async function sha256Hex(text: string): Promise<string> {
  if (!globalThis.crypto?.subtle) throw new Error("secure hashing not available");
  const digest = await globalThis.crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function randomSalt(): string {
  const bytes = new Uint8Array(16);
  globalThis.crypto.getRandomValues(bytes);
  return [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export const hasPin = (): boolean => read() !== null;

export async function setPin(pin: string): Promise<void> {
  const salt = randomSalt();
  const previous = read();
  write({ salt, hash: await sha256Hex(`${salt}:${pin}`), autoLockSec: previous?.autoLockSec ?? 60, fails: 0, lockedUntil: 0 });
}

export function removePin(): void {
  localStorage.removeItem(KEY);
}

export type VerifyResult = { ok: true } | { ok: false; waitMs: number };

export async function verifyPin(pin: string): Promise<VerifyResult> {
  const rec = read();
  if (!rec) return { ok: true };

  const now = Date.now();
  if (rec.lockedUntil > now) return { ok: false, waitMs: rec.lockedUntil - now };

  if ((await sha256Hex(`${rec.salt}:${pin}`)) === rec.hash) {
    write({ ...rec, fails: 0, lockedUntil: 0 });
    return { ok: true };
  }

  const fails = rec.fails + 1;
  let lockedUntil = 0;
  if (fails >= MAX_FREE_ATTEMPTS) {
    const seconds = Math.min(600, 30 * 2 ** (fails - MAX_FREE_ATTEMPTS));
    lockedUntil = now + seconds * 1000;
  }
  write({ ...rec, fails, lockedUntil });
  return { ok: false, waitMs: lockedUntil > now ? lockedUntil - now : 0 };
}

export function getAutoLockSec(): number {
  return read()?.autoLockSec ?? 60;
}

export function setAutoLockSec(sec: number): void {
  const rec = read();
  if (rec) write({ ...rec, autoLockSec: sec });
}
