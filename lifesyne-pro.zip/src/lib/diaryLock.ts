import { useSyncExternalStore } from "react";
import type { DiaryLockRecord } from "@/domain/types";

/**
 * The diary's own password (separate from the app PIN).
 * Only a salted PBKDF2 hash is stored (inside the synced settings), never the password itself.
 */
const ITERATIONS = 120_000;
const FAIL_KEY = "lsp_diary_fail_v1";
const MAX_FREE_ATTEMPTS = 5;
const MIN_LENGTH = 4;

const hex = (bytes: ArrayBuffer | Uint8Array): string => [...new Uint8Array(bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes))].map((b) => b.toString(16).padStart(2, "0")).join("");

async function derive(password: string, saltHex: string, iterations: number): Promise<string> {
  if (!globalThis.crypto?.subtle) throw new Error("secure hashing not available");
  const salt = new Uint8Array((saltHex.match(/.{2}/g) ?? []).map((h) => parseInt(h, 16)));
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  return hex(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt, iterations }, key, 256));
}

export const isValidDiaryPassword = (password: string): boolean => password.length >= MIN_LENGTH;
export const DIARY_PASSWORD_MIN = MIN_LENGTH;

export async function createLockRecord(password: string): Promise<DiaryLockRecord> {
  const salt = hex(crypto.getRandomValues(new Uint8Array(16)));
  return { salt, hash: await derive(password, salt, ITERATIONS), iterations: ITERATIONS };
}

interface Attempts {
  fails: number;
  lockedUntil: number;
}

function readAttempts(): Attempts {
  try {
    const raw = JSON.parse(localStorage.getItem(FAIL_KEY) ?? "{}") as Partial<Attempts>;
    return { fails: Number(raw.fails) || 0, lockedUntil: Number(raw.lockedUntil) || 0 };
  } catch {
    return { fails: 0, lockedUntil: 0 };
  }
}

const writeAttempts = (a: Attempts): void => {
  try {
    localStorage.setItem(FAIL_KEY, JSON.stringify(a));
  } catch {
    /* ignore */
  }
};

export type DiaryVerifyResult = { ok: true } | { ok: false; waitMs: number };

/** Checks the password. 5 wrong tries in a row cause an increasing wait. */
export async function verifyDiaryPassword(record: DiaryLockRecord, password: string): Promise<DiaryVerifyResult> {
  const now = Date.now();
  const attempts = readAttempts();
  if (attempts.lockedUntil > now) return { ok: false, waitMs: attempts.lockedUntil - now };

  if ((await derive(password, record.salt, record.iterations)) === record.hash) {
    writeAttempts({ fails: 0, lockedUntil: 0 });
    return { ok: true };
  }
  const fails = attempts.fails + 1;
  const lockedUntil = fails >= MAX_FREE_ATTEMPTS ? now + Math.min(600, 30 * 2 ** (fails - MAX_FREE_ATTEMPTS)) * 1000 : 0;
  writeAttempts({ fails, lockedUntil });
  return { ok: false, waitMs: lockedUntil > now ? lockedUntil - now : 0 };
}

export const resetDiaryAttempts = (): void => writeAttempts({ fails: 0, lockedUntil: 0 });

/* ------------------------- "is the diary open right now?" ------------------------- */

let opened = false;
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());

export const isDiaryOpen = (): boolean => opened;

export function openDiary(): void {
  if (opened) return;
  opened = true;
  emit();
}

export function closeDiary(): void {
  if (!opened) return;
  opened = false;
  emit();
}

export function useDiaryOpen(): boolean {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => {
        listeners.delete(l);
      };
    },
    isDiaryOpen,
    isDiaryOpen,
  );
}

/** Paths that belong to the private diary and must stay behind its cover. */
export const isDiaryPath = (path: string): boolean => path === "/diary" || path.startsWith("/diary/") || path === "/new" || path.startsWith("/entry/");
