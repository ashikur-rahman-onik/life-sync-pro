import { isValidDateKey, parseDateKey, timeToMinutes } from "./date";

const BN_DIGITS = "০১২৩৪৫৬৭৮৯";

export const toBn = (v: string | number): string => String(v).replace(/\d/g, (d) => BN_DIGITS[Number(d)]);

/** Bangla digits typed by the user → ASCII digits ("১২৫" → "125"). */
export const fromBn = (s: string): string => s.replace(/[০-৯]/g, (d) => String(BN_DIGITS.indexOf(d)));

export const MONTHS_BN = [
  "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
  "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর",
];
export const WEEKDAYS_BN = ["রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার"];
export const WEEKDAYS_SHORT_BN = ["রবি", "সোম", "মঙ্গল", "বুধ", "বৃহ", "শুক্র", "শনি"];

export function formatDateBn(key: string, opts: { weekday?: boolean; year?: boolean } = {}): string {
  if (!isValidDateKey(key)) return key;
  const d = parseDateKey(key);
  const base = `${toBn(d.getDate())} ${MONTHS_BN[d.getMonth()]}`;
  const withYear = opts.year === false ? base : `${base} ${toBn(d.getFullYear())}`;
  return opts.weekday ? `${WEEKDAYS_BN[d.getDay()]}, ${withYear}` : withYear;
}

export function monthLabelBn(year: number, month: number): string {
  return `${MONTHS_BN[month - 1]} ${toBn(year)}`;
}

export function periodOfDay(minutes: number): string {
  const h = Math.floor((((minutes % 1440) + 1440) % 1440) / 60);
  if (h >= 4 && h < 6) return "ভোর";
  if (h >= 6 && h < 12) return "সকাল";
  if (h >= 12 && h < 15) return "দুপুর";
  if (h >= 15 && h < 18) return "বিকাল";
  if (h >= 18 && h < 20) return "সন্ধ্যা";
  return "রাত";
}

/** "08:30" → "সকাল ৮:৩০" */
export function formatTimeBn(time: string): string {
  const mins = timeToMinutes(time);
  const h24 = Math.floor(mins / 60);
  const m = mins % 60;
  const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${periodOfDay(mins)} ${toBn(h12)}:${toBn(String(m).padStart(2, "0"))}`;
}

/** 250 → "২৫০ মি.লি.", 1500 → "১.৫ লিটার" */
export function formatMl(ml: number): string {
  if (ml >= 1000) {
    const liters = Math.round(ml / 10) / 100;
    return `${toBn(String(liters))} লিটার`;
  }
  return `${toBn(Math.round(ml))} মি.লি.`;
}

/** Short litres form used in progress rings: 1250 → "১.২৫ লি." */
export function formatLitersShort(ml: number): string {
  return `${toBn(String(Math.round(ml / 10) / 100))} লি.`;
}

/** Quantity with half support: 0.5 → "½", 1.5 → "১½", 2 → "২" */
export function formatNumberHalf(n: number): string {
  const whole = Math.floor(n);
  const frac = n - whole;
  if (Math.abs(frac - 0.5) < 1e-9) return whole === 0 ? "½" : `${toBn(whole)}½`;
  return toBn(String(Math.round(n * 100) / 100));
}
