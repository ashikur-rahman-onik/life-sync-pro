type Handler = () => void;
let handler: Handler | null = null;

export function registerCelebrateHandler(fn: Handler | null): void {
  handler = fn;
}

/** Small confetti burst for goals reached. */
export function celebrate(): void {
  handler?.();
}
