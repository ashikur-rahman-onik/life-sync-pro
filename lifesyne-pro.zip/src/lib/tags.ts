/** "পরিবার, কাজ ,, " → ["পরিবার", "কাজ"] (max 10, no duplicates) */
export function parseTags(input: string): string[] {
  return [...new Set(input.split(/[,،]/).map((t) => t.trim().replace(/^#/, "")).filter(Boolean))].slice(0, 10);
}
