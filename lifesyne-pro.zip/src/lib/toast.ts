type ToastHandler = (message: string) => void;

let handler: ToastHandler | null = null;

/** Lets non-React code (notification actions, updater) show a toast. */
export function registerToastHandler(fn: ToastHandler | null): void {
  handler = fn;
}

export function showToast(message: string): void {
  handler?.(message);
}
