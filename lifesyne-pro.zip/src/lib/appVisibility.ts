import { App as CapApp } from "@capacitor/app";
import { isNative } from "@/native/platform";

/**
 * Calls `onReturn(awayMs)` every time the app comes back to the foreground,
 * with how long it was in the background (works in the browser and the Android app).
 */
export function onReturnFromBackground(onReturn: (awayMs: number) => void): () => void {
  let hiddenAt: number | null = null;
  const hide = () => {
    if (hiddenAt === null) hiddenAt = Date.now();
  };
  const show = () => {
    if (hiddenAt === null) return;
    const away = Date.now() - hiddenAt;
    hiddenAt = null;
    onReturn(away);
  };
  const onVisibility = () => (document.visibilityState === "hidden" ? hide() : show());
  document.addEventListener("visibilitychange", onVisibility);

  let removeNative: (() => void) | undefined;
  let disposed = false;
  if (isNative()) {
    void CapApp.addListener("appStateChange", ({ isActive }) => (isActive ? show() : hide())).then((handle) => {
      if (disposed) void handle.remove();
      else removeNative = () => void handle.remove();
    });
  }
  return () => {
    disposed = true;
    document.removeEventListener("visibilitychange", onVisibility);
    removeNative?.();
  };
}
