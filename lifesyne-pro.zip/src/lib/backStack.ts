/**
 * Stack of "things the Android back button should close first"
 * (open sheets, dialogs, the lock screen…). Top of the stack wins.
 */
type BackHandler = () => void;

const stack: BackHandler[] = [];

export function pushBackHandler(fn: BackHandler): () => void {
  stack.push(fn);
  return () => {
    const i = stack.lastIndexOf(fn);
    if (i >= 0) stack.splice(i, 1);
  };
}

/** Runs the top handler. Returns true if something consumed the back press. */
export function consumeBack(): boolean {
  const top = stack[stack.length - 1];
  if (!top) return false;
  top();
  return true;
}
