const LOWER = "abcdefghijkmnopqrstuvwxyz"; // no easy-to-confuse l
const UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ"; // no I / O
const DIGITS = "23456789"; // no 0 / 1
const SYMBOLS = "!@#$%^&*?-_+=";

function randomIndex(max: number): number {
  const limit = Math.floor(0x100000000 / max) * max; // avoids modulo bias
  const buf = new Uint32Array(1);
  do crypto.getRandomValues(buf);
  while (buf[0] >= limit);
  return buf[0] % max;
}

/** Random strong password that always contains every character type. */
export function generatePassword(length = 14): string {
  const n = Math.max(8, Math.min(40, Math.round(length)));
  const sets = [LOWER, UPPER, DIGITS, SYMBOLS];
  const all = sets.join("");
  const chars = sets.map((set) => set[randomIndex(set.length)]);
  while (chars.length < n) chars.push(all[randomIndex(all.length)]);
  for (let i = chars.length - 1; i > 0; i--) {
    const j = randomIndex(i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join("");
}

export interface Strength {
  score: 0 | 1 | 2 | 3 | 4;
  label: string;
  color: string;
}

export function passwordStrength(password: string): Strength {
  if (!password) return { score: 0, label: "", color: "#9ca3af" };
  let points = 0;
  if (password.length >= 8) points++;
  if (password.length >= 12) points++;
  if (/[a-z]/.test(password) && /[A-Z]/.test(password)) points++;
  if (/\d/.test(password)) points++;
  if (/[^A-Za-z0-9]/.test(password)) points++;
  if (/^(.)\1+$/.test(password) || /^(0123|1234|abcd|password|qwerty)/i.test(password)) points = Math.min(points, 1);
  const score = Math.min(4, Math.max(0, points - (password.length < 6 ? 1 : 0))) as Strength["score"];
  const table: Strength[] = [
    { score: 0, label: "খুব দুর্বল", color: "#ef4444" },
    { score: 1, label: "দুর্বল", color: "#f97316" },
    { score: 2, label: "মোটামুটি", color: "#eab308" },
    { score: 3, label: "ভালো", color: "#84cc16" },
    { score: 4, label: "শক্তিশালী", color: "#22c55e" },
  ];
  return table[score];
}
