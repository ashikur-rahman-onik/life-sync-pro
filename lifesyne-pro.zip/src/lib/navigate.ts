/** Navigate from outside React (HashRouter lives in location.hash). */
export function navigateTo(path: string): void {
  window.location.hash = `#${path}`;
}
