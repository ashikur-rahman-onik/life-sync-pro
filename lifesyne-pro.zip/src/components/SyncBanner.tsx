import { Link } from "react-router-dom";
import { useSyncStatus } from "@/firebase/status";

/** Tells the user (only when needed) that cloud saving is blocked or waiting for internet. */
export default function SyncBanner() {
  const { error, pending, fromCache } = useSyncStatus();

  if (error === "permission") {
    return (
      <div className="safe-top bg-red-500 px-4 py-2 text-center text-xs font-semibold text-white">
        ⚠️ ক্লাউডে ডেটা সেভ হচ্ছে না — Firestore Rules সেট করা নেই।{" "}
        <Link to="/settings" className="underline">
          সেটিংস দেখুন
        </Link>
      </div>
    );
  }
  if (error === "other") {
    return <div className="safe-top bg-amber-500 px-4 py-2 text-center text-xs font-semibold text-white">⚠️ ক্লাউড সিঙ্কে সমস্যা হচ্ছে। ইন্টারনেট চেক করুন।</div>;
  }
  if (pending && fromCache) {
    return <div className="safe-top bg-amber-500/90 px-4 py-1.5 text-center text-[11px] font-semibold text-white">📴 অফলাইন — অনলাইনে এলেই নতুন ডেটা সিঙ্ক হবে</div>;
  }
  return null;
}
