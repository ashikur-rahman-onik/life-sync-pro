import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { pushBackHandler } from "@/lib/backStack";
import { registerToastHandler } from "@/lib/toast";
import { Button } from "./ui";

interface ConfirmOptions {
  title: string;
  message?: string;
  confirmText?: string;
  danger?: boolean;
}
type ConfirmFn = (options: ConfirmOptions) => Promise<boolean>;

const ConfirmContext = createContext<ConfirmFn>(() => Promise.resolve(false));

export const useConfirm = (): ConfirmFn => useContext(ConfirmContext);

/** Toast + confirm dialog shared by the whole app. */
export function FeedbackProvider({ children }: { children: ReactNode }) {
  const [toast, setToast] = useState<{ id: number; message: string } | null>(null);
  const [dialog, setDialog] = useState<ConfirmOptions | null>(null);
  const resolver = useRef<((v: boolean) => void) | null>(null);

  useEffect(() => {
    registerToastHandler((message) => setToast({ id: Date.now(), message }));
    return () => registerToastHandler(null);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2600);
    return () => clearTimeout(t);
  }, [toast]);

  const settle = useCallback((value: boolean) => {
    resolver.current?.(value);
    resolver.current = null;
    setDialog(null);
  }, []);

  const confirm = useCallback<ConfirmFn>((options) => {
    resolver.current?.(false);
    return new Promise<boolean>((resolve) => {
      resolver.current = resolve;
      setDialog(options);
    });
  }, []);

  useEffect(() => {
    if (!dialog) return;
    return pushBackHandler(() => settle(false));
  }, [dialog, settle]);

  const value = useMemo(() => confirm, [confirm]);

  return (
    <ConfirmContext.Provider value={value}>
      {children}
      {toast && (
        <div key={toast.id} className="animate-fade-in-up pointer-events-none fixed inset-x-4 bottom-28 z-[120] mx-auto max-w-sm rounded-2xl bg-[#142033] px-4 py-3 text-center text-sm font-medium text-white shadow-xl">
          {toast.message}
        </div>
      )}
      {dialog && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/45 px-6" onClick={() => settle(false)}>
          <div role="alertdialog" aria-modal="true" onClick={(e) => e.stopPropagation()} className="animate-fade-in-up w-full max-w-sm rounded-3xl bg-[var(--color-paper)] p-5 shadow-2xl dark:bg-[#17212f]">
            <h2 className="text-base font-bold">{dialog.title}</h2>
            {dialog.message && <p className="mt-2 text-sm leading-relaxed opacity-70">{dialog.message}</p>}
            <div className="mt-5 flex gap-2">
              <Button variant="ghost" block onClick={() => settle(false)}>
                বাতিল
              </Button>
              <Button variant={dialog.danger ? "danger" : "primary"} block onClick={() => settle(true)}>
                {dialog.confirmText ?? "ঠিক আছে"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </ConfirmContext.Provider>
  );
}
