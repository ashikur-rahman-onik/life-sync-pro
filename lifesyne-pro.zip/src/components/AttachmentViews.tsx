import { useState } from "react";
import type { Attachment } from "@/domain/types";
import { formatBytes } from "@/domain/attachments";
import { useAttachmentSrc } from "@/media/attachments";
import { pushBackHandler } from "@/lib/backStack";
import { useEffect } from "react";

/** Rotation that is the same every time for the same photo (so it never "jumps"). */
export function tilt(id: string): number {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0;
  return ((Math.abs(h) % 70) - 35) / 10; // −3.5° … +3.5°
}

function Lightbox({ src, name, onClose }: { src: string; name: string; onClose: () => void }) {
  useEffect(() => pushBackHandler(onClose), [onClose]);
  return (
    <div className="fixed inset-0 z-[140] flex flex-col items-center justify-center bg-black/90 p-4" onClick={onClose}>
      <img src={src} alt={name} className="max-h-[80vh] max-w-full rounded object-contain" />
      <p className="mt-3 text-xs text-white/70">{name}</p>
      <button type="button" className="mt-3 rounded-full bg-white/15 px-5 py-2 text-sm text-white">
        ✕ বন্ধ করুন
      </button>
    </div>
  );
}

/** A photo "pasted" on the page with tape; tap to view it full screen. */
export function Polaroid({ att, size = 140 }: { att: Attachment; size?: number }) {
  const src = useAttachmentSrc(att, 500);
  const full = useAttachmentSrc(att);
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" className="polaroid" style={{ ["--rot" as string]: `${tilt(att.id)}deg` }} onClick={() => src && setOpen(true)} aria-label={att.name}>
        {src ? (
          <img src={src} alt={att.name} className="block rounded-[1px] object-cover" style={{ width: size, height: size * 0.82 }} />
        ) : (
          <span className="flex items-center justify-center bg-black/5 text-[11px] text-black/50" style={{ width: size, height: size * 0.82 }}>
            ছবি অন্য ফোনে আপলোডের অপেক্ষায়
          </span>
        )}
        {att.url === null && src && <span className="absolute bottom-1 right-2 text-[10px] text-black/50">⏳ আপলোড বাকি</span>}
      </button>
      {open && full && <Lightbox src={full} name={att.name} onClose={() => setOpen(false)} />}
    </>
  );
}

/** Non-image file as a small card; opens in the browser/viewer. */
export function FileChip({ att }: { att: Attachment }) {
  const inner = (
    <>
      <span className="text-xl">📄</span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-xs font-semibold">{att.name}</span>
        <span className="block text-[10px] opacity-60">
          {formatBytes(att.bytes)} {att.url === null ? "· ⏳ আপলোড বাকি" : ""}
        </span>
      </span>
    </>
  );
  const cls = "flex items-center gap-2 rounded-xl border border-black/10 bg-white/60 px-3 py-2 dark:bg-white/5";
  return att.url ? (
    <a href={att.url} target="_blank" rel="noopener noreferrer" className={cls}>
      {inner}
    </a>
  ) : (
    <div className={cls}>{inner}</div>
  );
}

/** Photos as polaroids, other files as chips. */
export function AttachmentGallery({ attachments, size }: { attachments: Attachment[]; size?: number }) {
  const images = attachments.filter((a) => a.kind === "image");
  const files = attachments.filter((a) => a.kind !== "image");
  return (
    <div className="space-y-4">
      {images.length > 0 && (
        <div className="flex flex-wrap items-start gap-x-5 gap-y-6 px-1 pt-3">
          {images.map((a) => (
            <Polaroid key={a.id} att={a} size={size} />
          ))}
        </div>
      )}
      {files.length > 0 && (
        <div className="space-y-2">
          {files.map((a) => (
            <FileChip key={a.id} att={a} />
          ))}
        </div>
      )}
    </div>
  );
}
