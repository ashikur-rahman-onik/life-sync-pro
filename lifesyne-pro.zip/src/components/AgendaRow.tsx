import { formatTimeBn, toBn } from "@/lib/bn";
import { celebrate } from "@/lib/celebrate";
import { changeHabitCount, markDose, markReminder, undoDose, undoReminder } from "@/store/actions";
import { isFinished, type AgendaItem } from "@/domain/today";

const BADGE: Record<string, { text: string; cls: string }> = {
  taken: { text: "হয়েছে", cls: "bg-green-500/15 text-green-600" },
  done: { text: "হয়েছে", cls: "bg-green-500/15 text-green-600" },
  skipped: { text: "বাদ", cls: "bg-gray-500/15 text-gray-500" },
  missed: { text: "মিস", cls: "bg-red-500/15 text-red-500" },
  due: { text: "এখন", cls: "bg-amber-500/20 text-amber-600" },
  upcoming: { text: "আসছে", cls: "bg-black/5 opacity-70 dark:bg-white/10" },
  open: { text: "বাকি", cls: "bg-black/5 opacity-70 dark:bg-white/10" },
};

const pill = "rounded-full px-3 py-1 text-xs font-semibold active:scale-95";

/** One line of "today's plan" with the right buttons for medicine, reminder or habit. */
export default function AgendaRow({ item }: { item: AgendaItem }) {
  const finished = isFinished(item);
  const badge = BADGE[item.status];

  return (
    <div className={`rounded-2xl border border-[var(--color-accent)]/15 bg-white/70 p-3 dark:bg-white/5 ${finished ? "opacity-70" : ""}`}>
      <div className="flex items-start gap-3">
        <span className="text-2xl">{item.icon}</span>
        <div className="min-w-0 flex-1">
          <p className={`truncate text-sm font-bold ${finished ? "line-through" : ""}`}>{item.title}</p>
          {item.subtitle && <p className="truncate text-xs opacity-70">{item.subtitle}</p>}
          <p className="mt-0.5 text-[11px] opacity-60">{item.time ? formatTimeBn(item.time) : "যেকোনো সময়"}</p>
        </div>
        <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold ${badge.cls}`}>{badge.text}</span>
      </div>

      <div className="mt-2.5 flex items-center gap-2">
        {item.kind === "habit" ? (
          <>
            <button type="button" className={`${pill} bg-black/5 dark:bg-white/10`} onClick={() => changeHabitCount(item.habit.id, item.date, -1)} disabled={item.count === 0} aria-label="কমান">
              −
            </button>
            <span className="min-w-12 text-center text-sm font-bold">
              {toBn(item.count)}/{toBn(item.habit.target)}
            </span>
            <button
              type="button"
              className={`${pill} flex-1 text-white`}
              style={{ backgroundColor: item.habit.color }}
              onClick={() => {
                changeHabitCount(item.habit.id, item.date, 1);
                if (item.count + 1 === item.habit.target) celebrate();
              }}
            >
              ✅ করেছি
            </button>
          </>
        ) : finished ? (
          <button
            type="button"
            className={`${pill} bg-black/5 dark:bg-white/10`}
            onClick={() => (item.kind === "med" ? undoDose(item.key) : undoReminder(item.key))}
          >
            ↩︎ বাতিল করুন
          </button>
        ) : (
          <>
            <button
              type="button"
              className={`${pill} flex-1 bg-[var(--color-accent)] text-white`}
              onClick={() => (item.kind === "med" ? markDose(item.medicine, item.slot, item.date, "taken") : markReminder(item.reminder, item.date, item.time, "done"))}
            >
              {item.kind === "med" ? "✅ খেয়েছি" : "✅ হয়েছে"}
            </button>
            <button
              type="button"
              className={`${pill} bg-black/5 dark:bg-white/10`}
              onClick={() => (item.kind === "med" ? markDose(item.medicine, item.slot, item.date, "skipped") : markReminder(item.reminder, item.date, item.time, "skipped"))}
            >
              বাদ
            </button>
          </>
        )}
      </div>
    </div>
  );
}
