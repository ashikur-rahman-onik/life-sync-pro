import { formatTimeBn } from "@/lib/bn";
import { FORM_ICONS, formatDose, RELATION_LABELS, type DoseStatus, type PlannedDose } from "@/domain/medicine";

const BADGE: Record<DoseStatus, { text: string; cls: string }> = {
  taken: { text: "খাওয়া হয়েছে", cls: "bg-green-500/15 text-green-600" },
  skipped: { text: "বাদ দিয়েছেন", cls: "bg-gray-500/15 text-gray-500" },
  missed: { text: "মিস হয়েছে", cls: "bg-red-500/15 text-red-500" },
  due: { text: "এখন খাওয়ার সময়", cls: "bg-amber-500/20 text-amber-600" },
  upcoming: { text: "আসছে", cls: "bg-black/5 opacity-70 dark:bg-white/10" },
};

interface Props {
  dose: PlannedDose;
  status: DoseStatus;
  onTake: () => void;
  onSkip: () => void;
  onUndo: () => void;
}

export default function DoseRow({ dose, status, onTake, onSkip, onUndo }: Props) {
  const { medicine: m, slot } = dose;
  const done = status === "taken" || status === "skipped";
  return (
    <div className={`rounded-2xl border border-[var(--color-med)]/20 bg-white/70 p-3 dark:bg-white/5 ${done ? "opacity-70" : ""}`}>
      <div className="flex items-start gap-3">
        <span className="text-2xl">{FORM_ICONS[m.form]}</span>
        <div className="min-w-0 flex-1">
          <p className={`truncate text-sm font-bold ${status === "taken" ? "line-through" : ""}`}>{m.name}</p>
          <p className="text-xs opacity-70">
            {formatDose(slot.qty, m.form)}
            {m.relation !== "any" && ` · ${RELATION_LABELS[m.relation]}`}
          </p>
          <p className="mt-0.5 text-[11px] opacity-60">{formatTimeBn(dose.time)}</p>
        </div>
        <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold ${BADGE[status].cls}`}>{BADGE[status].text}</span>
      </div>
      <div className="mt-2.5 flex gap-2">
        {done ? (
          <button type="button" onClick={onUndo} className="rounded-full bg-black/5 px-3 py-1 text-xs font-medium dark:bg-white/10">
            ↩︎ বাতিল করুন
          </button>
        ) : (
          <>
            <button type="button" onClick={onTake} className="flex-1 rounded-full bg-[var(--color-med)] px-3 py-1.5 text-xs font-semibold text-white active:scale-95">
              ✅ খেয়েছি
            </button>
            <button type="button" onClick={onSkip} className="rounded-full bg-black/5 px-3 py-1.5 text-xs font-medium dark:bg-white/10">
              বাদ দিন
            </button>
          </>
        )}
      </div>
    </div>
  );
}
