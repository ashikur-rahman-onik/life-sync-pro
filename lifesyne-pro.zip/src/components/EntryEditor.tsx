import { useEffect, useRef, useState } from "react";
import { promptOfTheDay } from "@/domain/prompts";
import type { Attachment } from "@/domain/types";
import { todayKey } from "@/lib/date";
import { parseTags } from "@/lib/tags";
import { useAppData } from "@/store/store";
import AttachmentPicker from "./AttachmentPicker";
import DiaryPaper from "./DiaryPaper";
import MoodPicker from "./MoodPicker";
import { Button } from "./ui";

export interface EntryValues {
  title: string;
  content: string;
  mood: string;
  tags: string[];
  entryDate: string;
  favorite: boolean;
  attachments: Attachment[];
}

interface Props {
  initial?: EntryValues;
  saveLabel: string;
  onSave: (values: EntryValues) => void;
  onCancel?: () => void;
}

const BLANK: EntryValues = { title: "", content: "", mood: "neutral", tags: [], entryDate: "", favorite: false, attachments: [] };

/** The writing page: used for both new pages and editing. */
export default function EntryEditor({ initial, saveLabel, onSave, onCancel }: Props) {
  const { settings } = useAppData();
  const { diary } = settings;
  const [v, setV] = useState<EntryValues>(() => initial ?? { ...BLANK, entryDate: todayKey() });
  const [tagText, setTagText] = useState(() => (initial?.tags ?? []).join(", "));
  const [error, setError] = useState("");
  const area = useRef<HTMLTextAreaElement>(null);
  const set = (patch: Partial<EntryValues>) => setV((prev) => ({ ...prev, ...patch }));

  // grow the text box with the writing so the ruled page keeps scrolling naturally
  useEffect(() => {
    const el = area.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.max(el.scrollHeight, 240)}px`;
  }, [v.content, diary.textSize, diary.font]);

  const save = () => {
    if (!v.content.trim() && v.attachments.length === 0) {
      setError("কিছু একটা লিখুন বা ছবি যোগ করুন 🙂");
      return;
    }
    onSave({ ...v, title: v.title.trim(), content: v.content.trim(), tags: parseTags(tagText), entryDate: v.entryDate || todayKey() });
  };

  const prompt = promptOfTheDay(todayKey());

  return (
    <div>
      <div className="mb-3 flex items-center justify-between gap-2">
        <input type="date" value={v.entryDate} max={todayKey()} onChange={(e) => set({ entryDate: e.target.value })} className="rounded-xl border border-[var(--color-accent)]/20 bg-white/70 px-2.5 py-1.5 text-xs dark:bg-white/5" />
        <button type="button" onClick={() => set({ favorite: !v.favorite })} aria-label="প্রিয় পাতা" className={`rounded-full px-3 py-1.5 text-sm ${v.favorite ? "bg-amber-400/25 text-amber-600" : "bg-black/5 opacity-70 dark:bg-white/10"}`}>
          {v.favorite ? "⭐ প্রিয়" : "☆ প্রিয় করুন"}
        </button>
      </div>
      <div className="mb-3">
        <MoodPicker value={v.mood} onChange={(mood) => set({ mood })} />
      </div>

      <DiaryPaper diary={diary} className="pb-5">
        <input value={v.title} onChange={(e) => set({ title: e.target.value })} placeholder="শিরোনাম (ঐচ্ছিক)" className="paper-title block w-full border-0 bg-transparent font-[inherit] outline-none placeholder:opacity-40" />
        <textarea ref={area} value={v.content} onChange={(e) => set({ content: e.target.value })} placeholder="আজকের কথা লিখুন…" className="paper-text placeholder:opacity-40" rows={8} />
        {v.content.trim() === "" && (
          <button type="button" onClick={() => set({ content: `${prompt}\n` })} className="mb-2 text-left text-xs opacity-60">
            💡 আজকের প্রশ্ন: {prompt} <span className="font-semibold underline">(ট্যাপ করে শুরু করুন)</span>
          </button>
        )}
        <div className="pr-1">
          <AttachmentPicker value={v.attachments} onChange={(attachments) => set({ attachments })} />
        </div>
      </DiaryPaper>

      <input value={tagText} onChange={(e) => setTagText(e.target.value)} placeholder="ট্যাগ (কমা দিয়ে ভাগ করুন, যেমন: পরিবার, ভ্রমণ)" className="mt-3 w-full rounded-2xl border border-[var(--color-accent)]/20 bg-white/70 px-4 py-3 text-sm outline-none dark:bg-white/5" />
      {error && <p className="mt-3 text-sm font-medium text-red-500">{error}</p>}
      <div className="mt-4 flex gap-2">
        <Button block className="py-3.5" onClick={save}>
          {saveLabel}
        </Button>
        {onCancel && (
          <Button variant="ghost" onClick={onCancel}>
            বাতিল
          </Button>
        )}
      </div>
    </div>
  );
}
