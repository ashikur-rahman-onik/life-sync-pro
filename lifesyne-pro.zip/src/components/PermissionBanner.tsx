import { useEffect, useState } from "react";
import { getNotificationPermission, requestNotificationPermission, type PermissionStatus } from "@/native/notifications";
import { syncReminders } from "@/native/notifications";
import { getState } from "@/store/store";

/** Asks for the notification permission (Android 13+) — reminders cannot work without it. */
export default function PermissionBanner() {
  const [status, setStatus] = useState<PermissionStatus>("granted");

  useEffect(() => {
    void getNotificationPermission().then(setStatus);
  }, []);

  if (status === "granted" || status === "unsupported") return null;

  const enable = async () => {
    const next = await requestNotificationPermission();
    setStatus(next);
    if (next === "granted") await syncReminders(getState(), true);
  };

  return (
    <div className="mb-4 rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm">
      <p className="font-semibold">🔔 রিমাইন্ডারের জন্য নোটিফিকেশন চালু করুন</p>
      <p className="mt-1 text-xs opacity-70">
        {status === "denied" ? "নোটিফিকেশন বন্ধ আছে। ফোনের Settings → Apps → এই অ্যাপ → Notifications থেকে চালু করুন।" : "অনুমতি না দিলে পানি ও ওষুধের রিমাইন্ডার আসবে না।"}
      </p>
      {status !== "denied" && (
        <button type="button" onClick={() => void enable()} className="mt-3 rounded-full bg-amber-500 px-4 py-1.5 text-xs font-semibold text-white active:scale-95">
          অনুমতি দিন
        </button>
      )}
    </div>
  );
}
