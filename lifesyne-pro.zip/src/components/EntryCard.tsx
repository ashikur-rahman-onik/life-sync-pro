import { Link } from "react-router-dom";
import { formatDateBn } from "@/lib/bn";
import { getMood } from "@/lib/moods";
import type { DiaryEntry } from "@/domain/types";

export default function EntryCard({ entry }: { entry: DiaryEntry }) {
  const mood = getMood(entry.mood);
  return (
    <Link
      to={`/entry/${entry.id}`}
      className="animate-fade-in-up block rounded-2xl border border-[var(--color-accent)]/15 bg-white/70 p-4 shadow-sm transition active:scale-[0.99] dark:bg-white/5"
    >
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-medium opacity-60">{formatDateBn(entry.entryDate)}</span>
        <span className="text-lg" title={mood.label}>
          {mood.emoji}
        </span>
      </div>
      {entry.title ? <h3 className="mt-1.5 font-semibold">{entry.title}</h3> : null}
      <p className="mt-1 line-clamp-2 text-sm leading-relaxed opacity-80">{entry.content}</p>
      {entry.tags.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1.5">
          {entry.tags.map((tag) => (
            <span key={tag} className="rounded-full bg-[var(--color-accent)]/10 px-2 py-0.5 text-[11px] text-[var(--color-accent)]">
              #{tag}
            </span>
          ))}
        </div>
      )}
    </Link>
  );
}
