import { Link } from "react-router-dom";
import { toBn, MONTHS_BN } from "@/lib/bn";
import { parseDateKey } from "@/lib/date";
import { getMood } from "@/lib/moods";
import { useAttachmentSrc } from "@/media/attachments";
import type { DiaryEntry } from "@/domain/types";

/** A diary page in a list: date tab, title, first lines, small photo. */
export default function EntryCard({ entry, pageNumber }: { entry: DiaryEntry; pageNumber?: number }) {
  const mood = getMood(entry.mood);
  const firstImage = entry.attachments.find((a) => a.kind === "image") ?? null;
  const thumb = useAttachmentSrc(firstImage, 200);
  const d = parseDateKey(entry.entryDate);

  return (
    <Link
      to={`/entry/${entry.id}`}
      className="animate-fade-in-up flex gap-3 rounded-xl border-l-4 border-l-red-300/70 bg-[#fbf4e4] p-3 shadow-sm transition active:scale-[0.99] dark:bg-[#2a2320]"
    >
      <div className="flex w-11 shrink-0 flex-col items-center justify-center rounded-lg bg-black/5 py-1 dark:bg-white/10">
        <span className="text-lg font-bold leading-none">{toBn(d.getDate())}</span>
        <span className="mt-0.5 text-[10px] opacity-60">{MONTHS_BN[d.getMonth()].slice(0, 4)}</span>
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <h3 className="truncate text-sm font-semibold">{entry.title || "শিরোনামহীন পাতা"}</h3>
          <span className="shrink-0 text-base" title={mood.label}>
            {entry.favorite ? "🔖" : mood.emoji}
          </span>
        </div>
        {entry.content && <p className="mt-0.5 line-clamp-2 text-xs leading-relaxed opacity-75">{entry.content}</p>}
        <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[10px] opacity-60">
          {pageNumber !== undefined && <span>পাতা {toBn(pageNumber)}</span>}
          {entry.attachments.length > 0 && <span>📎 {toBn(entry.attachments.length)}</span>}
          {entry.tags.slice(0, 3).map((t) => (
            <span key={t}>#{t}</span>
          ))}
        </div>
      </div>
      {thumb && <img src={thumb} alt="" className="h-14 w-14 shrink-0 rotate-3 rounded-sm border-2 border-white object-cover shadow" />}
    </Link>
  );
}
