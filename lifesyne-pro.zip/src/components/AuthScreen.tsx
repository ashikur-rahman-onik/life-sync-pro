import { useState } from "react";
import logo from "@/assets/logo-mark.png";
import { authErrorMessage, requestPasswordReset, signIn, signUp } from "@/firebase/auth";
import { Button, Field, inputClass } from "./ui";

type Mode = "signin" | "signup";

/** Shown only when nobody is logged in. After one login the app stays logged in, even offline. */
export default function AuthScreen() {
  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");

  const submit = async () => {
    setError("");
    setInfo("");
    if (!email.trim() || !password) return setError("ইমেইল ও পাসওয়ার্ড লিখুন");
    if (mode === "signup" && password !== confirm) return setError("দুটি পাসওয়ার্ড মিলছে না");
    setBusy(true);
    try {
      await (mode === "signup" ? signUp(email, password) : signIn(email, password));
    } catch (e) {
      setError(authErrorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const reset = async () => {
    setError("");
    setInfo("");
    if (!email.trim()) return setError("আগে ওপরে ইমেইল লিখুন");
    try {
      await requestPasswordReset(email);
      setInfo("পাসওয়ার্ড রিসেটের লিংক ইমেইলে পাঠানো হয়েছে (স্প্যাম ফোল্ডারও দেখুন)");
    } catch (e) {
      setError(authErrorMessage(e));
    }
  };

  return (
    <main className="safe-top safe-bottom mx-auto flex min-h-screen max-w-sm flex-col justify-center px-6 py-10">
      <div className="mb-8 text-center">
        <img src={logo} alt="" className="mx-auto h-24 w-24" />
        <h1 className="mt-3 text-2xl font-bold">
          LifeSyne <span className="text-[#16c060]">Pro</span>
        </h1>
        <p className="mt-1 text-sm opacity-60">ডায়েরি · পানি · ওষুধ — সব এক জায়গায়</p>
      </div>

      <div className="space-y-3">
        <Field label="ইমেইল">
          <input className={inputClass} type="email" autoComplete="email" inputMode="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
        </Field>
        <Field label="পাসওয়ার্ড" hint={mode === "signup" ? "কমপক্ষে ৬ অক্ষর" : undefined}>
          <input className={inputClass} type="password" autoComplete={mode === "signup" ? "new-password" : "current-password"} value={password} onChange={(e) => setPassword(e.target.value)} />
        </Field>
        {mode === "signup" && (
          <Field label="পাসওয়ার্ড আবার লিখুন">
            <input className={inputClass} type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
          </Field>
        )}
        {error && <p className="text-sm font-medium text-red-500">{error}</p>}
        {info && <p className="text-sm font-medium text-green-600">{info}</p>}
        <Button block className="py-3.5" disabled={busy} onClick={() => void submit()}>
          {busy ? "অপেক্ষা করুন…" : mode === "signup" ? "অ্যাকাউন্ট খুলুন" : "লগইন"}
        </Button>
        {mode === "signin" && (
          <button type="button" onClick={() => void reset()} className="block w-full text-center text-xs font-medium text-[var(--color-accent)]">
            পাসওয়ার্ড ভুলে গেছি
          </button>
        )}
      </div>

      <button type="button" onClick={() => { setMode(mode === "signin" ? "signup" : "signin"); setError(""); setInfo(""); }} className="mt-8 text-center text-sm font-semibold text-[var(--color-accent)]">
        {mode === "signin" ? "নতুন? অ্যাকাউন্ট খুলুন" : "আগে থেকে অ্যাকাউন্ট আছে? লগইন করুন"}
      </button>
      <p className="mt-6 text-center text-[11px] leading-relaxed opacity-50">একবার লগইন করলে সবসময় লগইন থাকবে। ইন্টারনেট ছাড়াও অ্যাপ চলবে, অনলাইনে এলে ডেটা নিজে নিজে সিঙ্ক হবে।</p>
    </main>
  );
}
