import { MOODS } from "@/lib/moods";

export default function MoodPicker({ value, onChange }: { value: string; onChange: (mood: string) => void }) {
  return (
    <div className="flex justify-between gap-2">
      {MOODS.map((m) => (
        <button
          type="button"
          key={m.key}
          onClick={() => onChange(m.key)}
          className={`flex flex-1 flex-col items-center gap-1 rounded-2xl border py-2.5 transition active:scale-95 ${
            value === m.key ? "border-[var(--color-accent)] bg-[var(--color-accent)]/15" : "border-transparent bg-white/60 dark:bg-white/5"
          }`}
        >
          <span className="text-2xl">{m.emoji}</span>
          <span className="text-[10px] font-medium opacity-70">{m.label}</span>
        </button>
      ))}
    </div>
  );
}
