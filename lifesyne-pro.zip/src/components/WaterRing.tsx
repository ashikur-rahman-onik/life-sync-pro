import { formatLitersShort } from "@/lib/bn";
import ProgressRing from "./ProgressRing";

export default function WaterRing({ valueMl, goalMl, size = 150 }: { valueMl: number; goalMl: number | null; size?: number }) {
  const done = goalMl !== null && valueMl >= goalMl;
  return (
    <ProgressRing ratio={goalMl ? valueMl / goalMl : 0} size={size} color={done ? "#22c55e" : "var(--color-water)"}>
      <span className="text-lg font-bold leading-tight">{formatLitersShort(valueMl)}</span>
      <span className="text-[11px] opacity-60">{goalMl ? `/ ${formatLitersShort(goalMl)}` : "লক্ষ্য ঠিক করুন"}</span>
    </ProgressRing>
  );
}
