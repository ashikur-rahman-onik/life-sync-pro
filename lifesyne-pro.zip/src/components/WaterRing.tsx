import { formatLitersShort } from "@/lib/bn";

export default function WaterRing({ valueMl, goalMl, size = 150 }: { valueMl: number; goalMl: number | null; size?: number }) {
  const stroke = size * 0.1;
  const r = (size - stroke) / 2;
  const circumference = 2 * Math.PI * r;
  const ratio = goalMl && goalMl > 0 ? Math.min(1, valueMl / goalMl) : 0;
  const done = goalMl !== null && valueMl >= goalMl;
  const color = done ? "#22c55e" : "var(--color-water)";

  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90" aria-hidden="true">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="currentColor" strokeOpacity={0.1} strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={circumference * (1 - ratio)}
          style={{ transition: "stroke-dashoffset 0.5s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        <span className="text-lg font-bold leading-tight">{formatLitersShort(valueMl)}</span>
        <span className="text-[11px] opacity-60">{goalMl ? `/ ${formatLitersShort(goalMl)}` : "লক্ষ্য ঠিক করুন"}</span>
      </div>
    </div>
  );
}
