import type { CSSProperties, ReactNode } from "react";
import type { DiarySettings } from "@/domain/types";
import { useAttachmentSrc } from "@/media/attachments";

/** CSS-only look of the three cover styles (leather grain, woven cloth, flat). */
function coverBackground(color: string, style: DiarySettings["coverStyle"]): CSSProperties {
  if (style === "leather") {
    return {
      backgroundColor: color,
      backgroundImage:
        "radial-gradient(circle at 20% 15%, rgba(255,255,255,0.14), transparent 45%), radial-gradient(circle at 80% 90%, rgba(0,0,0,0.35), transparent 50%), repeating-radial-gradient(circle at 30% 30%, rgba(0,0,0,0.07) 0 1px, transparent 1px 3px)",
    };
  }
  if (style === "cloth") {
    return {
      backgroundColor: color,
      backgroundImage: "repeating-linear-gradient(0deg, rgba(255,255,255,0.07) 0 1px, transparent 1px 3px), repeating-linear-gradient(90deg, rgba(0,0,0,0.10) 0 1px, transparent 1px 3px)",
    };
  }
  return { backgroundColor: color, backgroundImage: "linear-gradient(135deg, rgba(255,255,255,0.12), rgba(0,0,0,0.18))" };
}

interface Props {
  diary: DiarySettings;
  /** Cover width in px (height follows the book proportions). */
  width?: number;
  children?: ReactNode;
  /** Open-book animation: the cover swings away. */
  opening?: boolean;
}

/** A realistic closed diary: spine, page edges, elastic band, bookmark ribbon, title plate. */
export default function DiaryCover({ diary, width = 220, opening = false, children }: Props) {
  const image = useAttachmentSrc(diary.coverImage, 700);
  const height = Math.round(width * 1.36);
  const hasImage = image !== null;

  return (
    <div className="relative mx-auto" style={{ width, height, perspective: 1200 }}>
      {/* pages peeking out at the right and bottom */}
      <div className="absolute inset-y-1.5 right-0 w-3 rounded-r-md bg-[#f4ecd8] shadow-inner" style={{ backgroundImage: "repeating-linear-gradient(0deg, #e6dcc2 0 1px, #f7f0de 1px 3px)" }} />
      <div
        className="absolute inset-0 origin-left overflow-hidden rounded-l-md rounded-r-xl shadow-[0_18px_40px_-12px_rgba(0,0,0,0.55)] transition-transform duration-700 ease-in-out"
        style={{ ...coverBackground(diary.coverColor, diary.coverStyle), transform: opening ? "rotateY(-115deg)" : "rotateY(0deg)", transformStyle: "preserve-3d" }}
      >
        {hasImage && <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover" />}
        {hasImage && <div className="absolute inset-0 bg-gradient-to-t from-black/45 via-transparent to-black/10" />}
        {/* spine shading */}
        <div className="absolute inset-y-0 left-0 w-5 bg-gradient-to-r from-black/45 via-black/15 to-transparent" />
        <div className="absolute inset-y-0 left-5 w-px bg-white/15" />
        {/* stitched border */}
        {!hasImage && <div className="absolute inset-3 rounded-lg border border-dashed border-white/25" />}
        {/* elastic band */}
        <div className="absolute inset-y-0 right-5 w-2.5 bg-black/35 shadow-[0_0_4px_rgba(0,0,0,0.5)]" />
        {/* bookmark ribbon */}
        <div className="absolute -bottom-1 right-12 h-10 w-3.5" style={{ backgroundColor: diary.ribbon, clipPath: "polygon(0 0, 100% 0, 100% 100%, 50% 80%, 0 100%)" }} />

        <div className="absolute inset-0 flex flex-col items-center justify-center px-8 text-center text-white">
          {!hasImage && <span className="mb-3 text-4xl drop-shadow">{diary.emblem}</span>}
          <div className={`rounded-md px-3 py-2 ${hasImage ? "bg-black/45 backdrop-blur-[2px]" : "border border-white/30 bg-black/10"}`}>
            <p className="font-diary-script text-xl leading-snug drop-shadow-md">{diary.title}</p>
            {diary.subtitle && <p className="mt-0.5 text-[11px] tracking-wide opacity-85">{diary.subtitle}</p>}
          </div>
          {hasImage && <span className="absolute bottom-6 text-2xl drop-shadow">{diary.emblem}</span>}
        </div>
        {children}
      </div>
    </div>
  );
}
