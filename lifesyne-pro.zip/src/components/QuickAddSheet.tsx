import { useNavigate } from "react-router-dom";
import { effectiveWaterGoal } from "@/domain/reminders";
import { waterTotalForDate } from "@/domain/water";
import { formatMl } from "@/lib/bn";
import { celebrate } from "@/lib/celebrate";
import { todayKey } from "@/lib/date";
import { showToast } from "@/lib/toast";
import { addWater } from "@/store/actions";
import { useAppData } from "@/store/store";
import { Modal } from "./ui";

/** Logs water and fires the confetti when that glass completes today's goal. */
export function drinkWater(ml: number, name: string, drunkBefore: number, goal: number | null): void {
  addWater(ml, name);
  showToast(`💧 ${formatMl(ml)} পানি যোগ হয়েছে`);
  if (goal !== null && drunkBefore < goal && drunkBefore + ml >= goal) {
    celebrate();
    showToast("🎉 অভিনন্দন! আজকের পানির লক্ষ্য পূরণ হয়েছে");
  }
}

/** The big "+" button: one place to add anything. */
export default function QuickAddSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const navigate = useNavigate();
  const data = useAppData();
  const container = data.containers.find((c) => c.id === data.settings.water.defaultContainerId) ?? data.containers[0];

  const go = (path: string) => {
    onClose();
    navigate(path);
  };

  const items: { icon: string; label: string; onClick: () => void }[] = [
    { icon: "✍️", label: "ডায়েরি লিখুন", onClick: () => go("/new") },
    {
      icon: "💧",
      label: container ? `পানি খেলাম (${formatMl(container.ml)})` : "পানি",
      onClick: () => {
        if (container) drinkWater(container.ml, container.name, waterTotalForDate(data.waterLogs, todayKey()), effectiveWaterGoal(data.settings));
        onClose();
      },
    },
    { icon: "⏰", label: "নতুন রিমাইন্ডার", onClick: () => go("/reminders/new") },
    { icon: "🔁", label: "নতুন অভ্যাস", onClick: () => go("/habits/new") },
    { icon: "💊", label: "ওষুধ যোগ", onClick: () => go("/medicine/new") },
    { icon: "📋", label: "প্রেসক্রিপশন", onClick: () => go("/prescription/new") },
  ];

  return (
    <Modal open={open} onClose={onClose} title="কী যোগ করবেন?">
      <div className="grid grid-cols-3 gap-3 pb-2">
        {items.map((i) => (
          <button key={i.label} type="button" onClick={i.onClick} className="flex flex-col items-center gap-1.5 rounded-2xl bg-white/70 px-2 py-4 text-center active:scale-95 dark:bg-white/5">
            <span className="text-3xl">{i.icon}</span>
            <span className="text-xs font-semibold leading-tight">{i.label}</span>
          </button>
        ))}
      </div>
    </Modal>
  );
}
