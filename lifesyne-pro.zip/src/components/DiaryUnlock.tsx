import { useState } from "react";
import { authErrorMessage, verifyAccountPassword } from "@/firebase/auth";
import { createLockRecord, DIARY_PASSWORD_MIN, isValidDiaryPassword, openDiary, resetDiaryAttempts, verifyDiaryPassword } from "@/lib/diaryLock";
import { toBn } from "@/lib/bn";
import { showToast } from "@/lib/toast";
import { updateSettings } from "@/store/actions";
import { useAppData } from "@/store/store";
import DiaryCover from "./DiaryCover";
import { Button, inputClass } from "./ui";

type Mode = "password" | "forgot" | "reset";

/** The closed diary on screen. Tap to open, or enter the diary password first. */
export default function DiaryUnlock() {
  const { settings } = useAppData();
  const { diary } = settings;
  const lock = diary.lock;

  const [mode, setMode] = useState<Mode>("password");
  const [text, setText] = useState("");
  const [text2, setText2] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [opening, setOpening] = useState(false);

  const swingOpen = () => {
    setOpening(true);
    setTimeout(openDiary, 650);
  };

  const submitPassword = async () => {
    if (!lock) return swingOpen();
    setBusy(true);
    setError("");
    try {
      const result = await verifyDiaryPassword(lock, text);
      if (result.ok) swingOpen();
      else {
        setText("");
        setError(result.waitMs > 0 ? `অনেকবার ভুল হয়েছে। ${toBn(Math.ceil(result.waitMs / 1000))} সেকেন্ড পরে আবার চেষ্টা করুন` : "পাসওয়ার্ড সঠিক নয়");
      }
    } catch {
      setError("যাচাই করা যায়নি, আবার চেষ্টা করুন");
    } finally {
      setBusy(false);
    }
  };

  const submitForgot = async () => {
    setBusy(true);
    setError("");
    try {
      await verifyAccountPassword(text);
      resetDiaryAttempts();
      setText("");
      setMode("reset");
    } catch (e) {
      setError(authErrorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const submitReset = async (skip: boolean) => {
    if (!skip) {
      if (!isValidDiaryPassword(text)) return setError(`কমপক্ষে ${toBn(DIARY_PASSWORD_MIN)} অক্ষরের পাসওয়ার্ড দিন`);
      if (text !== text2) return setError("দুটি পাসওয়ার্ড মিলছে না");
      setBusy(true);
      try {
        const record = await createLockRecord(text);
        updateSettings((s) => ({ ...s, diary: { ...s.diary, lock: record } }));
        showToast("✅ নতুন ডায়েরি পাসওয়ার্ড সেট হয়েছে");
      } finally {
        setBusy(false);
      }
    }
    swingOpen();
  };

  const go = (m: Mode) => {
    setMode(m);
    setText("");
    setText2("");
    setError("");
  };

  return (
    <main className="safe-top flex min-h-[calc(100vh-7rem)] flex-col items-center justify-center px-6 py-8">
      <DiaryCover diary={diary} width={210} opening={opening} />

      <div className="mt-9 w-full max-w-xs text-center">
        {mode === "password" && (
          <>
            {lock ? (
              <>
                <p className="mb-3 text-sm font-medium opacity-70">🔒 খুলতে ডায়েরির পাসওয়ার্ড দিন</p>
                <input
                  type="password"
                  autoComplete="off"
                  className={`${inputClass} text-center tracking-widest`}
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && void submitPassword()}
                  placeholder="পাসওয়ার্ড"
                />
                {error && <p className="mt-2 text-xs font-medium text-red-500">{error}</p>}
                <Button block className="mt-3 py-3" disabled={busy || !text} onClick={() => void submitPassword()}>
                  📖 ডায়েরি খুলুন
                </Button>
                <button type="button" onClick={() => go("forgot")} className="mt-4 text-xs font-medium text-[var(--color-accent)]">
                  পাসওয়ার্ড ভুলে গেছি
                </button>
              </>
            ) : (
              <Button block className="py-3.5" onClick={swingOpen}>
                📖 ডায়েরি খুলুন
              </Button>
            )}
          </>
        )}

        {mode === "forgot" && (
          <>
            <p className="mb-1 text-sm font-semibold">পাসওয়ার্ড ভুলে গেছেন?</p>
            <p className="mb-3 text-xs opacity-60">আপনার অ্যাকাউন্টের (লগইনের) পাসওয়ার্ড দিন। ঠিক হলে ডায়েরি খুলবে এবং নতুন ডায়েরি পাসওয়ার্ড দিতে পারবেন। ইন্টারনেট লাগবে।</p>
            <input type="password" className={`${inputClass} text-center`} value={text} onChange={(e) => setText(e.target.value)} placeholder="অ্যাকাউন্টের পাসওয়ার্ড" />
            {error && <p className="mt-2 text-xs font-medium text-red-500">{error}</p>}
            <div className="mt-3 flex gap-2">
              <Button variant="ghost" block onClick={() => go("password")}>
                ফিরে যান
              </Button>
              <Button block disabled={busy || !text} onClick={() => void submitForgot()}>
                যাচাই করুন
              </Button>
            </div>
          </>
        )}

        {mode === "reset" && (
          <>
            <p className="mb-1 text-sm font-semibold">✅ যাচাই সম্পন্ন</p>
            <p className="mb-3 text-xs opacity-60">নতুন ডায়েরি পাসওয়ার্ড দিন (বা এখন বাদ দিয়ে শুধু খুলুন)।</p>
            <input type="password" className={`${inputClass} text-center`} value={text} onChange={(e) => setText(e.target.value)} placeholder="নতুন পাসওয়ার্ড" />
            <input type="password" className={`${inputClass} mt-2 text-center`} value={text2} onChange={(e) => setText2(e.target.value)} placeholder="আবার লিখুন" />
            {error && <p className="mt-2 text-xs font-medium text-red-500">{error}</p>}
            <Button block className="mt-3" disabled={busy} onClick={() => void submitReset(false)}>
              সেট করে খুলুন
            </Button>
            <button type="button" onClick={() => void submitReset(true)} className="mt-3 text-xs font-medium text-[var(--color-accent)]">
              এখন বাদ দিন, শুধু খুলুন
            </button>
          </>
        )}
      </div>
    </main>
  );
}
