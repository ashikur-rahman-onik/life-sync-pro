import type { ReactNode } from "react";
import type { DiarySettings } from "@/domain/types";

/** A sheet of diary paper styled by the user's paper / tone / font / size choices. */
export default function DiaryPaper({ diary, children, className = "", minHeight }: { diary: DiarySettings; children: ReactNode; className?: string; minHeight?: string }) {
  return (
    <div className={`paper diary-font-${diary.font} ${className}`} data-style={diary.paper} data-tone={diary.paperTone} data-size={diary.textSize} style={{ minHeight }}>
      {children}
    </div>
  );
}
