import type { CSSProperties, ReactNode } from "react";
import type { DiarySettings } from "@/domain/types";

/** A sheet of diary paper styled by the user's paper / tone / font / size choices. */
export default function DiaryPaper({ diary, children, className = "", minHeight, style }: { diary: DiarySettings; children: ReactNode; className?: string; minHeight?: string; style?: CSSProperties }) {
  return (
    <div className={`paper diary-font-${diary.font} ${className}`} data-style={diary.paper} data-tone={diary.paperTone} data-size={diary.textSize} style={{ minHeight, ...style }}>
      {children}
    </div>
  );
}
