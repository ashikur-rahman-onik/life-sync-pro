import { useCallback, useEffect, useState, type ReactNode } from "react";
import { App as CapApp } from "@capacitor/app";
import { onReturnFromBackground } from "@/lib/appVisibility";
import { pushBackHandler } from "@/lib/backStack";
import { getAutoLockSec, hasPin, removePin, verifyPin } from "@/lib/security";
import { toBn } from "@/lib/bn";
import { isNative } from "@/native/platform";
import { authErrorMessage, verifyAccountPassword } from "@/firebase/auth";
import { Button, inputClass } from "./ui";

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫"];

/** Locks the app behind the PIN, and re-locks after the app stayed in the background for a while. */
export default function LockGate({ children }: { children: ReactNode }) {
  const [locked, setLocked] = useState(() => hasPin());
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<"pin" | "forgot">("pin");
  const [password, setPassword] = useState("");
  const [forgotError, setForgotError] = useState("");

  /* Re-lock after the configured time in the background. */
  useEffect(
    () =>
      onReturnFromBackground((away) => {
        const limit = getAutoLockSec();
        if (hasPin() && limit >= 0 && away >= limit * 1000) {
          setPin("");
          setError("");
          setLocked(true);
        }
      }),
    [],
  );

  /* While locked, Android back should leave the app instead of going "behind" the lock. */
  useEffect(() => {
    if (!locked) return;
    return pushBackHandler(() => {
      if (isNative()) void CapApp.exitApp();
    });
  }, [locked]);

  const submit = useCallback(async (value: string) => {
    setBusy(true);
    try {
      const result = await verifyPin(value);
      if (result.ok) {
        setLocked(false);
        setPin("");
        setError("");
      } else {
        setPin("");
        setError(
          result.waitMs > 0
            ? `অনেকবার ভুল হয়েছে। ${toBn(Math.ceil(result.waitMs / 1000))} সেকেন্ড পরে আবার চেষ্টা করুন`
            : "পিন সঠিক নয়, আবার চেষ্টা করুন",
        );
      }
    } catch {
      setError("পিন যাচাই করা যায়নি");
      setPin("");
    } finally {
      setBusy(false);
    }
  }, []);

  const press = (key: string) => {
    if (busy) return;
    if (key === "⌫") {
      setPin((p) => p.slice(0, -1));
      return;
    }
    if (pin.length >= 4) return;
    setError("");
    const next = pin + key;
    setPin(next);
    if (next.length === 4) void submit(next);
  };

  /* Forgot PIN: prove it is you with the account password, then the PIN is removed (no data is deleted). */
  const resetPin = async () => {
    setBusy(true);
    setForgotError("");
    try {
      await verifyAccountPassword(password);
      removePin();
      setLocked(false);
      setMode("pin");
      setPassword("");
    } catch (e) {
      setForgotError(authErrorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  if (!locked) return <>{children}</>;

  if (mode === "forgot") {
    return (
      <div className="safe-top safe-bottom fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[var(--color-paper)] px-6 dark:bg-[var(--color-paper-dark)]">
        <div className="w-full max-w-sm">
          <h1 className="text-lg font-semibold">পিন ভুলে গেছেন?</h1>
          <p className="mt-1 text-sm opacity-60">আপনার অ্যাকাউন্টের পাসওয়ার্ড দিন। ঠিক হলে পিন বন্ধ হয়ে যাবে (কোনো ডেটা মুছবে না), পরে সেটিংস থেকে নতুন পিন দিতে পারবেন। এজন্য ইন্টারনেট লাগবে।</p>
          <input type="password" className={`${inputClass} mt-4`} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="অ্যাকাউন্টের পাসওয়ার্ড" />
          {forgotError && <p className="mt-2 text-xs font-medium text-red-500">{forgotError}</p>}
          <div className="mt-4 flex gap-2">
            <Button variant="ghost" block onClick={() => { setMode("pin"); setForgotError(""); setPassword(""); }}>
              ফিরে যান
            </Button>
            <Button block disabled={busy || !password} onClick={() => void resetPin()}>
              পিন বন্ধ করুন
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="safe-top safe-bottom fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[var(--color-paper)] px-6 dark:bg-[var(--color-paper-dark)]">
      <div className="text-5xl">🔒</div>
      <h1 className="mt-4 text-lg font-semibold">ডায়েরি লক করা আছে</h1>
      <p className="mt-1 text-sm opacity-60">চালিয়ে যেতে ৪ ডিজিটের পিন দিন</p>

      <div className="mt-6 flex gap-3" aria-label={`${pin.length} ডিজিট দেওয়া হয়েছে`}>
        {[0, 1, 2, 3].map((i) => (
          <span key={i} className={`h-4 w-4 rounded-full border-2 border-[var(--color-accent)] ${pin.length > i ? "bg-[var(--color-accent)]" : "bg-transparent"}`} />
        ))}
      </div>
      <p className="mt-3 min-h-5 text-center text-xs font-medium text-red-500">{error}</p>

      <div className="mt-4 grid grid-cols-3 gap-4">
        {KEYS.map((key, i) =>
          key === "" ? (
            <span key={i} />
          ) : (
            <button
              key={i}
              type="button"
              onClick={() => press(key)}
              className="flex h-16 w-16 items-center justify-center rounded-full bg-white/70 text-xl font-medium shadow-sm active:scale-95 dark:bg-white/10"
            >
              {key === "⌫" ? key : toBn(key)}
            </button>
          ),
        )}
      </div>

      <button type="button" onClick={() => setMode("forgot")} className="mt-8 text-xs font-medium text-[var(--color-accent)]">
        পিন ভুলে গেছি
      </button>
    </div>
  );
}
