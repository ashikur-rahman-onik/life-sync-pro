import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import { buildEntryPages, type PageLayout, type PageSpec } from "@/domain/pagination";
import type { DiaryEntry, DiarySettings } from "@/domain/types";
import { formatDateBn, toBn } from "@/lib/bn";
import BookPage from "./BookPage";

interface Props {
  /** All pages of the diary in book order (oldest first). */
  entries: DiaryEntry[];
  startId: string;
  diary: DiarySettings;
  onClose: () => void;
  onEdit: (entry: DiaryEntry) => void;
  onDelete: (entry: DiaryEntry) => void;
  onToggleBookmark: (entry: DiaryEntry) => void;
  onNew: () => void;
}

interface Pos {
  id: string;
  page: number;
}

interface Flip {
  dir: "next" | "prev";
  /** 0 = nothing turned yet, 1 = the page has fully turned */
  progress: number;
  settling: boolean;
}

const TURN_MS = 520;
const SWIPE_COMMIT = 0.28;

function buzz(): void {
  try {
    navigator.vibrate?.(8);
  } catch {
    /* no vibration on this device */
  }
}

/** A full-screen book: swipe, tap the page edges or use the arrows and the page turns like paper. */
export default function BookReader({ entries, startId, diary, onClose, onEdit, onDelete, onToggleBookmark, onNew }: Props) {
  const stage = useRef<HTMLDivElement>(null);
  const measurer = useRef<HTMLDivElement>(null);
  const measureText = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState<{ w: number; h: number } | null>(null);
  const [fontsReady, setFontsReady] = useState(false);
  const [layout, setLayout] = useState<{ key: string; value: PageLayout; photoSize: number } | null>(null);
  const [pos, setPos] = useState<Pos>({ id: startId, page: 0 });
  const [flip, setFlip] = useState<Flip | null>(null);
  const cache = useRef(new Map<string, PageSpec[]>());
  const gesture = useRef<{ x: number; y: number; t: number; dragging: boolean; dir: "next" | "prev" | null; pointerId: number } | null>(null);
  const busy = useRef(false);

  /* ---- page size ---- */
  useLayoutEffect(() => {
    const el = stage.current;
    if (!el) return;
    const read = () => setSize({ w: Math.round(el.clientWidth), h: Math.round(el.clientHeight) });
    read();
    const ro = new ResizeObserver(read);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    let alive = true;
    void document.fonts.ready.then(() => alive && setFontsReady(true));
    return () => {
      alive = false;
    };
  }, []);

  /* ---- how many lines / photos fit on a page (measured with the real font) ---- */
  useLayoutEffect(() => {
    const box = measurer.current;
    const inner = measureText.current;
    if (!size || !box || !inner || size.w < 100 || size.h < 200) return;
    const key = `${size.w}x${size.h}|${diary.font}|${diary.textSize}|${fontsReady}|${getComputedStyle(document.documentElement).fontSize}`;
    if (layout?.key === key) return;

    const style = getComputedStyle(inner);
    const lineHeight = parseFloat(style.lineHeight);
    if (!(lineHeight > 0)) return;
    const rem = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
    const textWidth = size.w - 3.4 * rem - 1.1 * rem;
    const photoSize = Math.max(80, Math.min(150, Math.floor((textWidth - 28) / 2)));
    const contentHeight = size.h - lineHeight - lineHeight * 1.5; // top gap and the page-number strip at the bottom

    setLayout({
      key,
      photoSize,
      value: {
        measure: (s) => {
          inner.textContent = s.replace(/\s+$/, "") || " ";
          return inner.getBoundingClientRect().height;
        },
        lineHeight,
        restLines: Math.max(3, Math.floor(contentHeight / lineHeight)),
        photoFootprint: photoSize * 0.82 + 29 + 20,
        photosPerRow: 2,
        photosPerPage: 4,
      },
    });
  }, [size, diary.font, diary.textSize, fontsReady, layout?.key]);

  /* ---- pages ---- */
  const pagesOf = useCallback(
    (entry: DiaryEntry): PageSpec[] => {
      if (!layout) return [];
      const key = `${layout.key}|${entry.id}|${entry.updatedAt}|${entry.attachments.length}`;
      let pages = cache.current.get(key);
      if (!pages) {
        pages = buildEntryPages(entry, layout.value);
        if (cache.current.size > 60) cache.current.clear();
        cache.current.set(key, pages);
      }
      return pages;
    },
    [layout],
  );

  const idx = Math.max(0, entries.findIndex((e) => e.id === pos.id));
  const entry = entries[idx];
  const pages = useMemo(() => (entry ? pagesOf(entry) : []), [entry, pagesOf]);
  const page = Math.min(pos.page, Math.max(0, pages.length - 1));
  const current = pages[page] ?? null;

  const neighbor = useCallback(
    (dir: "next" | "prev"): { pos: Pos; spec: PageSpec } | null => {
      if (!entry) return null;
      if (dir === "next") {
        if (page < pages.length - 1) return { pos: { id: entry.id, page: page + 1 }, spec: pages[page + 1] };
        const next = entries[idx + 1];
        const first = next ? pagesOf(next)[0] : undefined;
        return next && first ? { pos: { id: next.id, page: 0 }, spec: first } : null;
      }
      if (page > 0) return { pos: { id: entry.id, page: page - 1 }, spec: pages[page - 1] };
      const prev = entries[idx - 1];
      const prevPages = prev ? pagesOf(prev) : [];
      return prev && prevPages.length > 0 ? { pos: { id: prev.id, page: prevPages.length - 1 }, spec: prevPages[prevPages.length - 1] } : null;
    },
    [entry, entries, idx, page, pages, pagesOf],
  );

  const target = flip ? neighbor(flip.dir) : null;
  const numberOf = (e: DiaryEntry) => entries.findIndex((x) => x.id === e.id) + 1;

  /* ---- turning ---- */
  const finish = useCallback(
    (dir: "next" | "prev", completed: boolean) => {
      const dest = neighbor(dir);
      if (completed && dest) {
        setPos(dest.pos);
        buzz();
      }
      setFlip(null);
      busy.current = false;
    },
    [neighbor],
  );

  /** Animates from the current progress to 0 (cancel) or 1 (turn). */
  const settle = useCallback(
    (dir: "next" | "prev", to: 0 | 1) => {
      setFlip({ dir, progress: to, settling: true });
      window.setTimeout(() => finish(dir, to === 1), TURN_MS + 30);
    },
    [finish],
  );

  const turn = useCallback(
    (dir: "next" | "prev") => {
      if (busy.current || !neighbor(dir)) return;
      busy.current = true;
      setFlip({ dir, progress: 0, settling: false });
      requestAnimationFrame(() => requestAnimationFrame(() => settle(dir, 1)));
    },
    [neighbor, settle],
  );

  const onPointerDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (busy.current) return;
    gesture.current = { x: e.clientX, y: e.clientY, t: Date.now(), dragging: false, dir: null, pointerId: e.pointerId };
  };

  const onPointerMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    const g = gesture.current;
    if (!g || !size) return;
    const dx = e.clientX - g.x;
    if (!g.dragging) {
      if (Math.abs(dx) < 10 || Math.abs(dx) < Math.abs(e.clientY - g.y)) return;
      const dir = dx < 0 ? "next" : "prev";
      if (!neighbor(dir)) {
        gesture.current = null;
        return;
      }
      g.dragging = true;
      g.dir = dir;
      busy.current = true;
      (e.currentTarget as HTMLDivElement).setPointerCapture(g.pointerId);
    }
    if (g.dir) setFlip({ dir: g.dir, progress: Math.min(1, Math.abs(dx) / (size.w * 0.85)), settling: false });
  };

  const onPointerUp = (e: ReactPointerEvent<HTMLDivElement>) => {
    const g = gesture.current;
    gesture.current = null;
    if (!g || !size) return;
    if (g.dragging && g.dir) {
      const dx = Math.abs(e.clientX - g.x);
      const progress = Math.min(1, dx / (size.w * 0.85));
      const fast = dx / Math.max(1, Date.now() - g.t) > 0.5; // px per ms
      settle(g.dir, progress > SWIPE_COMMIT || fast ? 1 : 0);
      return;
    }
    // a tap on the left / right edge turns the page
    const targetEl = e.target as HTMLElement;
    if (targetEl.closest("button, a") || Math.abs(e.clientX - g.x) > 8 || Math.abs(e.clientY - g.y) > 8) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const rel = (e.clientX - rect.left) / rect.width;
    if (rel > 0.72) turn("next");
    else if (rel < 0.28) turn("prev");
  };

  const onPointerCancel = () => {
    const g = gesture.current;
    gesture.current = null;
    if (g?.dragging && g.dir) settle(g.dir, 0);
  };

  /* ---- what is drawn ---- */
  const dir = flip?.dir ?? null;
  const p = flip?.progress ?? 0;
  const baseSpec = dir === "next" ? target?.spec : current;
  const leafSpec = dir === "next" ? current : dir === "prev" ? target?.spec : null;
  const angle = dir === "next" ? -180 * p : dir === "prev" ? -180 * (1 - p) : 0;
  const shade = Math.sin(Math.PI * p);
  const transition = flip?.settling ? `transform ${TURN_MS}ms cubic-bezier(0.45, 0.05, 0.25, 1)` : "none";
  const fade = flip?.settling ? `opacity ${TURN_MS}ms ease` : "none";

  const isLast = idx === entries.length - 1 && page >= pages.length - 1;
  const photoSize = layout?.photoSize ?? 120;

  return (
    <div className="fixed inset-0 z-[60] flex flex-col" style={{ background: "radial-gradient(circle at 50% 30%, #4a3a30, #241b16 75%)" }}>
      {/* top bar */}
      <div className="safe-top flex items-center justify-between gap-2 px-3 pb-2 pt-2 text-white">
        <button type="button" onClick={onClose} aria-label="ফিরে যান" className="rounded-full px-3 py-1.5 text-lg active:scale-90">
          ←
        </button>
        <div className="min-w-0 flex-1 text-center">
          <p className="truncate text-xs font-semibold">{entry ? `পাতা ${toBn(numberOf(entry))} · ${formatDateBn(entry.entryDate)}` : ""}</p>
        </div>
        {entry && (
          <div className="flex items-center gap-1 text-lg">
            <button type="button" onClick={() => onToggleBookmark(entry)} aria-label="প্রিয় পাতা" className="rounded-full px-2 py-1 active:scale-90" style={{ opacity: entry.favorite ? 1 : 0.55 }}>
              {entry.favorite ? "🔖" : "🏷️"}
            </button>
            <button type="button" onClick={() => onEdit(entry)} aria-label="এডিট" className="rounded-full px-2 py-1 active:scale-90">
              ✏️
            </button>
            <button type="button" onClick={() => onDelete(entry)} aria-label="মুছুন" className="rounded-full px-2 py-1 active:scale-90">
              🗑️
            </button>
          </div>
        )}
      </div>

      {/* the book page */}
      <div className="relative min-h-0 flex-1 px-2.5 pb-1">
        <div
          ref={stage}
          className="relative h-full w-full select-none"
          style={{ perspective: 2400, touchAction: "none" }}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerCancel={onPointerCancel}
        >
          {/* page stack peeking out on the right */}
          <div className="absolute inset-y-1 -right-1 w-3 rounded-r-md" style={{ background: "repeating-linear-gradient(0deg, #d9cfb6 0 1px, #f3ecd8 1px 3px)", boxShadow: "2px 0 6px rgba(0,0,0,0.4)" }} />

          {/* invisible ruler used to measure text exactly like the page will show it */}
          <div ref={measurer} aria-hidden="true" className={`paper diary-font-${diary.font}`} data-size={diary.textSize} style={{ position: "absolute", left: 0, top: 0, width: size?.w ?? 0, visibility: "hidden", pointerEvents: "none", boxShadow: "none" }}>
            <div ref={measureText} className="paper-text" style={{ paddingTop: 0 }} />
          </div>

          {layout && baseSpec && (
            <div className="absolute inset-0">
              <BookPage spec={baseSpec} diary={diary} number={numberOf(baseSpec.entry)} photoSize={photoSize} />
              {/* shadow the turning page casts on the page below */}
              {dir && <div className="pointer-events-none absolute inset-0 rounded-[4px_14px_14px_4px]" style={{ background: "linear-gradient(to right, rgba(0,0,0,0.38), rgba(0,0,0,0.12) 45%, transparent 80%)", opacity: shade * 0.9, transition: fade }} />}
            </div>
          )}

          {layout && dir && leafSpec && (
            <div className="absolute inset-0" style={{ transformStyle: "preserve-3d", transformOrigin: "left center", transform: `rotateY(${angle}deg)`, transition, willChange: "transform" }}>
              <div className="absolute inset-0" style={{ backfaceVisibility: "hidden", WebkitBackfaceVisibility: "hidden" }}>
                <BookPage spec={leafSpec} diary={diary} number={numberOf(leafSpec.entry)} photoSize={photoSize} />
                <div className="pointer-events-none absolute inset-0 rounded-[4px_14px_14px_4px]" style={{ background: "linear-gradient(to left, rgba(0,0,0,0.35), transparent 70%)", opacity: shade * 0.8 }} />
              </div>
              {/* the back of the sheet */}
              <div className="paper absolute inset-0" data-tone={diary.paperTone} data-style="plain" style={{ transform: "rotateY(180deg)", backfaceVisibility: "hidden", WebkitBackfaceVisibility: "hidden", borderRadius: "14px 4px 4px 14px", filter: "brightness(0.93)" }}>
                <div className="pointer-events-none absolute inset-0" style={{ background: "linear-gradient(to right, rgba(0,0,0,0.3), transparent 60%)", opacity: shade * 0.7 }} />
              </div>
            </div>
          )}

          {!layout && <div className="absolute inset-0 flex items-center justify-center text-sm text-white/60">পাতা সাজানো হচ্ছে…</div>}
        </div>
      </div>

      {/* bottom bar */}
      <div className="safe-bottom flex items-center justify-between px-3 pb-2 pt-1 text-white">
        <button type="button" onClick={() => turn("prev")} disabled={!neighbor("prev") || flip !== null} className="rounded-full bg-white/10 px-4 py-2 text-sm active:scale-95 disabled:opacity-30">
          ← আগের
        </button>
        <span className="text-[11px] text-white/60">{current ? `${toBn(page + 1)}/${toBn(pages.length)} · মোট ${toBn(entries.length)}টি পাতা` : ""}</span>
        {isLast ? (
          <button type="button" onClick={onNew} className="rounded-full bg-[var(--color-accent)] px-4 py-2 text-sm font-semibold active:scale-95">
            ✍️ নতুন পাতা
          </button>
        ) : (
          <button type="button" onClick={() => turn("next")} disabled={!neighbor("next") || flip !== null} className="rounded-full bg-white/10 px-4 py-2 text-sm active:scale-95 disabled:opacity-30">
            পরের →
          </button>
        )}
      </div>
    </div>
  );
}
