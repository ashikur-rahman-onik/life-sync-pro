import { dismissUpdate, startUpdate, updatesAvailable, useUpdater } from "@/native/updater";
import { toBn } from "@/lib/bn";
import { ProgressBar } from "./ui";

/** Shown on the home screen when a newer APK is published on GitHub Releases. */
export default function UpdateBanner() {
  const u = useUpdater();
  if (!updatesAvailable() || !u.info || u.info.build === u.dismissedBuild) return null;
  if (u.status !== "available" && u.status !== "downloading" && u.status !== "error") return null;

  const downloading = u.status === "downloading";
  return (
    <div className="animate-fade-in-up mb-4 rounded-2xl border border-[var(--color-accent)]/30 bg-[var(--color-accent)]/10 p-4">
      <div className="flex items-start gap-3">
        <span className="text-2xl">🚀</span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-bold">নতুন আপডেট পাওয়া গেছে ({toBn(u.info.versionName)})</p>
          {u.info.notes && <p className="mt-0.5 line-clamp-2 text-xs opacity-70">{u.info.notes}</p>}
          {downloading ? (
            <div className="mt-3">
              <ProgressBar percent={u.progress} />
              <p className="mt-1 text-[11px] opacity-60">ডাউনলোড হচ্ছে… {toBn(u.progress)}%</p>
            </div>
          ) : (
            <>
              {u.status === "error" && <p className="mt-1 text-xs text-red-500">{u.error}</p>}
              <div className="mt-3 flex gap-2">
                <button type="button" onClick={() => void startUpdate()} className="rounded-full bg-[var(--color-accent)] px-4 py-1.5 text-xs font-semibold text-white active:scale-95">
                  এখনই আপডেট করুন
                </button>
                <button type="button" onClick={dismissUpdate} className="rounded-full px-4 py-1.5 text-xs font-medium opacity-60">
                  পরে
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
