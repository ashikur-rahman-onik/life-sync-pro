import { useMemo } from "react";
import { dateKey, nowMinutes } from "@/lib/date";
import { dosesForDate, doseStatus, logMap, type DoseStatus, type PlannedDose } from "@/domain/medicine";
import { useAppData } from "@/store/store";
import { useNow } from "@/lib/useNow";

export interface DoseWithStatus {
  dose: PlannedDose;
  status: DoseStatus;
}

/** Today's doses with their live status (taken / due / missed …). */
export function useTodayDoses(): { today: string; items: DoseWithStatus[] } {
  const data = useAppData();
  const now = useNow();
  const today = dateKey(now);
  const minutes = nowMinutes(now);

  const items = useMemo(() => {
    const logs = logMap(data.doseLogs);
    return dosesForDate(data.medicines, today).map((dose) => ({ dose, status: doseStatus(dose, logs.get(dose.key), today, minutes) }));
  }, [data.medicines, data.doseLogs, today, minutes]);

  return { today, items };
}
