import { useRef, useState } from "react";
import type { Attachment } from "@/domain/types";
import { createAttachment, removeLocalBlobs } from "@/media/attachments";
import { showToast } from "@/lib/toast";
import { useAppData } from "@/store/store";
import { cloudinaryReady } from "@/media/cloudinary";
import { FileChip, Polaroid } from "./AttachmentViews";

interface Props {
  value: Attachment[];
  onChange: (next: Attachment[]) => void;
  /** Photos only (e.g. for the cover). */
  imagesOnly?: boolean;
  max?: number;
}

/** Add/remove photos and files. They are saved on the phone first and uploaded to Cloudinary in the background. */
export default function AttachmentPicker({ value, onChange, imagesOnly = false, max = 12 }: Props) {
  const { settings } = useAppData();
  const photoRef = useRef<HTMLInputElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  const add = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setBusy(true);
    const added: Attachment[] = [];
    try {
      for (const file of Array.from(files)) {
        if (value.length + added.length >= max) {
          showToast(`একসাথে সর্বোচ্চ ${max}টি যোগ করা যায়`);
          break;
        }
        try {
          added.push(await createAttachment(file));
        } catch (e) {
          showToast(e instanceof Error ? e.message : "ফাইল যোগ করা যায়নি");
        }
      }
      if (added.length > 0) {
        onChange([...value, ...added]);
        if (!cloudinaryReady(settings.cloudinary)) showToast("ℹ️ ফোনে সেভ হয়েছে। সেটিংসে Cloudinary দিলে ক্লাউডে আপলোড হবে");
      }
    } finally {
      setBusy(false);
    }
  };

  const remove = (att: Attachment) => {
    onChange(value.filter((a) => a.id !== att.id));
    void removeLocalBlobs([att]); // only phone copies are freed; the cloud link just stops being used
  };

  return (
    <div>
      {value.length > 0 && (
        <div className="mb-3 flex flex-wrap items-start gap-x-5 gap-y-6 px-1 pt-3">
          {value.map((a) => (
            <div key={a.id} className="relative">
              {a.kind === "image" ? <Polaroid att={a} size={110} /> : <FileChip att={a} />}
              <button type="button" onClick={() => remove(a)} aria-label="সরান" className="absolute -right-2 -top-3 z-10 flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-xs text-white shadow">
                ✕
              </button>
            </div>
          ))}
        </div>
      )}
      <div className="flex gap-2">
        <button type="button" disabled={busy} onClick={() => photoRef.current?.click()} className="flex-1 rounded-xl bg-black/5 px-3 py-2.5 text-xs font-semibold active:scale-95 dark:bg-white/10">
          🖼️ ছবি যোগ করুন
        </button>
        {!imagesOnly && (
          <button type="button" disabled={busy} onClick={() => fileRef.current?.click()} className="flex-1 rounded-xl bg-black/5 px-3 py-2.5 text-xs font-semibold active:scale-95 dark:bg-white/10">
            📎 ফাইল/ডকুমেন্ট
          </button>
        )}
      </div>
      {busy && <p className="mt-1 text-[11px] opacity-60">প্রস্তুত হচ্ছে…</p>}
      <input ref={photoRef} type="file" accept="image/*" multiple={!imagesOnly} className="hidden" onChange={(e) => { void add(e.target.files); e.target.value = ""; }} />
      <input ref={fileRef} type="file" multiple className="hidden" onChange={(e) => { void add(e.target.files); e.target.value = ""; }} />
    </div>
  );
}
