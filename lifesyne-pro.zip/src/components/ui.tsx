import { useEffect, type ButtonHTMLAttributes, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { pushBackHandler } from "@/lib/backStack";
import { toBn } from "@/lib/bn";

export const cardClass = "rounded-2xl border border-[var(--color-accent)]/15 bg-white/70 p-4 dark:bg-white/5";
export const inputClass =
  "w-full rounded-2xl border border-[var(--color-accent)]/20 bg-white/70 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-[var(--color-accent)]/40 dark:bg-white/5";

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`${cardClass} ${className}`}>{children}</section>;
}

type Variant = "primary" | "soft" | "danger" | "ghost";
const VARIANTS: Record<Variant, string> = {
  primary: "bg-[var(--color-accent)] text-white shadow-md shadow-[var(--color-accent)]/25",
  soft: "bg-[var(--color-accent)]/12 text-[var(--color-accent)]",
  danger: "bg-red-500/10 text-red-500",
  ghost: "bg-white/70 dark:bg-white/10",
};

export function Button({
  variant = "primary",
  block = false,
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; block?: boolean }) {
  return (
    <button
      type="button"
      {...props}
      className={`rounded-2xl px-4 py-2.5 text-sm font-semibold transition active:scale-[0.98] disabled:opacity-50 ${VARIANTS[variant]} ${
        block ? "w-full" : ""
      } ${className}`}
    />
  );
}

export function PageHeader({ title, back = false, right }: { title: string; back?: boolean; right?: ReactNode }) {
  const navigate = useNavigate();
  const goBack = () => (window.history.length > 1 ? navigate(-1) : navigate("/"));
  return (
    <header className="mb-5 flex items-center justify-between gap-3">
      <div className="flex min-w-0 items-center gap-2">
        {back && (
          <button type="button" onClick={goBack} aria-label="ফিরে যান" className="-ml-1 rounded-full px-2 py-1 text-xl opacity-70 active:scale-90">
            ←
          </button>
        )}
        <h1 className="truncate text-xl font-bold">{title}</h1>
      </div>
      {right}
    </header>
  );
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold opacity-70">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[11px] opacity-50">{hint}</span>}
    </label>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
  description,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  description?: string;
}) {
  return (
    <button type="button" role="switch" aria-checked={checked} onClick={() => onChange(!checked)} className="flex w-full items-center justify-between gap-3 text-left">
      <span>
        <span className="block text-sm font-semibold">{label}</span>
        {description && <span className="block text-xs opacity-60">{description}</span>}
      </span>
      <span className={`relative h-7 w-12 shrink-0 rounded-full transition ${checked ? "bg-[var(--color-accent)]" : "bg-black/15 dark:bg-white/20"}`}>
        <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-transform ${checked ? "translate-x-6" : "translate-x-1"}`} />
      </span>
    </button>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div className="flex gap-1 rounded-2xl bg-black/5 p-1 dark:bg-white/10">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={`flex-1 rounded-xl px-2 py-2 text-xs font-semibold transition ${
            o.value === value ? "bg-white text-[var(--color-ink)] shadow-sm dark:bg-[var(--color-accent)] dark:text-white" : "opacity-60"
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-medium transition ${
        active ? "bg-[var(--color-accent)] text-white" : "bg-white/70 opacity-80 dark:bg-white/5"
      }`}
    >
      {children}
    </button>
  );
}

export function Stepper({
  value,
  onChange,
  step = 1,
  min = 0,
  max = 99,
  format,
}: {
  value: number;
  onChange: (v: number) => void;
  step?: number;
  min?: number;
  max?: number;
  format?: (v: number) => string;
}) {
  const clamp = (v: number) => Math.min(max, Math.max(min, Math.round(v * 100) / 100));
  const btn = "flex h-9 w-9 items-center justify-center rounded-full bg-[var(--color-accent)]/12 text-lg font-bold text-[var(--color-accent)] active:scale-90 disabled:opacity-30";
  return (
    <div className="flex items-center gap-3">
      <button type="button" className={btn} onClick={() => onChange(clamp(value - step))} disabled={value <= min} aria-label="কমান">
        −
      </button>
      <span className="min-w-10 text-center text-sm font-semibold">{format ? format(value) : toBn(value)}</span>
      <button type="button" className={btn} onClick={() => onChange(clamp(value + step))} disabled={value >= max} aria-label="বাড়ান">
        +
      </button>
    </div>
  );
}

/** Bottom sheet. The Android back button closes it first. */
export function Modal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  useEffect(() => {
    if (!open) return;
    return pushBackHandler(onClose);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center bg-black/40" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
        className="animate-sheet-up safe-bottom max-h-[88vh] w-full max-w-xl overflow-y-auto rounded-t-3xl bg-[var(--color-paper)] p-5 shadow-2xl dark:bg-[#17212f]"
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-base font-bold">{title}</h2>
          <button type="button" onClick={onClose} aria-label="বন্ধ করুন" className="rounded-full px-2 text-lg opacity-60">
            ✕
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function EmptyState({ icon, title, text }: { icon: string; title: string; text?: string }) {
  return (
    <div className="flex flex-col items-center py-10 text-center">
      <span className="text-5xl">{icon}</span>
      <p className="mt-4 font-semibold">{title}</p>
      {text && <p className="mt-1 max-w-xs text-sm opacity-60">{text}</p>}
    </div>
  );
}

export function ProgressBar({ percent, color = "var(--color-accent)" }: { percent: number; color?: string }) {
  return (
    <div className="h-2.5 w-full overflow-hidden rounded-full bg-black/5 dark:bg-white/10">
      <div className="h-full rounded-full transition-all" style={{ width: `${Math.min(100, Math.max(0, percent))}%`, backgroundColor: color }} />
    </div>
  );
}
