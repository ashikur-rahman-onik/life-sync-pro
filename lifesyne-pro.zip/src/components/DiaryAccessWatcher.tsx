import { useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import { onReturnFromBackground } from "@/lib/appVisibility";
import { closeDiary, isDiaryPath } from "@/lib/diaryLock";
import { useAppData } from "@/store/store";

/** The diary is closed again when you leave it (or after a delay, depending on the setting) and when the app was away for a minute. */
const BACKGROUND_LIMIT_MS = 60_000;
const DELAYS_MS = { "1m": 60_000, "5m": 300_000 } as const;

export default function DiaryAccessWatcher() {
  const { pathname } = useLocation();
  const { lock, relock } = useAppData().settings.diary;
  const hasLock = lock !== null;
  const wasInDiary = useRef(isDiaryPath(pathname));
  const leftAt = useRef<number | null>(null);

  useEffect(() => {
    const inDiary = isDiaryPath(pathname);
    if (wasInDiary.current && !inDiary && hasLock) {
      if (relock === "leave") closeDiary();
      else if (relock !== "session") leftAt.current = Date.now();
    }
    if (!wasInDiary.current && inDiary && leftAt.current !== null) {
      const limit = relock === "1m" || relock === "5m" ? DELAYS_MS[relock] : 0;
      if (hasLock && Date.now() - leftAt.current >= limit) closeDiary();
      leftAt.current = null;
    }
    wasInDiary.current = inDiary;
  }, [pathname, hasLock, relock]);

  useEffect(
    () =>
      onReturnFromBackground((away) => {
        if (hasLock && away >= BACKGROUND_LIMIT_MS) closeDiary();
      }),
    [hasLock],
  );

  return null;
}
