import { useState } from "react";
import { WEEKDAYS_SHORT_BN, toBn } from "@/lib/bn";
import { uid } from "@/lib/id";
import { daysInCourse, DEFAULT_QTY, endDateFromDays, evenSlots, FORM_ICONS, FORM_LABELS, formatDose, QTY_STEP, RELATION_LABELS, SLOT_PRESETS, buildPresetSlots, sortSlots, type PresetId } from "@/domain/medicine";
import type { DoseSlot, MealRelation, MedForm, Medicine, Settings } from "@/domain/types";
import { Chip, Field, inputClass, Segmented, Stepper } from "./ui";

interface Props {
  value: Medicine;
  onChange: (m: Medicine) => void;
  meals: Settings["meals"];
  showDoctor?: boolean;
}

const FORMS = Object.keys(FORM_LABELS) as MedForm[];

/** Form fields for one medicine — used by the single-medicine page and the prescription page. */
export default function MedicineFields({ value: m, onChange, meals, showDoctor = true }: Props) {
  const [stockText, setStockText] = useState(m.stock === null ? "" : String(m.stock));
  const set = (patch: Partial<Medicine>) => onChange({ ...m, ...patch });

  const presetCount = (id: PresetId) => m.slots.find((s) => s.id === id)?.qty ?? 0;
  const baseQty = m.slots[0]?.qty ?? DEFAULT_QTY[m.form];

  const setPreset = (id: PresetId, qty: number) => {
    const counts = Object.fromEntries(SLOT_PRESETS.map((p) => [p.id, presetCount(p.id)])) as Record<PresetId, number>;
    counts[id] = qty;
    const rebuilt = buildPresetSlots(counts, meals, m.relation);
    // keep times the user edited by hand
    const kept = rebuilt.map((s) => {
      const old = m.slots.find((o) => o.id === s.id);
      return old ? { ...s, time: old.time } : s;
    });
    const custom = m.slots.filter((s) => !SLOT_PRESETS.some((p) => p.id === s.id));
    set({ slots: sortSlots([...kept, ...custom]) });
  };

  const changeRelation = (relation: MealRelation) => {
    const counts = Object.fromEntries(SLOT_PRESETS.map((p) => [p.id, presetCount(p.id)])) as Record<PresetId, number>;
    const presets = buildPresetSlots(counts, meals, relation);
    const custom = m.slots.filter((s) => !SLOT_PRESETS.some((p) => p.id === s.id));
    set({ relation, slots: sortSlots([...presets, ...custom]) });
  };

  const changeForm = (form: MedForm) => set({ form, slots: m.slots.map((s) => ({ ...s, qty: DEFAULT_QTY[form] })) });

  const updateSlot = (id: string, patch: Partial<DoseSlot>) => set({ slots: m.slots.map((s) => (s.id === id ? { ...s, ...patch } : s)) });
  const removeSlot = (id: string) => set({ slots: m.slots.filter((s) => s.id !== id) });
  const addSlot = () => set({ slots: sortSlots([...m.slots, { id: uid(), label: "নির্দিষ্ট সময়", time: "12:00", qty: baseQty }]) });
  const everyHours = (h: number) => set({ slots: evenSlots(m.slots[0]?.time ?? "08:00", h, baseQty) });

  const ongoing = m.endDate === null;
  const days = m.endDate ? daysInCourse(m.startDate, m.endDate) : 7;
  const toggleDay = (d: number) => set({ weekdays: m.weekdays.includes(d) ? m.weekdays.filter((x) => x !== d) : [...m.weekdays, d].sort() });

  return (
    <div className="space-y-4">
      <Field label="ওষুধের নাম">
        <input className={inputClass} value={m.name} onChange={(e) => set({ name: e.target.value })} placeholder="যেমন: নাপা ৫০০ মি.গ্রা." />
      </Field>

      <div>
        <span className="mb-1.5 block text-xs font-semibold opacity-70">ধরন</span>
        <div className="flex flex-wrap gap-2">
          {FORMS.map((f) => (
            <Chip key={f} active={m.form === f} onClick={() => changeForm(f)}>
              {FORM_ICONS[f]} {FORM_LABELS[f]}
            </Chip>
          ))}
        </div>
      </div>

      <div>
        <span className="mb-1.5 block text-xs font-semibold opacity-70">খাওয়ার নিয়ম</span>
        <Segmented
          value={m.relation}
          onChange={changeRelation}
          options={(Object.keys(RELATION_LABELS) as MealRelation[]).map((r) => ({ value: r, label: RELATION_LABELS[r] }))}
        />
      </div>

      <div>
        <span className="mb-1 block text-xs font-semibold opacity-70">কখন কখন খাবেন (ডাক্তারের লেখা ১+০+১ এর মতো)</span>
        <div className="space-y-2 rounded-2xl bg-black/[0.03] p-3 dark:bg-white/5">
          {SLOT_PRESETS.map((p) => (
            <div key={p.id} className="flex items-center justify-between">
              <span className="text-sm font-medium">{p.label}</span>
              <Stepper value={presetCount(p.id)} onChange={(v) => setPreset(p.id, v)} step={QTY_STEP[m.form]} max={10} format={(v) => (v === 0 ? "০" : formatDose(v, m.form))} />
            </div>
          ))}
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <span className="text-[11px] opacity-60">অথবা:</span>
          {[6, 8, 12].map((h) => (
            <Chip key={h} active={false} onClick={() => everyHours(h)}>
              প্রতি {toBn(h)} ঘণ্টা পরপর
            </Chip>
          ))}
          <Chip active={false} onClick={addSlot}>
            + সময় যোগ
          </Chip>
        </div>
      </div>

      {m.slots.length > 0 && (
        <div className="space-y-2">
          <span className="block text-xs font-semibold opacity-70">সময় ঠিক করুন</span>
          {m.slots.map((s) => (
            <div key={s.id} className="flex items-center gap-2 rounded-2xl bg-white/60 p-2 dark:bg-white/5">
              <input
                type="time"
                value={s.time}
                onChange={(e) => e.target.value && updateSlot(s.id, { time: e.target.value })}
                className="rounded-xl border border-[var(--color-accent)]/20 bg-transparent px-2 py-1.5 text-sm"
              />
              <span className="flex-1 text-xs opacity-70">{formatDose(s.qty, m.form)}</span>
              <Stepper value={s.qty} onChange={(v) => updateSlot(s.id, { qty: v })} step={QTY_STEP[m.form]} min={QTY_STEP[m.form]} max={20} format={() => ""} />
              <button type="button" onClick={() => removeSlot(s.id)} aria-label="সময় মুছুন" className="px-1 text-red-500">
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      <div>
        <span className="mb-1.5 block text-xs font-semibold opacity-70">কতদিন খাবেন</span>
        <Segmented
          value={ongoing ? "ongoing" : "days"}
          onChange={(v) => set({ endDate: v === "ongoing" ? null : endDateFromDays(m.startDate, days) })}
          options={[
            { value: "days", label: "নির্দিষ্ট দিন" },
            { value: "ongoing", label: "চলতে থাকবে" },
          ]}
        />
        {!ongoing && (
          <div className="mt-3 flex items-center justify-between">
            <span className="text-sm">মোট দিন</span>
            <Stepper value={days} onChange={(v) => set({ endDate: endDateFromDays(m.startDate, v) })} min={1} max={365} format={(v) => `${toBn(v)} দিন`} />
          </div>
        )}
      </div>

      <Field label="শুরুর তারিখ">
        <input
          type="date"
          className={inputClass}
          value={m.startDate}
          onChange={(e) => e.target.value && set({ startDate: e.target.value, endDate: m.endDate ? endDateFromDays(e.target.value, days) : null })}
        />
      </Field>

      <div>
        <span className="mb-1.5 block text-xs font-semibold opacity-70">নির্দিষ্ট বার (ফাঁকা থাকলে প্রতিদিন)</span>
        <div className="flex flex-wrap gap-2">
          {WEEKDAYS_SHORT_BN.map((label, d) => (
            <Chip key={d} active={m.weekdays.includes(d)} onClick={() => toggleDay(d)}>
              {label}
            </Chip>
          ))}
        </div>
      </div>

      <Field label="হাতে কতটুকু আছে (ঐচ্ছিক)" hint="কম পড়লে অ্যাপ আগে থেকে জানিয়ে দেবে। ট্যাবলেট/ক্যাপসুলের সংখ্যা বা সিরাপের মি.লি. লিখুন।">
        <input
          className={inputClass}
          inputMode="decimal"
          value={stockText}
          onChange={(e) => {
            const raw = e.target.value.replace(/[^\d.]/g, "");
            setStockText(raw);
            const n = parseFloat(raw);
            set({ stock: raw === "" || Number.isNaN(n) ? null : n });
          }}
          placeholder="যেমন: ২০"
        />
      </Field>

      {showDoctor && (
        <Field label="ডাক্তারের নাম (ঐচ্ছিক)">
          <input className={inputClass} value={m.doctor} onChange={(e) => set({ doctor: e.target.value })} />
        </Field>
      )}
      <Field label="নোট (ঐচ্ছিক)">
        <input className={inputClass} value={m.notes} onChange={(e) => set({ notes: e.target.value })} placeholder="যেমন: গরম পানি দিয়ে খাবেন" />
      </Field>
    </div>
  );
}
