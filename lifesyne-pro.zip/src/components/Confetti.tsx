import { useEffect, useState } from "react";
import { registerCelebrateHandler } from "@/lib/celebrate";

const PIECES = ["🎉", "✨", "💧", "⭐", "🎊", "🌟"];

/** Falling emoji for ~2 seconds. Mounted once in the app shell. */
export default function Confetti() {
  const [burst, setBurst] = useState(0);

  useEffect(() => {
    registerCelebrateHandler(() => setBurst(Date.now()));
    return () => registerCelebrateHandler(null);
  }, []);

  useEffect(() => {
    if (!burst) return;
    const t = setTimeout(() => setBurst(0), 2200);
    return () => clearTimeout(t);
  }, [burst]);

  if (!burst) return null;
  return (
    <div key={burst} className="pointer-events-none fixed inset-0 z-[130] overflow-hidden" aria-hidden="true">
      {Array.from({ length: 22 }, (_, i) => (
        <span
          key={i}
          className="confetti-piece absolute top-0 text-2xl"
          style={{ left: `${(i * 37) % 100}%`, animationDelay: `${(i % 7) * 0.12}s`, animationDuration: `${1.4 + (i % 5) * 0.2}s` }}
        >
          {PIECES[i % PIECES.length]}
        </span>
      ))}
    </div>
  );
}
