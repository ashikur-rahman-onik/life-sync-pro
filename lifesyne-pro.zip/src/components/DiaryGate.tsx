import type { ReactNode } from "react";
import { useDiaryOpen } from "@/lib/diaryLock";
import DiaryUnlock from "./DiaryUnlock";

/** Everything inside the private diary stays hidden behind the closed cover until it is opened. */
export default function DiaryGate({ children }: { children: ReactNode }) {
  return useDiaryOpen() ? <>{children}</> : <DiaryUnlock />;
}
