import { useLocation, useNavigate } from "react-router-dom";
import { Segmented } from "./ui";

/** Water ⇄ Medicine switch shown on top of both health pages. */
export default function HealthTabs() {
  const navigate = useNavigate();
  const onMedicine = useLocation().pathname.startsWith("/medicine");
  return (
    <div className="mb-4">
      <Segmented
        value={onMedicine ? "medicine" : "water"}
        onChange={(v) => navigate(v === "water" ? "/water" : "/medicine", { replace: true })}
        options={[
          { value: "water", label: "💧 পানি" },
          { value: "medicine", label: "💊 ওষুধ" },
        ]}
      />
    </div>
  );
}
