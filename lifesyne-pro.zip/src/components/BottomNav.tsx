import { useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { buildAgenda } from "@/domain/today";
import { dateKey, nowMinutes } from "@/lib/date";
import { toBn } from "@/lib/bn";
import { useNow } from "@/lib/useNow";
import { useAppData } from "@/store/store";
import QuickAddSheet from "./QuickAddSheet";

const ITEMS = [
  { to: "/", label: "হোম", icon: "🏠", match: (p: string) => p === "/" },
  { to: "/diary", label: "ডায়েরি", icon: "📔", match: (p: string) => p.startsWith("/diary") || p.startsWith("/entry") || p === "/new" },
  { to: "/water", label: "স্বাস্থ্য", icon: "💧", match: (p: string) => p.startsWith("/water") || p.startsWith("/medicine") || p.startsWith("/prescription") },
  { to: "/reminders", label: "রিমাইন্ডার", icon: "⏰", match: (p: string) => p.startsWith("/reminders") || p.startsWith("/habits") },
] as const;

/** Forms hide the bottom bar so the save button is never covered. */
const HIDDEN_ON = [/^\/new$/, /^\/medicine\/(new|.+\/edit)$/, /^\/prescription\/new$/, /^\/reminders\/(new|.+\/edit)$/, /^\/habits\/(new|.+\/edit)$/];

export default function BottomNav() {
  const { pathname } = useLocation();
  const data = useAppData();
  const now = useNow();
  const [addOpen, setAddOpen] = useState(false);

  if (HIDDEN_ON.some((re) => re.test(pathname))) return null;

  const pending = buildAgenda(data, dateKey(now), nowMinutes(now)).filter((i) => i.kind !== "habit" && (i.status === "due" || i.status === "missed")).length;

  const renderItem = (item: (typeof ITEMS)[number]) => (
    <NavLink
      key={item.to}
      to={item.to}
      className={`relative flex flex-1 flex-col items-center justify-center gap-0.5 py-2.5 text-[11px] font-medium transition ${item.match(pathname) ? "text-[var(--color-accent)]" : "opacity-55"}`}
    >
      <span className="relative text-lg">
        {item.icon}
        {item.to === "/reminders" && pending > 0 && (
          <span className="absolute -right-2.5 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[9px] font-bold text-white">{toBn(pending)}</span>
        )}
      </span>
      {item.label}
    </NavLink>
  );

  return (
    <>
      <nav className="safe-bottom fixed inset-x-0 bottom-0 z-40 border-t border-[var(--color-accent)]/20 bg-[var(--color-paper)]/90 backdrop-blur-lg dark:bg-[var(--color-paper-dark)]/90">
        <div className="mx-auto flex max-w-xl items-stretch justify-between px-2">
          {ITEMS.slice(0, 2).map(renderItem)}
          <button type="button" onClick={() => setAddOpen(true)} aria-label="নতুন যোগ করুন" className="relative -mt-5 flex flex-1 flex-col items-center justify-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-[var(--color-accent)] text-3xl font-light text-white shadow-lg shadow-[var(--color-accent)]/40 ring-4 ring-[var(--color-paper)] transition active:scale-95 dark:ring-[var(--color-paper-dark)]">
              +
            </span>
            <span className="mt-1 text-[11px] font-medium opacity-80">যোগ করুন</span>
          </button>
          {ITEMS.slice(2).map(renderItem)}
        </div>
      </nav>
      <QuickAddSheet open={addOpen} onClose={() => setAddOpen(false)} />
    </>
  );
}
