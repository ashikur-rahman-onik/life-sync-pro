import { NavLink, useLocation } from "react-router-dom";
import { dosesForDate, doseStatus, logMap } from "@/domain/medicine";
import { dateKey, nowMinutes } from "@/lib/date";
import { toBn } from "@/lib/bn";
import { useNow } from "@/lib/useNow";
import { useAppData } from "@/store/store";

const ITEMS = [
  { to: "/", label: "হোম", icon: "🏠", match: (p: string) => p === "/" },
  { to: "/diary", label: "ডায়েরি", icon: "📔", match: (p: string) => p.startsWith("/diary") || p.startsWith("/entry") },
  { to: "/new", label: "লিখুন", icon: "✍️", match: (p: string) => p === "/new", primary: true },
  { to: "/water", label: "পানি", icon: "💧", match: (p: string) => p.startsWith("/water") },
  { to: "/medicine", label: "ওষুধ", icon: "💊", match: (p: string) => p.startsWith("/medicine") || p.startsWith("/prescription") },
] as const;

/** Forms hide the bottom bar so the save button is never covered. */
const HIDDEN_ON = [/^\/new$/, /^\/medicine\/(new|.+\/edit)$/, /^\/prescription\/new$/];

export default function BottomNav() {
  const { pathname } = useLocation();
  const data = useAppData();
  const now = useNow();

  if (HIDDEN_ON.some((re) => re.test(pathname))) return null;

  const today = dateKey(now);
  const logs = logMap(data.doseLogs);
  const pending = dosesForDate(data.medicines, today).filter((d) => {
    const s = doseStatus(d, logs.get(d.key), today, nowMinutes(now));
    return s === "due" || s === "missed";
  }).length;

  return (
    <nav className="safe-bottom fixed inset-x-0 bottom-0 z-40 border-t border-[var(--color-accent)]/20 bg-[var(--color-paper)]/90 backdrop-blur-lg dark:bg-[var(--color-paper-dark)]/90">
      <div className="mx-auto flex max-w-xl items-stretch justify-between px-2">
        {ITEMS.map((item) => {
          const active = item.match(pathname);
          if ("primary" in item) {
            return (
              <NavLink key={item.to} to={item.to} className="relative -mt-5 flex flex-1 flex-col items-center justify-center">
                <span className="flex h-14 w-14 items-center justify-center rounded-full bg-[var(--color-accent)] text-2xl text-white shadow-lg shadow-[var(--color-accent)]/40 ring-4 ring-[var(--color-paper)] transition active:scale-95 dark:ring-[var(--color-paper-dark)]">
                  {item.icon}
                </span>
                <span className="mt-1 text-[11px] font-medium opacity-80">{item.label}</span>
              </NavLink>
            );
          }
          return (
            <NavLink
              key={item.to}
              to={item.to}
              className={`relative flex flex-1 flex-col items-center justify-center gap-0.5 py-2.5 text-[11px] font-medium transition ${
                active ? "text-[var(--color-accent)]" : "opacity-55"
              }`}
            >
              <span className="relative text-lg">
                {item.icon}
                {item.to === "/medicine" && pending > 0 && (
                  <span className="absolute -right-2.5 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[9px] font-bold text-white">
                    {toBn(pending)}
                  </span>
                )}
              </span>
              {item.label}
            </NavLink>
          );
        })}
      </div>
    </nav>
  );
}
