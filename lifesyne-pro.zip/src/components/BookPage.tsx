import { FileChip, Polaroid } from "@/components/AttachmentViews";
import DiaryPaper from "@/components/DiaryPaper";
import type { PageSpec } from "@/domain/pagination";
import { headerLines } from "@/domain/pagination";
import type { DiarySettings } from "@/domain/types";
import { formatDateBn, toBn, WEEKDAYS_BN } from "@/lib/bn";
import { parseDateKey } from "@/lib/date";
import { getMood } from "@/lib/moods";

interface Props {
  spec: PageSpec;
  diary: DiarySettings;
  /** The page's number in the whole diary. */
  number: number;
  photoSize: number;
}

/** One printed page of the book. Everything on it is sized in "lines" so text sits exactly on the ruled lines. */
export default function BookPage({ spec, diary, number, photoSize }: Props) {
  const { entry } = spec;
  const mood = getMood(entry.mood);
  const lines = headerLines(entry.title);
  const titleLines = lines - 2;

  return (
    <DiaryPaper diary={diary} className="h-full w-full" style={{ borderRadius: "4px 14px 14px 4px" }}>
      <div className="flex h-full flex-col" style={{ paddingTop: "var(--lh)" }}>
        {spec.isFirst && (
          <>
            <div className="relative" style={{ height: "calc(var(--lh) * 2)" }}>
              <p className="text-[0.8em] opacity-60" style={{ lineHeight: "var(--lh)" }}>
                {WEEKDAYS_BN[parseDateKey(entry.entryDate).getDay()]}
              </p>
              <p className="font-semibold" style={{ fontSize: "calc(var(--fs) * 1.15)", lineHeight: "var(--lh)" }}>
                {formatDateBn(entry.entryDate)}
              </p>
              <span className="absolute right-2 top-0 flex h-11 w-11 -rotate-6 items-center justify-center rounded-full border-2 border-dashed border-current text-2xl opacity-80" title={mood.label}>
                {mood.emoji}
              </span>
            </div>
            {titleLines > 0 && (
              <h1 className="paper-title overflow-hidden" style={{ height: `calc(var(--lh) * ${titleLines})`, display: "-webkit-box", WebkitLineClamp: titleLines, WebkitBoxOrient: "vertical" }}>
                {entry.title}
              </h1>
            )}
          </>
        )}

        {spec.kind === "photos" && <p className="text-[0.8em] opacity-60" style={{ lineHeight: "var(--lh)" }}>📷 ছবি</p>}
        {spec.kind === "files" && <p className="text-[0.8em] opacity-60" style={{ lineHeight: "var(--lh)" }}>📎 সংযুক্ত ফাইল</p>}

        {spec.text && (
          <p className="paper-text" style={{ paddingTop: 0 }}>
            {spec.text}
          </p>
        )}

        {spec.photos.length > 0 && (
          <div className="flex flex-wrap items-start gap-x-5 gap-y-5 pr-1 pt-3">
            {spec.photos.map((a) => (
              <Polaroid key={a.id} att={a} size={photoSize} />
            ))}
          </div>
        )}
        {spec.files.length > 0 && (
          <div className="space-y-2 pr-1 pt-2">
            {spec.files.map((a) => (
              <FileChip key={a.id} att={a} />
            ))}
          </div>
        )}
      </div>

      {spec.isFirst && entry.tags.length > 0 && spec.total === 1 && (
        <div className="absolute inset-x-0 flex flex-wrap gap-2 pl-[3.4rem] pr-3" style={{ bottom: "calc(var(--lh) * 1.2)" }}>
          {entry.tags.slice(0, 4).map((t, i) => (
            <span key={t} className="bg-amber-200/70 px-2 py-0.5 text-[10px] text-amber-950 shadow-sm" style={{ transform: `rotate(${i % 2 ? 2 : -2}deg)` }}>
              #{t}
            </span>
          ))}
        </div>
      )}
      <p className="absolute inset-x-0 text-center text-[11px] opacity-45" style={{ bottom: "calc(var(--lh) * 0.3)" }}>
        — {toBn(number)} {spec.total > 1 ? `(${toBn(spec.index + 1)}/${toBn(spec.total)})` : ""} —
      </p>
    </DiaryPaper>
  );
}
