import { useSyncExternalStore } from "react";
import { emptyData } from "@/domain/defaults";
import type { AppData } from "@/domain/types";
import { normalizeData } from "./normalize";

/**
 * In-memory copy of the user's data. Firestore (see src/firebase/sync.ts) is the real
 * database: it fills this store from its offline cache / server, and every local change
 * made through `setState` is written back to Firestore.
 */
let state: AppData = emptyData();
let localChangeHandler: (() => void) | null = null;
const listeners = new Set<() => void>();

const emit = () => listeners.forEach((l) => l());

export const getState = (): AppData => state;

export function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

/** Used by the sync layer: called after every local (user) change. */
export function setLocalChangeHandler(handler: (() => void) | null): void {
  localChangeHandler = handler;
}

/** A change made by the user — it will be written to Firestore. */
export function setState(updater: (current: AppData) => AppData): void {
  state = updater(state);
  emit();
  localChangeHandler?.();
}

/** A change that came FROM Firestore — it must not be written back. */
export function applyRemote(updater: (current: AppData) => AppData): void {
  state = updater(state);
  emit();
}

export function replaceAll(next: AppData): void {
  setState(() => normalizeData(next));
}

export function useAppData(): AppData {
  return useSyncExternalStore(subscribe, getState, getState);
}
