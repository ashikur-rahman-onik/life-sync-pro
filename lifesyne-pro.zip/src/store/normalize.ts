import { dateKey, isValidDateKey, isValidTime, todayKey } from "@/lib/date";
import { uid } from "@/lib/id";
import { DEFAULT_CATEGORIES, defaultSettings, DEFAULT_CONTAINERS, emptyData } from "@/domain/defaults";
import type {
  Activity,
  AppData,
  Category,
  Container,
  DiaryEntry,
  DoseLog,
  DoseSlot,
  MealRelation,
  MedForm,
  Habit,
  HabitLog,
  Medicine,
  NotifyStyle,
  Prescription,
  Reminder,
  ReminderLog,
  RepeatType,
  Settings,
  Snooze,
  WaterLog,
  WaterMode,
} from "@/domain/types";

const isObj = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null && !Array.isArray(v);
const asStr = (v: unknown, def = ""): string => (typeof v === "string" ? v : def);
const asNum = (v: unknown): number | null => (typeof v === "number" && Number.isFinite(v) ? v : null);
const asBool = (v: unknown, def: boolean): boolean => (typeof v === "boolean" ? v : def);
const asArr = (v: unknown): unknown[] => (Array.isArray(v) ? v : []);
const asIso = (v: unknown, fallback: string): string =>
  typeof v === "string" && !Number.isNaN(Date.parse(v)) ? v : fallback;
const asDate = (v: unknown, fallback: string): string => (isValidDateKey(v) ? v : fallback);
const asTime = (v: unknown, fallback: string): string => (isValidTime(v) ? v : fallback);
const oneOf = <T extends string>(v: unknown, options: readonly T[], def: T): T =>
  typeof v === "string" && (options as readonly string[]).includes(v) ? (v as T) : def;

const FORMS = ["tablet", "capsule", "syrup", "injection", "drops", "other"] as const satisfies readonly MedForm[];
const RELATIONS = ["before", "after", "with", "any"] as const satisfies readonly MealRelation[];
const STYLES = ["normal", "chime", "alarm"] as const satisfies readonly NotifyStyle[];
const REPEATS = ["once", "daily", "weekly", "monthly", "yearly", "interval"] as const satisfies readonly RepeatType[];
const WATER_MODES = ["even", "interval", "custom"] as const satisfies readonly WaterMode[];
const ACTIVITIES = ["low", "moderate", "high"] as const satisfies readonly Activity[];

export function normalizeEntry(raw: unknown): DiaryEntry | null {
  if (!isObj(raw)) return null;
  const content = asStr(raw.content).trim();
  if (!content) return null;
  const nowIso = new Date().toISOString();
  const createdAt = asIso(raw.createdAt, nowIso);
  return {
    id: asStr(raw.id) || uid(),
    title: asStr(raw.title).slice(0, 255),
    content,
    mood: asStr(raw.mood, "neutral") || "neutral",
    tags: asArr(raw.tags).filter((t): t is string => typeof t === "string" && t.trim() !== "").map((t) => t.trim()).slice(0, 10),
    entryDate: asDate(raw.entryDate, dateKey(new Date(createdAt))),
    createdAt,
    updatedAt: asIso(raw.updatedAt, createdAt),
  };
}

export function normalizeContainer(raw: unknown): Container | null {
  if (!isObj(raw)) return null;
  const ml = asNum(raw.ml);
  const name = asStr(raw.name).trim();
  if (!ml || ml <= 0 || !name) return null;
  return { id: asStr(raw.id) || uid(), name, ml, icon: asStr(raw.icon, "🥛") || "🥛" };
}

export function normalizeWaterLog(raw: unknown): WaterLog | null {
  if (!isObj(raw)) return null;
  const ml = asNum(raw.ml);
  if (!ml || ml <= 0) return null;
  const at = asIso(raw.at, new Date().toISOString());
  return {
    id: asStr(raw.id) || uid(),
    date: asDate(raw.date, dateKey(new Date(at))),
    at,
    ml,
    containerName: asStr(raw.containerName, "পানি"),
  };
}

function normalizeSlot(raw: unknown): DoseSlot | null {
  if (!isObj(raw) || !isValidTime(raw.time)) return null;
  const qty = asNum(raw.qty);
  if (!qty || qty <= 0) return null;
  return { id: asStr(raw.id) || uid(), label: asStr(raw.label, "নির্দিষ্ট সময়"), time: raw.time, qty };
}

export function normalizeMedicine(raw: unknown): Medicine | null {
  if (!isObj(raw)) return null;
  const name = asStr(raw.name).trim();
  const slots = asArr(raw.slots).map(normalizeSlot).filter((s): s is DoseSlot => s !== null);
  if (!name || slots.length === 0) return null;
  const startDate = asDate(raw.startDate, todayKey());
  const endRaw = isValidDateKey(raw.endDate) && raw.endDate >= startDate ? raw.endDate : null;
  const stock = asNum(raw.stock);
  return {
    id: asStr(raw.id) || uid(),
    name,
    form: oneOf(raw.form, FORMS, "tablet"),
    slots,
    relation: oneOf(raw.relation, RELATIONS, "any"),
    startDate,
    endDate: endRaw,
    weekdays: [...new Set(asArr(raw.weekdays).filter((d): d is number => Number.isInteger(d) && (d as number) >= 0 && (d as number) <= 6))],
    stock: stock !== null && stock >= 0 ? stock : null,
    notes: asStr(raw.notes),
    doctor: asStr(raw.doctor),
    prescriptionId: asStr(raw.prescriptionId) || null,
    active: asBool(raw.active, true),
    createdAt: asIso(raw.createdAt, new Date().toISOString()),
  };
}

export function normalizePrescription(raw: unknown): Prescription | null {
  if (!isObj(raw) || !asStr(raw.id)) return null;
  return {
    id: asStr(raw.id),
    doctor: asStr(raw.doctor),
    date: asDate(raw.date, todayKey()),
    note: asStr(raw.note),
    createdAt: asIso(raw.createdAt, new Date().toISOString()),
  };
}

export function normalizeDoseLog(raw: unknown): DoseLog | null {
  if (!isObj(raw) || !isValidDateKey(raw.date)) return null;
  const medicineId = asStr(raw.medicineId);
  const slotId = asStr(raw.slotId);
  if (!medicineId || !slotId) return null;
  return {
    id: asStr(raw.id) || uid(),
    key: `${medicineId}|${slotId}|${raw.date}`,
    medicineId,
    medicineName: asStr(raw.medicineName),
    slotId,
    date: raw.date,
    status: raw.status === "skipped" ? "skipped" : "taken",
    at: asIso(raw.at, new Date().toISOString()),
    qty: asNum(raw.qty) ?? 1,
  };
}

export function normalizeSnooze(raw: unknown): Snooze | null {
  if (!isObj(raw) || !isValidDateKey(raw.date) || !isValidTime(raw.time)) return null;
  const refId = asStr(raw.refId) || asStr(raw.medicineId); // older data used "medicineId"
  const slotId = asStr(raw.slotId);
  if (!refId || !slotId) return null;
  return {
    id: asStr(raw.id) || uid(),
    kind: raw.kind === "reminder" ? "reminder" : "med",
    refId,
    slotId,
    date: raw.date,
    time: raw.time,
    at: asIso(raw.at, new Date().toISOString()),
  };
}

const uniqueSorted = <T>(list: T[]): T[] => [...new Set(list)].sort();
const asWeekdays = (v: unknown): number[] =>
  uniqueSorted(asArr(v).filter((d): d is number => Number.isInteger(d) && (d as number) >= 0 && (d as number) <= 6));
const asTimes = (v: unknown): string[] => uniqueSorted(asArr(v).filter(isValidTime)).slice(0, 12);
const asClampedInt = (v: unknown, min: number, max: number, def: number): number => {
  const n = asNum(v);
  return n === null ? def : Math.min(max, Math.max(min, Math.round(n)));
};

export function normalizeReminder(raw: unknown): Reminder | null {
  if (!isObj(raw)) return null;
  const title = asStr(raw.title).trim().slice(0, 120);
  const times = asTimes(raw.times);
  if (!title || times.length === 0) return null;
  const date = asDate(raw.date, todayKey());
  return {
    id: asStr(raw.id) || uid(),
    title,
    note: asStr(raw.note).slice(0, 500),
    icon: asStr(raw.icon, "⏰").slice(0, 8) || "⏰",
    categoryId: asStr(raw.categoryId, "personal"),
    type: oneOf(raw.type, REPEATS, "once"),
    date,
    times,
    weekdays: asWeekdays(raw.weekdays),
    intervalDays: asClampedInt(raw.intervalDays, 1, 365, 2),
    endDate: isValidDateKey(raw.endDate) && raw.endDate >= date ? raw.endDate : null,
    style: oneOf(raw.style, STYLES, "normal"),
    snoozeMin: asClampedInt(raw.snoozeMin, 1, 120, 10),
    earlyMin: asClampedInt(raw.earlyMin, 0, 1440, 0),
    active: asBool(raw.active, true),
    createdAt: asIso(raw.createdAt, new Date().toISOString()),
  };
}

export function normalizeReminderLog(raw: unknown): ReminderLog | null {
  if (!isObj(raw) || !isValidDateKey(raw.date) || !isValidTime(raw.time)) return null;
  const reminderId = asStr(raw.reminderId);
  if (!reminderId) return null;
  const key = `${reminderId}|${raw.time}|${raw.date}`;
  return {
    id: key,
    key,
    reminderId,
    title: asStr(raw.title),
    date: raw.date,
    time: raw.time,
    status: raw.status === "skipped" ? "skipped" : "done",
    at: asIso(raw.at, new Date().toISOString()),
  };
}

export function normalizeHabit(raw: unknown): Habit | null {
  if (!isObj(raw)) return null;
  const name = asStr(raw.name).trim().slice(0, 80);
  if (!name) return null;
  return {
    id: asStr(raw.id) || uid(),
    name,
    icon: asStr(raw.icon, "✅").slice(0, 8) || "✅",
    color: /^#[0-9a-fA-F]{6}$/.test(asStr(raw.color)) ? asStr(raw.color) : "#2b7de9",
    target: asClampedInt(raw.target, 1, 50, 1),
    weekdays: asWeekdays(raw.weekdays),
    times: asTimes(raw.times),
    reminderOn: asBool(raw.reminderOn, false),
    style: oneOf(raw.style, STYLES, "normal"),
    startDate: asDate(raw.startDate, todayKey()),
    archived: asBool(raw.archived, false),
    createdAt: asIso(raw.createdAt, new Date().toISOString()),
  };
}

export function normalizeHabitLog(raw: unknown): HabitLog | null {
  if (!isObj(raw) || !isValidDateKey(raw.date)) return null;
  const habitId = asStr(raw.habitId);
  const count = asNum(raw.count);
  if (!habitId || count === null || count < 0) return null;
  const key = `${habitId}|${raw.date}`;
  return { id: key, key, habitId, date: raw.date, count: Math.round(count) };
}

function normalizeCategories(raw: unknown): Category[] {
  const out: Category[] = [];
  const seen = new Set<string>();
  for (const item of asArr(raw)) {
    if (!isObj(item)) continue;
    const id = asStr(item.id);
    const name = asStr(item.name).trim().slice(0, 30);
    if (!id || !name || seen.has(id)) continue;
    seen.add(id);
    out.push({ id, name, icon: asStr(item.icon, "📌").slice(0, 8) || "📌" });
  }
  return out.length > 0 ? out : DEFAULT_CATEGORIES.map((c) => ({ ...c }));
}

export function normalizeSettings(raw: unknown): Settings {
  const d = defaultSettings();
  if (!isObj(raw)) return d;
  const p = isObj(raw.profile) ? raw.profile : {};
  const w = isObj(raw.water) ? raw.water : {};
  const m = isObj(raw.meals) ? raw.meals : {};
  const dr = isObj(raw.diaryReminder) ? raw.diaryReminder : {};
  const nt = isObj(raw.notify) ? raw.notify : {};
  const age = asNum(p.age);
  const weight = asNum(p.weightKg);
  const goal = asNum(w.goalOverrideMl);
  return {
    profile: {
      name: asStr(p.name).slice(0, 60),
      age: age !== null && age > 0 && age < 120 ? age : null,
      weightKg: weight !== null && weight > 0 && weight < 400 ? weight : null,
      activity: oneOf(p.activity, ACTIVITIES, d.profile.activity),
      hotWeather: asBool(p.hotWeather, d.profile.hotWeather),
    },
    water: {
      goalOverrideMl: goal !== null && goal >= 500 && goal <= 8000 ? Math.round(goal) : null,
      wake: asTime(w.wake, d.water.wake),
      sleep: asTime(w.sleep, d.water.sleep),
      remindersOn: asBool(w.remindersOn, d.water.remindersOn),
      defaultContainerId: typeof w.defaultContainerId === "string" ? w.defaultContainerId : d.water.defaultContainerId,
      mode: oneOf(w.mode, WATER_MODES, d.water.mode),
      intervalMin: asClampedInt(w.intervalMin, 15, 480, d.water.intervalMin),
      customTimes: asTimes(w.customTimes),
    },
    notify: {
      medStyle: oneOf(nt.medStyle, STYLES, d.notify.medStyle),
      waterStyle: oneOf(nt.waterStyle, STYLES, d.notify.waterStyle),
      diaryStyle: oneOf(nt.diaryStyle, STYLES, d.notify.diaryStyle),
      reminderStyle: oneOf(nt.reminderStyle, STYLES, d.notify.reminderStyle),
      medSnoozeMin: asClampedInt(nt.medSnoozeMin, 1, 120, d.notify.medSnoozeMin),
      medEarlyMin: asClampedInt(nt.medEarlyMin, 0, 120, d.notify.medEarlyMin),
      medFollowUps: asClampedInt(nt.medFollowUps, 0, 5, d.notify.medFollowUps),
      medFollowEveryMin: asClampedInt(nt.medFollowEveryMin, 1, 120, d.notify.medFollowEveryMin),
    },
    categories: normalizeCategories(raw.categories),
    showQuotes: asBool(raw.showQuotes, d.showQuotes),
    meals: {
      breakfast: asTime(m.breakfast, d.meals.breakfast),
      lunch: asTime(m.lunch, d.meals.lunch),
      dinner: asTime(m.dinner, d.meals.dinner),
      bed: asTime(m.bed, d.meals.bed),
    },
    medRemindersOn: asBool(raw.medRemindersOn, d.medRemindersOn),
    diaryReminder: { on: asBool(dr.on, d.diaryReminder.on), time: asTime(dr.time, d.diaryReminder.time) },
  };
}

function compact<T extends { id: string }>(items: unknown[], fn: (raw: unknown) => T | null): T[] {
  const out: T[] = [];
  const seen = new Set<string>();
  for (const raw of items) {
    const item = fn(raw);
    if (!item) continue;
    if (seen.has(item.id)) continue;
    seen.add(item.id);
    out.push(item);
  }
  return out;
}

/** Turns anything (old data, imported file, corrupt data) into a valid AppData. */
export function normalizeData(raw: unknown): AppData {
  const base = emptyData();
  if (!isObj(raw)) return base;

  const containers = compact(asArr(raw.containers), normalizeContainer);
  const medicines = compact(asArr(raw.medicines), normalizeMedicine);
  const medIds = new Set(medicines.map((m) => m.id));
  const reminders = compact(asArr(raw.reminders), normalizeReminder);
  const reminderIds = new Set(reminders.map((r) => r.id));

  return {
    version: 1,
    settings: normalizeSettings(raw.settings),
    entries: compact(asArr(raw.entries), normalizeEntry),
    containers: containers.length > 0 ? containers : DEFAULT_CONTAINERS.map((c) => ({ ...c })),
    waterLogs: compact(asArr(raw.waterLogs), normalizeWaterLog),
    medicines,
    prescriptions: compact(asArr(raw.prescriptions), normalizePrescription),
    doseLogs: compact(asArr(raw.doseLogs), normalizeDoseLog),
    snoozes: compact(asArr(raw.snoozes), normalizeSnooze).filter((s) => (s.kind === "med" ? medIds.has(s.refId) : reminderIds.has(s.refId))),
    reminders,
    reminderLogs: compact(asArr(raw.reminderLogs), normalizeReminderLog),
    habits: compact(asArr(raw.habits), normalizeHabit),
    habitLogs: compact(asArr(raw.habitLogs), normalizeHabitLog),
  };
}
