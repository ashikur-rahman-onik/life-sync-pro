import { dateKey } from "@/lib/date";
import { uid } from "@/lib/id";
import { doseKey } from "@/domain/medicine";
import { habitKey } from "@/domain/habits";
import type { Category, Container, DiaryEntry, DoseSlot, Habit, Medicine, Prescription, Reminder, Settings } from "@/domain/types";
import { getState, setState } from "./store";

/* ------------------------------ Diary ------------------------------ */

export type EntryInput = Pick<DiaryEntry, "title" | "content" | "mood" | "tags" | "entryDate">;

export function addEntry(input: EntryInput): string {
  const now = new Date().toISOString();
  const entry: DiaryEntry = { id: uid(), ...input, createdAt: now, updatedAt: now };
  setState((s) => ({ ...s, entries: [entry, ...s.entries] }));
  return entry.id;
}

export function updateEntry(id: string, patch: Partial<EntryInput>): void {
  setState((s) => ({
    ...s,
    entries: s.entries.map((e) => (e.id === id ? { ...e, ...patch, updatedAt: new Date().toISOString() } : e)),
  }));
}

export function deleteEntry(id: string): void {
  setState((s) => ({ ...s, entries: s.entries.filter((e) => e.id !== id) }));
}

/* ------------------------------ Water ------------------------------ */

export function addWater(ml: number, containerName: string): string {
  const now = new Date();
  const id = uid();
  setState((s) => ({
    ...s,
    waterLogs: [...s.waterLogs, { id, date: dateKey(now), at: now.toISOString(), ml, containerName }],
  }));
  return id;
}

export function removeWaterLog(id: string): void {
  setState((s) => ({ ...s, waterLogs: s.waterLogs.filter((l) => l.id !== id) }));
}

export function saveContainer(container: Container): void {
  setState((s) => {
    const exists = s.containers.some((c) => c.id === container.id);
    return { ...s, containers: exists ? s.containers.map((c) => (c.id === container.id ? container : c)) : [...s.containers, container] };
  });
}

export function deleteContainer(id: string): void {
  setState((s) => {
    if (s.containers.length <= 1) return s;
    const containers = s.containers.filter((c) => c.id !== id);
    const defaultId = s.settings.water.defaultContainerId === id ? containers[0].id : s.settings.water.defaultContainerId;
    return { ...s, containers, settings: { ...s.settings, water: { ...s.settings.water, defaultContainerId: defaultId } } };
  });
}

/* ----------------------------- Settings ---------------------------- */

export function updateSettings(fn: (settings: Settings) => Settings): void {
  setState((s) => ({ ...s, settings: fn(s.settings) }));
}

/* ---------------------------- Medicines ---------------------------- */

export function saveMedicines(medicines: Medicine[], prescription?: Prescription): void {
  setState((s) => {
    let list = s.medicines;
    for (const med of medicines) {
      list = list.some((m) => m.id === med.id) ? list.map((m) => (m.id === med.id ? med : m)) : [...list, med];
    }
    const prescriptions = prescription ? [...s.prescriptions.filter((p) => p.id !== prescription.id), prescription] : s.prescriptions;
    return { ...s, medicines: list, prescriptions };
  });
}

export function setMedicineActive(id: string, active: boolean): void {
  setState((s) => ({ ...s, medicines: s.medicines.map((m) => (m.id === id ? { ...m, active } : m)) }));
}

export function deleteMedicine(id: string): void {
  setState((s) => {
    const medicines = s.medicines.filter((m) => m.id !== id);
    const usedPrescriptions = new Set(medicines.map((m) => m.prescriptionId));
    return {
      ...s,
      medicines,
      prescriptions: s.prescriptions.filter((p) => usedPrescriptions.has(p.id)),
      snoozes: s.snoozes.filter((z) => !(z.kind === "med" && z.refId === id)),
    };
  });
}

export function deletePrescription(id: string): void {
  setState((s) => {
    const removed = new Set(s.medicines.filter((m) => m.prescriptionId === id).map((m) => m.id));
    return {
      ...s,
      medicines: s.medicines.filter((m) => m.prescriptionId !== id),
      prescriptions: s.prescriptions.filter((p) => p.id !== id),
      snoozes: s.snoozes.filter((z) => !(z.kind === "med" && removed.has(z.refId))),
    };
  });
}

export function markDose(medicine: Medicine, slot: DoseSlot, date: string, status: "taken" | "skipped"): void {
  const key = doseKey(medicine.id, slot.id, date);
  setState((s) => {
    const previous = s.doseLogs.find((l) => l.key === key);
    const log = {
      id: previous?.id ?? uid(),
      key,
      medicineId: medicine.id,
      medicineName: medicine.name,
      slotId: slot.id,
      date,
      status,
      at: new Date().toISOString(),
      qty: slot.qty,
    };
    // Stock goes down only when a dose is newly taken, and comes back if a taken dose is changed.
    let delta = 0;
    if (status === "taken" && previous?.status !== "taken") delta = -slot.qty;
    if (status !== "taken" && previous?.status === "taken") delta = slot.qty;

    return {
      ...s,
      doseLogs: previous ? s.doseLogs.map((l) => (l.key === key ? log : l)) : [...s.doseLogs, log],
      medicines:
        delta === 0
          ? s.medicines
          : s.medicines.map((m) => (m.id === medicine.id && m.stock !== null ? { ...m, stock: Math.max(0, m.stock + delta) } : m)),
      snoozes: s.snoozes.filter((z) => !(z.kind === "med" && z.refId === medicine.id && z.slotId === slot.id && z.date === date)),
    };
  });
}

export function undoDose(key: string): void {
  setState((s) => {
    const previous = s.doseLogs.find((l) => l.key === key);
    if (!previous) return s;
    return {
      ...s,
      doseLogs: s.doseLogs.filter((l) => l.key !== key),
      medicines:
        previous.status === "taken"
          ? s.medicines.map((m) => (m.id === previous.medicineId && m.stock !== null ? { ...m, stock: m.stock + previous.qty } : m))
          : s.medicines,
    };
  });
}

export interface SnoozeTarget {
  kind: "med" | "reminder";
  refId: string;
  slotId: string; // medicine slot id, or the reminder time
  date: string;
  time: string;
}

export function addSnooze(target: SnoozeTarget, minutes: number): void {
  const at = new Date(Date.now() + minutes * 60_000).toISOString();
  setState((s) => ({
    ...s,
    snoozes: [
      ...s.snoozes.filter((z) => !(z.kind === target.kind && z.refId === target.refId && z.slotId === target.slotId && z.date === target.date)),
      { id: uid(), ...target, at },
    ],
  }));
}

/** Removes snoozes whose time has passed so the list stays tidy. */
export function pruneSnoozes(): void {
  const now = Date.now();
  setState((s) => (s.snoozes.some((z) => Date.parse(z.at) <= now) ? { ...s, snoozes: s.snoozes.filter((z) => Date.parse(z.at) > now) } : s));
}

/* ------------------------ Custom reminders ------------------------ */

export const reminderLogKey = (reminderId: string, time: string, date: string): string => `${reminderId}|${time}|${date}`;

export function saveReminder(reminder: Reminder): void {
  setState((s) => ({
    ...s,
    reminders: s.reminders.some((r) => r.id === reminder.id) ? s.reminders.map((r) => (r.id === reminder.id ? reminder : r)) : [...s.reminders, reminder],
  }));
}

export function setReminderActive(id: string, active: boolean): void {
  setState((s) => ({ ...s, reminders: s.reminders.map((r) => (r.id === id ? { ...r, active } : r)) }));
}

export function deleteReminder(id: string): void {
  setState((s) => ({
    ...s,
    reminders: s.reminders.filter((r) => r.id !== id),
    reminderLogs: s.reminderLogs.filter((l) => l.reminderId !== id),
    snoozes: s.snoozes.filter((z) => !(z.kind === "reminder" && z.refId === id)),
  }));
}

export function markReminder(reminder: Reminder, date: string, time: string, status: "done" | "skipped"): void {
  const key = reminderLogKey(reminder.id, time, date);
  setState((s) => ({
    ...s,
    reminderLogs: [...s.reminderLogs.filter((l) => l.key !== key), { id: key, key, reminderId: reminder.id, title: reminder.title, date, time, status, at: new Date().toISOString() }],
    snoozes: s.snoozes.filter((z) => !(z.kind === "reminder" && z.refId === reminder.id && z.slotId === time && z.date === date)),
  }));
}

export function undoReminder(key: string): void {
  setState((s) => ({ ...s, reminderLogs: s.reminderLogs.filter((l) => l.key !== key) }));
}

/* ----------------------------- Habits ----------------------------- */

export function saveHabit(habit: Habit): void {
  setState((s) => ({
    ...s,
    habits: s.habits.some((h) => h.id === habit.id) ? s.habits.map((h) => (h.id === habit.id ? habit : h)) : [...s.habits, habit],
  }));
}

export function setHabitArchived(id: string, archived: boolean): void {
  setState((s) => ({ ...s, habits: s.habits.map((h) => (h.id === id ? { ...h, archived } : h)) }));
}

export function deleteHabit(id: string): void {
  setState((s) => ({ ...s, habits: s.habits.filter((h) => h.id !== id), habitLogs: s.habitLogs.filter((l) => l.habitId !== id) }));
}

/** Sets how many times a habit was done on a date (0 removes the log). */
export function setHabitCount(habitId: string, date: string, count: number): void {
  const key = habitKey(habitId, date);
  const value = Math.max(0, Math.round(count));
  setState((s) => ({
    ...s,
    habitLogs: value === 0 ? s.habitLogs.filter((l) => l.key !== key) : [...s.habitLogs.filter((l) => l.key !== key), { id: key, key, habitId, date, count: value }],
  }));
}

export function changeHabitCount(habitId: string, date: string, delta: number): void {
  const current = getHabitCount(habitId, date);
  setHabitCount(habitId, date, current + delta);
}

function getHabitCount(habitId: string, date: string): number {
  return getState().habitLogs.find((l) => l.key === habitKey(habitId, date))?.count ?? 0;
}

/* --------------------------- Categories --------------------------- */

export function saveCategory(category: Category): void {
  updateSettings((st) => ({
    ...st,
    categories: st.categories.some((c) => c.id === category.id) ? st.categories.map((c) => (c.id === category.id ? category : c)) : [...st.categories, category],
  }));
}

export function deleteCategory(id: string): void {
  setState((s) => {
    if (s.settings.categories.length <= 1) return s;
    const categories = s.settings.categories.filter((c) => c.id !== id);
    const fallback = categories[0].id;
    return { ...s, settings: { ...s.settings, categories }, reminders: s.reminders.map((r) => (r.categoryId === id ? { ...r, categoryId: fallback } : r)) };
  });
}
