import { useEffect, useState } from "react";
import type { Attachment } from "@/domain/types";
import { uid } from "@/lib/id";
import { deleteBlob, getBlob, putBlob } from "./blobStore";
import { MAX_FILE_BYTES, thumbUrl } from "./cloudinary";
import { compressImage } from "./image";

/** Saves a picked file on the phone and returns the attachment record (upload happens later, in the background). */
export async function createAttachment(file: File, opts: { maxSide?: number } = {}): Promise<Attachment> {
  const isImage = file.type.startsWith("image/") && file.type !== "image/gif" && file.type !== "image/svg+xml";
  const blob = isImage ? await compressImage(file, opts.maxSide ?? 1600) : file;
  if (blob.size > MAX_FILE_BYTES) throw new Error("ফাইলটি ১০ মেগাবাইটের বেশি বড় — ছোট ফাইল দিন");
  const id = uid();
  const localKey = `att-${id}`;
  await putBlob(localKey, blob);
  return {
    id,
    name: file.name || "ফাইল",
    kind: file.type.startsWith("image/") ? "image" : "file",
    mime: blob.type || file.type,
    bytes: blob.size,
    url: null,
    localKey,
  };
}

/** Frees the phone copies of removed attachments. */
export async function removeLocalBlobs(attachments: Attachment[]): Promise<void> {
  await Promise.all(attachments.filter((a) => a.localKey).map((a) => deleteBlob(a.localKey as string).catch(() => undefined)));
}

/** Picture source for an attachment: the Cloudinary link, or the phone copy while it waits to upload. */
export function useAttachmentSrc(att: Attachment | null, width?: number): string | null {
  const remote = att?.url ? (width ? thumbUrl(att.url, width) : att.url) : null;
  const localKey = att && !att.url ? att.localKey : null;
  const [local, setLocal] = useState<string | null>(null);

  useEffect(() => {
    if (!localKey) return;
    let objectUrl: string | null = null;
    let cancelled = false;
    void getBlob(localKey).then((blob) => {
      if (cancelled || !blob) return;
      objectUrl = URL.createObjectURL(blob);
      setLocal(objectUrl);
    });
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
      setLocal(null);
    };
  }, [localKey]);

  return remote ?? local;
}
