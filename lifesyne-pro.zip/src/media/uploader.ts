import { useSyncExternalStore } from "react";
import { pendingAttachments } from "@/domain/attachments";
import { patchAttachment } from "@/store/actions";
import { getState, subscribe } from "@/store/store";
import { deleteBlob, getBlob } from "./blobStore";
import { cloudinaryReady, uploadToCloudinary } from "./cloudinary";

export interface UploadStatus {
  pending: number;
  uploading: boolean;
  error: string | null;
}

let status: UploadStatus = { pending: 0, uploading: false, error: null };
const listeners = new Set<() => void>();

function setStatus(next: Partial<UploadStatus>): void {
  const merged = { ...status, ...next };
  if (merged.pending === status.pending && merged.uploading === status.uploading && merged.error === status.error) return;
  status = merged;
  listeners.forEach((l) => l());
}

export function useUploadStatus(): UploadStatus {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => {
        listeners.delete(l);
      };
    },
    () => status,
    () => status,
  );
}

/**
 * Background worker: uploads photos/files saved on this phone to Cloudinary whenever
 * there is internet and the Cloudinary settings are filled in, then keeps only the link.
 */
export function startUploader(): () => void {
  let running = false;
  let stopped = false;
  let failures = 0;
  let retryAt = 0;
  let timer: ReturnType<typeof setTimeout> | null = null;

  const run = async () => {
    const data = getState();
    const pending = pendingAttachments(data);
    setStatus({ pending: pending.length });
    if (running || stopped || pending.length === 0 || !navigator.onLine || Date.now() < retryAt) return;
    const cfg = data.settings.cloudinary;
    if (!cloudinaryReady(cfg)) return;

    running = true;
    setStatus({ uploading: true });
    try {
      for (const att of pending) {
        if (stopped) break;
        const blob = att.localKey ? await getBlob(att.localKey) : null;
        if (!blob) continue; // copy lives on another phone
        const url = await uploadToCloudinary(blob, att.name, cfg);
        patchAttachment(att.id, { url, localKey: null });
        await deleteBlob(att.localKey as string).catch(() => undefined);
      }
      failures = 0;
      setStatus({ error: null });
    } catch (e) {
      failures++;
      retryAt = Date.now() + Math.min(600_000, 20_000 * 2 ** failures);
      setStatus({ error: e instanceof Error ? e.message : "আপলোড হয়নি" });
    } finally {
      running = false;
      setStatus({ uploading: false, pending: pendingAttachments(getState()).length });
    }
  };

  const kick = () => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => void run(), 1200);
  };

  const unsubscribe = subscribe(kick);
  const interval = setInterval(() => void run(), 60_000);
  window.addEventListener("online", kick);
  kick();

  return () => {
    stopped = true;
    unsubscribe();
    clearInterval(interval);
    window.removeEventListener("online", kick);
    if (timer) clearTimeout(timer);
  };
}

/** Lets the user retry right away (resets the back-off). */
export function retryUploadsNow(): void {
  window.dispatchEvent(new Event("online"));
}
