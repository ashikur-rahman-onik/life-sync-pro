/**
 * Photos/files that are waiting to be uploaded live here (IndexedDB), never in Firestore.
 * Once uploaded to Cloudinary the copy is deleted and only the link is kept.
 */
const DB_NAME = "lifesyne-media";
const STORE = "blobs";

function open(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function run<T>(mode: IDBTransactionMode, fn: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await open();
  try {
    return await new Promise<T>((resolve, reject) => {
      const tx = db.transaction(STORE, mode);
      const req = fn(tx.objectStore(STORE));
      tx.oncomplete = () => resolve(req.result);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  } finally {
    db.close();
  }
}

export const putBlob = (key: string, blob: Blob): Promise<IDBValidKey> => run("readwrite", (s) => s.put(blob, key));
export const getBlob = async (key: string): Promise<Blob | null> => ((await run("readonly", (s) => s.get(key))) as Blob | undefined) ?? null;
export const deleteBlob = (key: string): Promise<undefined> => run("readwrite", (s) => s.delete(key));
