import type { CloudinarySettings } from "@/domain/types";

/** Cloudinary's free plan accepts files up to 10 MB. */
export const MAX_FILE_BYTES = 10 * 1024 * 1024;

export const cloudinaryReady = (c: CloudinarySettings): boolean => c.cloudName.trim() !== "" && c.uploadPreset.trim() !== "";

/** Unsigned upload (needs an "Unsigned" upload preset made in the Cloudinary dashboard). */
export async function uploadToCloudinary(blob: Blob, name: string, cfg: CloudinarySettings): Promise<string> {
  const form = new FormData();
  form.append("file", blob, name);
  form.append("upload_preset", cfg.uploadPreset.trim());
  if (cfg.folder.trim()) form.append("folder", cfg.folder.trim());

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 90_000);
  try {
    const res = await fetch(`https://api.cloudinary.com/v1_1/${encodeURIComponent(cfg.cloudName.trim())}/auto/upload`, { method: "POST", body: form, signal: controller.signal });
    const json = (await res.json().catch(() => ({}))) as { secure_url?: string; error?: { message?: string } };
    if (!res.ok || !json.secure_url) throw new Error(json.error?.message ?? `HTTP ${res.status}`);
    return json.secure_url;
  } finally {
    clearTimeout(timer);
  }
}

/** Smaller, optimised copy of a Cloudinary image for lists and thumbnails. */
export function thumbUrl(url: string, width: number): string {
  return url.includes("/image/upload/") ? url.replace("/image/upload/", `/image/upload/w_${width},c_limit,q_auto,f_auto/`) : url;
}
