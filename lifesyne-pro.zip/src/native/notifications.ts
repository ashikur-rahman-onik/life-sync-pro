import { LocalNotifications, type ActionPerformed, type Channel, type LocalNotificationSchema } from "@capacitor/local-notifications";
import type { PluginListenerHandle } from "@capacitor/core";
import type { AppData } from "@/domain/types";
import { planReminders, planSignature, type PlannedNotification, type ReminderChannel } from "@/domain/reminders";
import { isNative } from "./platform";

export type PermissionStatus = "granted" | "denied" | "prompt" | "unsupported";

const CHANNELS: Record<ReminderChannel, Channel> = {
  medicine: {
    id: "medicine_v1",
    name: "ওষুধের রিমাইন্ডার",
    description: "ওষুধ খাওয়ার সময় মনে করিয়ে দেয়",
    importance: 5,
    visibility: 1,
    vibration: true,
    lights: true,
    lightColor: "#8B6FD1",
  },
  water: {
    id: "water_v1",
    name: "পানি খাওয়ার রিমাইন্ডার",
    description: "নিয়মিত পানি খাওয়ার কথা মনে করিয়ে দেয়",
    importance: 4,
    visibility: 1,
    vibration: true,
    lights: true,
    lightColor: "#3B9AE1",
  },
  diary: {
    id: "diary_v1",
    name: "ডায়েরি রিমাইন্ডার",
    description: "প্রতিদিন ডায়েরি লেখার কথা মনে করিয়ে দেয়",
    importance: 3,
    visibility: 1,
    vibration: false,
    lights: false,
  },
};

function mapPermission(state: string): PermissionStatus {
  if (state === "granted") return "granted";
  if (state === "denied") return "denied";
  return "prompt";
}

export async function getNotificationPermission(): Promise<PermissionStatus> {
  if (!isNative()) return "unsupported";
  try {
    return mapPermission((await LocalNotifications.checkPermissions()).display);
  } catch {
    return "unsupported";
  }
}

export async function requestNotificationPermission(): Promise<PermissionStatus> {
  if (!isNative()) return "unsupported";
  try {
    return mapPermission((await LocalNotifications.requestPermissions()).display);
  } catch {
    return "unsupported";
  }
}

/** Exact alarms make reminders fire on the minute (Android 12+). */
export async function getExactAlarmStatus(): Promise<PermissionStatus> {
  if (!isNative()) return "unsupported";
  try {
    return mapPermission((await LocalNotifications.checkExactNotificationSetting()).exact_alarm);
  } catch {
    return "unsupported";
  }
}

export async function openExactAlarmSettings(): Promise<void> {
  if (!isNative()) return;
  try {
    await LocalNotifications.changeExactNotificationSetting();
  } catch {
    /* settings screen not available on this Android version */
  }
}

let setupDone = false;

async function ensureSetup(): Promise<void> {
  if (setupDone) return;
  await Promise.all(Object.values(CHANNELS).map((c) => LocalNotifications.createChannel(c)));
  await LocalNotifications.registerActionTypes({
    types: [
      {
        id: "MED_DOSE",
        actions: [
          { id: "taken", title: "✅ খেয়েছি" },
          { id: "snooze", title: "⏰ ১০ মিনিট পরে" },
        ],
      },
      { id: "WATER", actions: [{ id: "drank", title: "💧 খেয়েছি" }] },
    ],
  });
  setupDone = true;
}

function toSchema(n: PlannedNotification): LocalNotificationSchema {
  return {
    id: n.id,
    title: n.title,
    body: n.body,
    channelId: CHANNELS[n.channel].id,
    actionTypeId: n.actionTypeId,
    extra: n.extra,
    autoCancel: true,
    schedule: n.at ? { at: n.at, allowWhileIdle: true } : { on: n.on, allowWhileIdle: true },
  };
}

let queue: Promise<unknown> = Promise.resolve();
let lastSignature = "";

/**
 * Makes the phone's scheduled notifications match the app data.
 * Calls are serialised so a cancel/schedule pair never interleaves with another one.
 * Returns the number of notifications scheduled (0 if permission is missing).
 */
export function syncReminders(data: AppData, force = false): Promise<number> {
  const run = async (): Promise<number> => {
    if (!isNative()) return 0;
    if ((await getNotificationPermission()) !== "granted") return 0;

    const plan = planReminders(data);
    const signature = planSignature(plan);
    if (!force && signature === lastSignature) return plan.length;

    await ensureSetup();
    const pending = await LocalNotifications.getPending();
    if (pending.notifications.length > 0) {
      await LocalNotifications.cancel({ notifications: pending.notifications.map((n) => ({ id: n.id })) });
    }
    if (plan.length > 0) await LocalNotifications.schedule({ notifications: plan.map(toSchema) });
    lastSignature = signature;
    return plan.length;
  };
  const next = queue.then(run, run);
  queue = next.catch(() => undefined);
  return next;
}

export async function listenForNotificationActions(
  handler: (actionId: string, extra: Record<string, string> | undefined) => void,
): Promise<() => void> {
  if (!isNative()) return () => undefined;
  const handle: PluginListenerHandle = await LocalNotifications.addListener(
    "localNotificationActionPerformed",
    (event: ActionPerformed) => handler(event.actionId, event.notification.extra as Record<string, string> | undefined),
  );
  return () => {
    void handle.remove();
  };
}
