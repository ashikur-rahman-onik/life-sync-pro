import { LocalNotifications, type ActionPerformed, type Channel, type LocalNotificationSchema } from "@capacitor/local-notifications";
import type { PluginListenerHandle } from "@capacitor/core";
import type { AppData } from "@/domain/types";
import { planReminders, planSignature, type PlannedNotification, type ReminderKind } from "@/domain/reminders";
import type { NotifyStyle } from "@/domain/types";
import { isNative } from "./platform";

export type PermissionStatus = "granted" | "denied" | "prompt" | "unsupported";

/** One channel per sound style (Android fixes a channel's sound once it exists, hence the _v1 suffix). */
const CHANNELS: Record<NotifyStyle, Channel> = {
  normal: {
    id: "normal_v1",
    name: "সাধারণ রিমাইন্ডার",
    description: "ফোনের ডিফল্ট শব্দে রিমাইন্ডার",
    importance: 4,
    visibility: 1,
    vibration: true,
    lights: true,
    lightColor: "#2B7DE9",
  },
  chime: {
    id: "chime_v1",
    name: "মৃদু চাইম",
    description: "নরম সুরের রিমাইন্ডার",
    importance: 4,
    visibility: 1,
    sound: "chime.wav",
    vibration: true,
    lights: true,
    lightColor: "#16C060",
  },
  alarm: {
    id: "alarm_v1",
    name: "অ্যালার্ম (জোরালো)",
    description: "লম্বা জোরালো অ্যালার্ম সুর — জরুরি রিমাইন্ডারের জন্য",
    importance: 5,
    visibility: 1,
    sound: "alarm.wav",
    vibration: true,
    lights: true,
    lightColor: "#EF4444",
  },
};

/** Channels from the first app version, removed so the phone's settings stay tidy. */
const LEGACY_CHANNELS = ["medicine_v1", "water_v1", "diary_v1"];

function mapPermission(state: string): PermissionStatus {
  if (state === "granted") return "granted";
  if (state === "denied") return "denied";
  return "prompt";
}

export async function getNotificationPermission(): Promise<PermissionStatus> {
  if (!isNative()) return "unsupported";
  try {
    return mapPermission((await LocalNotifications.checkPermissions()).display);
  } catch {
    return "unsupported";
  }
}

export async function requestNotificationPermission(): Promise<PermissionStatus> {
  if (!isNative()) return "unsupported";
  try {
    return mapPermission((await LocalNotifications.requestPermissions()).display);
  } catch {
    return "unsupported";
  }
}

/** Exact alarms make reminders fire on the minute (Android 12+). */
export async function getExactAlarmStatus(): Promise<PermissionStatus> {
  if (!isNative()) return "unsupported";
  try {
    return mapPermission((await LocalNotifications.checkExactNotificationSetting()).exact_alarm);
  } catch {
    return "unsupported";
  }
}

export async function openExactAlarmSettings(): Promise<void> {
  if (!isNative()) return;
  try {
    await LocalNotifications.changeExactNotificationSetting();
  } catch {
    /* settings screen not available on this Android version */
  }
}

let setupDone = false;

async function ensureSetup(): Promise<void> {
  if (setupDone) return;
  await Promise.all(LEGACY_CHANNELS.map((id) => LocalNotifications.deleteChannel({ id }).catch(() => undefined)));
  await Promise.all(Object.values(CHANNELS).map((c) => LocalNotifications.createChannel(c)));
  await LocalNotifications.registerActionTypes({
    types: [
      {
        id: "MED_DOSE",
        actions: [
          { id: "taken", title: "✅ খেয়েছি" },
          { id: "snooze", title: "⏰ ১০ মিনিট পরে" },
        ],
      },
      { id: "WATER", actions: [{ id: "drank", title: "💧 খেয়েছি" }] },
      {
        id: "REMINDER",
        actions: [
          { id: "done", title: "✅ হয়েছে" },
          { id: "snooze", title: "⏰ পরে মনে করান" },
        ],
      },
      { id: "HABIT", actions: [{ id: "done", title: "✅ করেছি" }] },
    ],
  });
  setupDone = true;
}

/** Each kind of reminder gets its own round icon, colour and label so notifications are recognisable at a glance. */
const LOOK: Record<ReminderKind, { largeIcon: string; color: string; label: string }> = {
  water: { largeIcon: "ic_large_water", color: "#3B9AE1", label: "পানি" },
  med: { largeIcon: "ic_large_med", color: "#8B6FD1", label: "ওষুধ" },
  reminder: { largeIcon: "ic_large_reminder", color: "#2B7DE9", label: "রিমাইন্ডার" },
  habit: { largeIcon: "ic_large_habit", color: "#16A05D", label: "অভ্যাস" },
  diary: { largeIcon: "ic_large_diary", color: "#8A5A3C", label: "ডায়েরি" },
};

function toSchema(n: PlannedNotification): LocalNotificationSchema {
  const look = LOOK[n.kind];
  return {
    id: n.id,
    title: n.title,
    body: n.body,
    largeBody: n.body,
    summaryText: `LifeSyne Pro · ${look.label}`,
    largeIcon: look.largeIcon,
    iconColor: look.color,
    channelId: CHANNELS[n.style].id,
    actionTypeId: n.actionTypeId,
    extra: n.extra,
    autoCancel: true,
    schedule: n.at ? { at: n.at, allowWhileIdle: true } : { on: n.on, allowWhileIdle: true },
  };
}

let queue: Promise<unknown> = Promise.resolve();
let lastSignature = "";

/**
 * Makes the phone's scheduled notifications match the app data.
 * Calls are serialised so a cancel/schedule pair never interleaves with another one.
 * Returns the number of notifications scheduled (0 if permission is missing).
 */
export function syncReminders(data: AppData, force = false): Promise<number> {
  const run = async (): Promise<number> => {
    if (!isNative()) return 0;
    if ((await getNotificationPermission()) !== "granted") return 0;

    const plan = planReminders(data);
    const signature = planSignature(plan);
    if (!force && signature === lastSignature) return plan.length;

    await ensureSetup();
    const pending = await LocalNotifications.getPending();
    if (pending.notifications.length > 0) {
      await LocalNotifications.cancel({ notifications: pending.notifications.map((n) => ({ id: n.id })) });
    }
    if (plan.length > 0) await LocalNotifications.schedule({ notifications: plan.map(toSchema) });
    lastSignature = signature;
    return plan.length;
  };
  const next = queue.then(run, run);
  queue = next.catch(() => undefined);
  return next;
}

export async function listenForNotificationActions(
  handler: (actionId: string, extra: Record<string, string> | undefined) => void,
): Promise<() => void> {
  if (!isNative()) return () => undefined;
  const handle: PluginListenerHandle = await LocalNotifications.addListener(
    "localNotificationActionPerformed",
    (event: ActionPerformed) => handler(event.actionId, event.notification.extra as Record<string, string> | undefined),
  );
  return () => {
    void handle.remove();
  };
}

/** Fires a sample notification in 3 seconds so the user can hear each style. */
export async function sendTestNotification(style: NotifyStyle): Promise<boolean> {
  if (!isNative() || (await getNotificationPermission()) !== "granted") return false;
  await ensureSetup();
  await LocalNotifications.schedule({
    notifications: [
      {
        id: 9_999_001,
        title: style === "alarm" ? "⏰ অ্যালার্ম টেস্ট" : style === "chime" ? "🎵 চাইম টেস্ট" : "🔔 নোটিফিকেশন টেস্ট",
        body: "এভাবেই রিমাইন্ডার আসবে",
        summaryText: "LifeSyne Pro · টেস্ট",
        largeIcon: "ic_large_brand",
        iconColor: "#2B7DE9",
        channelId: CHANNELS[style].id,
        schedule: { at: new Date(Date.now() + 3000), allowWhileIdle: true },
      },
    ],
  });
  return true;
}
