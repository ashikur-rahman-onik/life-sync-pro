import { useSyncExternalStore } from "react";
import { App } from "@capacitor/app";
import { Directory, Filesystem } from "@capacitor/filesystem";
import { FileTransfer } from "@capacitor/file-transfer";
import { FileOpener } from "@capacitor-community/file-opener";
import { isNative } from "./platform";

/** "owner/repo" — injected at build time by the GitHub workflow. */
const REPO = import.meta.env.VITE_GITHUB_REPO ?? "";
const META_KEY = "amar_update_meta_v1";
const APK_FILE = "lifesyne-pro-update.apk";
const AUTO_CHECK_EVERY_MS = 6 * 60 * 60 * 1000;

export interface AppVersion {
  name: string;
  build: number;
}

export interface UpdateInfo {
  build: number;
  versionName: string;
  notes: string;
  apkUrl: string;
  sizeBytes: number;
}

export type UpdaterStatus = "idle" | "checking" | "available" | "uptodate" | "downloading" | "error";

export interface UpdaterState {
  status: UpdaterStatus;
  current: AppVersion | null;
  info: UpdateInfo | null;
  progress: number;
  error: string;
  dismissedBuild: number;
}

interface Meta {
  lastCheckAt: number;
  dismissedBuild: number;
}

function loadMeta(): Meta {
  try {
    const raw = JSON.parse(localStorage.getItem(META_KEY) ?? "{}") as Partial<Meta>;
    return { lastCheckAt: Number(raw.lastCheckAt) || 0, dismissedBuild: Number(raw.dismissedBuild) || 0 };
  } catch {
    return { lastCheckAt: 0, dismissedBuild: 0 };
  }
}

function saveMeta(patch: Partial<Meta>): void {
  try {
    localStorage.setItem(META_KEY, JSON.stringify({ ...loadMeta(), ...patch }));
  } catch {
    /* storage full — update checks simply run again next time */
  }
}

let state: UpdaterState = {
  status: "idle",
  current: null,
  info: null,
  progress: 0,
  error: "",
  dismissedBuild: loadMeta().dismissedBuild,
};
const listeners = new Set<() => void>();

function setUpdater(patch: Partial<UpdaterState>): void {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
}

const subscribe = (l: () => void) => {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
};

export function useUpdater(): UpdaterState {
  return useSyncExternalStore(subscribe, () => state, () => state);
}

/** In-app updates only work inside the installed Android app and when the repo is known. */
export const updatesAvailable = (): boolean => isNative() && REPO !== "";

export async function getAppVersion(): Promise<AppVersion> {
  if (isNative()) {
    const info = await App.getInfo();
    return { name: info.version, build: Number(info.build) || 0 };
  }
  return { name: __APP_VERSION__, build: 0 };
}

interface GithubRelease {
  tag_name?: string;
  name?: string;
  body?: string;
  assets?: { name?: string; browser_download_url?: string; size?: number }[];
}

/** Release tags look like "b29712345" — the number is the Android versionCode. */
export function parseBuildFromTag(tag: string): number | null {
  const match = /(\d+)$/.exec(tag);
  return match ? Number(match[1]) : null;
}

export function parseRelease(release: GithubRelease): UpdateInfo | null {
  const build = parseBuildFromTag(release.tag_name ?? "");
  const apk = release.assets?.find((a) => a.name?.toLowerCase().endsWith(".apk") && a.browser_download_url);
  if (build === null || !apk?.browser_download_url) return null;
  return {
    build,
    versionName: (release.name ?? release.tag_name ?? "").replace(/^v/i, "").trim(),
    notes: (release.body ?? "").trim(),
    apkUrl: apk.browser_download_url,
    sizeBytes: apk.size ?? 0,
  };
}

async function fetchLatest(): Promise<UpdateInfo | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15_000);
  try {
    const res = await fetch(`https://api.github.com/repos/${REPO}/releases/latest`, {
      headers: { Accept: "application/vnd.github+json" },
      cache: "no-store",
      signal: controller.signal,
    });
    if (res.status === 404) return null; // no release yet (or repository is private)
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return parseRelease((await res.json()) as GithubRelease);
  } finally {
    clearTimeout(timer);
  }
}

/** Checks GitHub Releases. `silent` = background check (no error shown, throttled to every 6 hours). */
export async function checkForUpdate(silent: boolean): Promise<void> {
  if (!updatesAvailable()) return;
  if (state.status === "checking" || state.status === "downloading") return;
  if (silent && Date.now() - loadMeta().lastCheckAt < AUTO_CHECK_EVERY_MS) return;

  setUpdater({ status: "checking", error: "" });
  try {
    const [current, latest] = await Promise.all([getAppVersion(), fetchLatest()]);
    saveMeta({ lastCheckAt: Date.now() });
    if (latest && latest.build > current.build) {
      setUpdater({ status: "available", current, info: latest });
    } else {
      setUpdater({ status: "uptodate", current, info: null });
    }
  } catch {
    setUpdater({ status: silent ? "idle" : "error", error: "ইন্টারনেট সংযোগ চেক করে আবার চেষ্টা করুন" });
  }
}

export function dismissUpdate(): void {
  if (!state.info) return;
  saveMeta({ dismissedBuild: state.info.build });
  setUpdater({ dismissedBuild: state.info.build });
}

/** Downloads the new APK and opens Android's installer. Installing over the old app keeps all data. */
export async function startUpdate(): Promise<void> {
  const info = state.info;
  if (!info || state.status === "downloading") return;

  setUpdater({ status: "downloading", progress: 0, error: "" });
  let listener: { remove: () => Promise<void> } | null = null;
  try {
    try {
      await Filesystem.deleteFile({ path: APK_FILE, directory: Directory.Cache });
    } catch {
      /* no old download */
    }
    const { uri } = await Filesystem.getUri({ path: APK_FILE, directory: Directory.Cache });

    listener = await FileTransfer.addListener("progress", (p) => {
      if (p.type !== "download") return;
      const total = p.lengthComputable && p.contentLength > 0 ? p.contentLength : info.sizeBytes;
      if (total > 0) setUpdater({ progress: Math.min(100, Math.round((p.bytes / total) * 100)) });
    });
    await FileTransfer.downloadFile({ url: info.apkUrl, path: uri, progress: true });

    const stat = await Filesystem.stat({ path: APK_FILE, directory: Directory.Cache });
    if (info.sizeBytes > 0 && stat.size !== info.sizeBytes) throw new Error("incomplete download");

    setUpdater({ status: "available", progress: 100 });
    await FileOpener.open({ filePath: uri, contentType: "application/vnd.android.package-archive" });
  } catch {
    setUpdater({ status: "error", error: "আপডেট ডাউনলোড বা ইনস্টল শুরু করা যায়নি। ইন্টারনেট চেক করে আবার চেষ্টা করুন।" });
  } finally {
    if (listener) await listener.remove();
  }
}
