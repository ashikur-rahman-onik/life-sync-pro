import { Directory, Encoding, Filesystem } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";
import { todayKey } from "@/lib/date";
import type { AppData, DiaryEntry } from "@/domain/types";
import { normalizeData, normalizeEntry } from "@/store/normalize";
import { isNative } from "./platform";

export const BACKUP_APP_ID = "lifesyne-pro";
const ACCEPTED_BACKUP_IDS = [BACKUP_APP_ID, "amar-diary-plus"];

export function buildBackupJson(data: AppData): string {
  return JSON.stringify({ app: BACKUP_APP_ID, version: 1, exportedAt: new Date().toISOString(), data }, null, 2);
}

export type ParsedBackup = { kind: "full"; data: AppData } | { kind: "entries"; entries: DiaryEntry[] };

/** Accepts our full backup, or the plain entries array exported by the old web version. */
export function parseBackup(text: string): ParsedBackup {
  let raw: unknown;
  try {
    raw = JSON.parse(text);
  } catch {
    throw new Error("ফাইলটি পড়া যায়নি — এটি সঠিক ব্যাকআপ ফাইল নয়");
  }

  if (Array.isArray(raw)) {
    const entries = raw
      .map((item) => normalizeEntry(item && typeof item === "object" ? { ...(item as object), id: "" } : item))
      .filter((e): e is DiaryEntry => e !== null);
    if (entries.length === 0) throw new Error("ফাইলে কোনো এন্ট্রি পাওয়া যায়নি");
    return { kind: "entries", entries };
  }

  if (raw && typeof raw === "object" && ACCEPTED_BACKUP_IDS.includes((raw as { app?: string }).app ?? "")) {
    return { kind: "full", data: normalizeData((raw as { data?: unknown }).data) };
  }
  throw new Error("এটি LifeSyne Pro-এর ব্যাকআপ ফাইল নয়");
}

/** Saves/shares the backup. On Android it opens the share sheet (Drive, WhatsApp, Files…). */
export async function exportBackup(data: AppData): Promise<"shared" | "downloaded"> {
  const json = buildBackupJson(data);
  const filename = `lifesyne-pro-backup-${todayKey()}.json`;

  if (isNative()) {
    await Filesystem.writeFile({ path: filename, data: json, directory: Directory.Cache, encoding: Encoding.UTF8 });
    const { uri } = await Filesystem.getUri({ path: filename, directory: Directory.Cache });
    await Share.share({ title: "আমার ডায়েরি ব্যাকআপ", url: uri, dialogTitle: "ব্যাকআপ ফাইলটি সেভ বা শেয়ার করুন" });
    return "shared";
  }

  const url = URL.createObjectURL(new Blob([json], { type: "application/json" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
  return "downloaded";
}
