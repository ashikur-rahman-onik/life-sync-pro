import { useEffect, useRef } from "react";
import { App as CapApp } from "@capacitor/app";
import { useLocation, useNavigate } from "react-router-dom";
import { consumeBack } from "@/lib/backStack";
import { pruneSnoozes } from "@/store/actions";
import { getState, subscribe } from "@/store/store";
import { listenForNotificationActions, syncReminders } from "./notifications";
import { handleNotificationAction } from "./notificationActions";
import { isNative } from "./platform";
import { checkForUpdate } from "./updater";

/** Everything that connects the web app to the phone: back button, reminders, updates. */
export function useNativeBridge(): void {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const pathRef = useRef(pathname);
  useEffect(() => {
    pathRef.current = pathname;
  }, [pathname]);

  /* Android back button */
  useEffect(() => {
    if (!isNative()) return;
    let remove: (() => void) | undefined;
    void CapApp.addListener("backButton", () => {
      if (consumeBack()) return;
      if (pathRef.current !== "/") {
        if (window.history.length > 1) navigate(-1);
        else navigate("/", { replace: true });
      } else {
        void CapApp.exitApp();
      }
    }).then((h) => {
      remove = () => void h.remove();
    });
    return () => remove?.();
  }, [navigate]);

  /* Keep scheduled reminders in sync with the data */
  useEffect(() => {
    if (!isNative()) return;
    let timer: ReturnType<typeof setTimeout> | null = null;
    const sync = () => void syncReminders(getState()).catch(() => undefined);
    const schedule = () => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(sync, 1000);
    };
    const refresh = () => {
      pruneSnoozes();
      sync();
      void checkForUpdate(true);
    };

    refresh();
    const unsubscribe = subscribe(schedule);
    const onVisible = () => document.visibilityState === "visible" && refresh();
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      unsubscribe();
      document.removeEventListener("visibilitychange", onVisible);
      if (timer) clearTimeout(timer);
    };
  }, []);

  /* Notification taps / action buttons */
  useEffect(() => {
    let remove: (() => void) | undefined;
    let cancelled = false;
    void listenForNotificationActions(handleNotificationAction).then((fn) => {
      if (cancelled) fn();
      else remove = fn;
    });
    return () => {
      cancelled = true;
      remove?.();
    };
  }, []);
}
