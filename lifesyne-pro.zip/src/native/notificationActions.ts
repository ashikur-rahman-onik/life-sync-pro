import { addDays, nowMinutes, timeToMinutes, todayKey } from "@/lib/date";
import { navigateTo } from "@/lib/navigate";
import { showToast } from "@/lib/toast";
import { formatMl } from "@/lib/bn";
import { addSnooze, addWater, markDose } from "@/store/actions";
import { getState } from "@/store/store";

/** Repeating reminders carry no date; late-night taps right after midnight belong to yesterday. */
function resolveDoseDate(extra: Record<string, string>): string {
  if (extra.date) return extra.date;
  const today = todayKey();
  return extra.time && timeToMinutes(extra.time) - nowMinutes() > 12 * 60 ? addDays(today, -1) : today;
}

/** Called when the user taps a reminder or one of its action buttons. */
export function handleNotificationAction(actionId: string, extra: Record<string, string> | undefined): void {
  if (!extra) return;
  const state = getState();

  if (extra.kind === "med") {
    const med = state.medicines.find((m) => m.id === extra.medId);
    const slot = med?.slots.find((s) => s.id === extra.slotId);
    if (med && slot) {
      const date = resolveDoseDate(extra);
      if (actionId === "taken") {
        markDose(med, slot, date, "taken");
        showToast(`✅ ${med.name} খাওয়া হয়েছে`);
      } else if (actionId === "snooze") {
        addSnooze(med, slot, date, 10);
        showToast("⏰ ১০ মিনিট পরে আবার মনে করিয়ে দেব");
      }
    }
    navigateTo("/medicine");
    return;
  }

  if (extra.kind === "water") {
    if (actionId === "drank") {
      const c = state.containers.find((x) => x.id === state.settings.water.defaultContainerId) ?? state.containers[0];
      if (c) {
        addWater(c.ml, c.name);
        showToast(`💧 ${formatMl(c.ml)} পানি যোগ হয়েছে`);
      }
    }
    navigateTo("/water");
    return;
  }

  if (extra.kind === "diary") navigateTo("/new");
}
