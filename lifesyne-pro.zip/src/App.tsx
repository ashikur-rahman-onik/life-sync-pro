import { useEffect, type ReactNode } from "react";
import { HashRouter, Navigate, Route, Routes } from "react-router-dom";
import AchievementsPage from "@/pages/Achievements";
import AuthScreen from "@/components/AuthScreen";
import BottomNav from "@/components/BottomNav";
import Confetti from "@/components/Confetti";
import { FeedbackProvider } from "@/components/Feedback";
import LockGate from "@/components/LockGate";
import SyncBanner from "@/components/SyncBanner";
import { emptyData } from "@/domain/defaults";
import { useAuthState } from "@/firebase/auth";
import { useSyncStatus } from "@/firebase/status";
import { startSync } from "@/firebase/sync";
import { startUploader } from "@/media/uploader";
import { useNativeBridge } from "@/native/useNativeBridge";
import { applyRemote } from "@/store/store";
import DiaryGate from "@/components/DiaryGate";
import DiaryHomePage from "@/pages/Diary";
import DiaryAccessWatcher from "@/components/DiaryAccessWatcher";
import DiaryCustomizePage from "@/pages/DiaryCustomize";
import DiaryPagesPage from "@/pages/DiaryPages";
import LedgerPage from "@/pages/Ledger";
import PasswordsPage from "@/pages/Passwords";
import VaultPage from "@/pages/Vault";
import EntryDetailPage from "@/pages/EntryDetail";
import HabitFormPage from "@/pages/HabitForm";
import HomePage from "@/pages/Home";
import MedicineFormPage from "@/pages/MedicineForm";
import MedicinePage from "@/pages/Medicine";
import NewEntryPage from "@/pages/NewEntry";
import PrescriptionFormPage from "@/pages/PrescriptionForm";
import ReminderFormPage from "@/pages/ReminderForm";
import RemindersPage from "@/pages/Reminders";
import SettingsPage from "@/pages/Settings";
import WaterPage from "@/pages/Water";

function Shell() {
  useNativeBridge();
  useEffect(() => startUploader(), []);
  return (
    <>
      <LockGate>
        <SyncBanner />
        <Confetti />
        <DiaryAccessWatcher />
        <div className="mx-auto min-h-screen max-w-xl pb-28">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/diary" element={<DiaryGate><DiaryHomePage /></DiaryGate>} />
            <Route path="/diary/pages" element={<DiaryGate><DiaryPagesPage /></DiaryGate>} />
            <Route path="/diary/vault" element={<DiaryGate><VaultPage /></DiaryGate>} />
            <Route path="/diary/passwords" element={<DiaryGate><PasswordsPage /></DiaryGate>} />
            <Route path="/diary/ledger" element={<DiaryGate><LedgerPage /></DiaryGate>} />
            <Route path="/diary/customize" element={<DiaryGate><DiaryCustomizePage /></DiaryGate>} />
            <Route path="/new" element={<DiaryGate><NewEntryPage /></DiaryGate>} />
            <Route path="/entry/:id" element={<DiaryGate><EntryDetailPage /></DiaryGate>} />
            <Route path="/water" element={<WaterPage />} />
            <Route path="/medicine" element={<MedicinePage />} />
            <Route path="/medicine/new" element={<MedicineFormPage />} />
            <Route path="/medicine/:id/edit" element={<MedicineFormPage />} />
            <Route path="/prescription/new" element={<PrescriptionFormPage />} />
            <Route path="/reminders" element={<RemindersPage />} />
            <Route path="/reminders/new" element={<ReminderFormPage />} />
            <Route path="/reminders/:id/edit" element={<ReminderFormPage />} />
            <Route path="/habits/new" element={<HabitFormPage />} />
            <Route path="/habits/:id/edit" element={<HabitFormPage />} />
            <Route path="/achievements" element={<AchievementsPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
        <BottomNav />
      </LockGate>
    </>
  );
}

function Splash({ text }: { text: string }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-3">
      <div className="h-9 w-9 animate-spin rounded-full border-4 border-[var(--color-accent)]/25 border-t-[var(--color-accent)]" />
      <p className="text-sm opacity-60">{text}</p>
    </div>
  );
}

/** Keeps the in-memory data in step with Firestore while a user is logged in. */
function SyncGate({ uid, children }: { uid: string; children: ReactNode }) {
  const { ready } = useSyncStatus();
  useEffect(() => {
    const stop = startSync(uid);
    return () => {
      stop();
      applyRemote(() => emptyData()); // never leave one account's data in memory after logout
    };
  }, [uid]);
  return ready ? <>{children}</> : <Splash text="আপনার ডেটা লোড হচ্ছে…" />;
}

function AuthGate({ children }: { children: ReactNode }) {
  const auth = useAuthState();
  if (auth.status === "loading") return <Splash text="লোড হচ্ছে…" />;
  if (auth.status === "out") return <AuthScreen />;
  return (
    <SyncGate key={auth.user.uid} uid={auth.user.uid}>
      {children}
    </SyncGate>
  );
}

export default function App() {
  return (
    <HashRouter>
      <FeedbackProvider>
        <AuthGate>
          <Shell />
        </AuthGate>
      </FeedbackProvider>
    </HashRouter>
  );
}
