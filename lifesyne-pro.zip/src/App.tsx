import { useEffect, type ReactNode } from "react";
import { HashRouter, Navigate, Route, Routes } from "react-router-dom";
import AuthScreen from "@/components/AuthScreen";
import BottomNav from "@/components/BottomNav";
import { FeedbackProvider } from "@/components/Feedback";
import LockGate from "@/components/LockGate";
import SyncBanner from "@/components/SyncBanner";
import { emptyData } from "@/domain/defaults";
import { useAuthState } from "@/firebase/auth";
import { useSyncStatus } from "@/firebase/status";
import { startSync } from "@/firebase/sync";
import { useNativeBridge } from "@/native/useNativeBridge";
import { applyRemote } from "@/store/store";
import DiaryPage from "@/pages/Diary";
import EntryDetailPage from "@/pages/EntryDetail";
import HomePage from "@/pages/Home";
import MedicineFormPage from "@/pages/MedicineForm";
import MedicinePage from "@/pages/Medicine";
import NewEntryPage from "@/pages/NewEntry";
import PrescriptionFormPage from "@/pages/PrescriptionForm";
import SettingsPage from "@/pages/Settings";
import WaterPage from "@/pages/Water";

function Shell() {
  useNativeBridge();
  return (
    <>
      <LockGate>
        <SyncBanner />
        <div className="mx-auto min-h-screen max-w-xl pb-28">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/diary" element={<DiaryPage />} />
            <Route path="/new" element={<NewEntryPage />} />
            <Route path="/entry/:id" element={<EntryDetailPage />} />
            <Route path="/water" element={<WaterPage />} />
            <Route path="/medicine" element={<MedicinePage />} />
            <Route path="/medicine/new" element={<MedicineFormPage />} />
            <Route path="/medicine/:id/edit" element={<MedicineFormPage />} />
            <Route path="/prescription/new" element={<PrescriptionFormPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
        <BottomNav />
      </LockGate>
    </>
  );
}

function Splash({ text }: { text: string }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-3">
      <div className="h-9 w-9 animate-spin rounded-full border-4 border-[var(--color-accent)]/25 border-t-[var(--color-accent)]" />
      <p className="text-sm opacity-60">{text}</p>
    </div>
  );
}

/** Keeps the in-memory data in step with Firestore while a user is logged in. */
function SyncGate({ uid, children }: { uid: string; children: ReactNode }) {
  const { ready } = useSyncStatus();
  useEffect(() => {
    const stop = startSync(uid);
    return () => {
      stop();
      applyRemote(() => emptyData()); // never leave one account's data in memory after logout
    };
  }, [uid]);
  return ready ? <>{children}</> : <Splash text="আপনার ডেটা লোড হচ্ছে…" />;
}

function AuthGate({ children }: { children: ReactNode }) {
  const auth = useAuthState();
  if (auth.status === "loading") return <Splash text="লোড হচ্ছে…" />;
  if (auth.status === "out") return <AuthScreen />;
  return (
    <SyncGate key={auth.user.uid} uid={auth.user.uid}>
      {children}
    </SyncGate>
  );
}

export default function App() {
  return (
    <HashRouter>
      <FeedbackProvider>
        <AuthGate>
          <Shell />
        </AuthGate>
      </FeedbackProvider>
    </HashRouter>
  );
}
