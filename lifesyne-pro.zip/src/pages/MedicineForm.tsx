import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import MedicineFields from "@/components/MedicineFields";
import { Button, EmptyState } from "@/components/ui";
import { validateMedicine } from "@/domain/medicine";
import { newMedicine } from "@/domain/medicineDraft";
import type { Medicine } from "@/domain/types";
import { showToast } from "@/lib/toast";
import { saveMedicines } from "@/store/actions";
import { useAppData } from "@/store/store";

export default function MedicineFormPage() {
  const { id } = useParams<{ id: string }>();
  const data = useAppData();
  const navigate = useNavigate();
  const existing = id ? data.medicines.find((m) => m.id === id) : undefined;

  if (id && !existing) {
    return (
      <main className="safe-top px-4 pt-10">
        <EmptyState icon="🔍" title="ওষুধটি পাওয়া যায়নি" />
        <Button variant="soft" block onClick={() => navigate("/medicine", { replace: true })}>
          ← ওষুধের তালিকায় ফিরুন
        </Button>
      </main>
    );
  }
  return <Form key={id ?? "new"} initial={existing ?? newMedicine(data.settings)} isEdit={Boolean(existing)} />;
}

function Form({ initial, isEdit }: { initial: Medicine; isEdit: boolean }) {
  const navigate = useNavigate();
  const { settings } = useAppData();
  const [med, setMed] = useState(initial);

  const save = () => {
    const problem = validateMedicine({ ...med, name: med.name.trim() });
    if (problem) {
      showToast(problem);
      return;
    }
    saveMedicines([{ ...med, name: med.name.trim(), doctor: med.doctor.trim(), notes: med.notes.trim() }]);
    showToast(isEdit ? "✅ ওষুধ আপডেট হয়েছে" : "✅ ওষুধ যোগ হয়েছে, রিমাইন্ডার চালু");
    navigate("/medicine", { replace: true });
  };

  return (
    <main className="safe-top px-4 pb-28 pt-6">
      <header className="mb-5 flex items-center gap-2">
        <button type="button" onClick={() => (window.history.length > 1 ? navigate(-1) : navigate("/medicine"))} aria-label="ফিরে যান" className="-ml-1 rounded-full px-2 py-1 text-xl opacity-70 active:scale-90">
          ←
        </button>
        <h1 className="text-xl font-bold">{isEdit ? "ওষুধ এডিট" : "নতুন ওষুধ"} 💊</h1>
      </header>
      <MedicineFields value={med} onChange={setMed} meals={settings.meals} />
      <div className="safe-bottom fixed inset-x-0 bottom-0 z-30 border-t border-[var(--color-accent)]/20 bg-[var(--color-paper)]/95 px-4 py-3 backdrop-blur dark:bg-[var(--color-paper-dark)]/95">
        <div className="mx-auto max-w-xl">
          <Button block className="py-3.5" onClick={save}>
            💾 সংরক্ষণ করুন
          </Button>
        </div>
      </div>
    </main>
  );
}
