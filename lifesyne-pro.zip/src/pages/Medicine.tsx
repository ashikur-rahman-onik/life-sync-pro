import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import DoseRow from "@/components/DoseRow";
import { useConfirm } from "@/components/Feedback";
import PermissionBanner from "@/components/PermissionBanner";
import { useTodayDoses } from "@/components/useDoses";
import { Button, Card, EmptyState, PageHeader, Segmented } from "@/components/ui";
import { adherence, FORM_ICONS, formatDose, formatStock, logMap, RELATION_LABELS, stockInfo } from "@/domain/medicine";
import type { Medicine, Prescription } from "@/domain/types";
import { formatDateBn, formatTimeBn, toBn } from "@/lib/bn";
import { diffDays, nowMinutes } from "@/lib/date";
import { deleteMedicine, deletePrescription, markDose, setMedicineActive, undoDose } from "@/store/actions";
import { useAppData } from "@/store/store";

type Tab = "today" | "all";

export default function MedicinePage() {
  const [tab, setTab] = useState<Tab>("today");
  return (
    <main className="safe-top px-4 pt-6">
      <PageHeader title="ওষুধ 💊" />
      <PermissionBanner />
      <div className="mb-4 grid grid-cols-2 gap-2">
        <Link to="/prescription/new" className="rounded-2xl bg-[var(--color-med)] px-3 py-3 text-center text-sm font-semibold text-white shadow-md active:scale-[0.98]">
          📋 প্রেসক্রিপশন যোগ
        </Link>
        <Link to="/medicine/new" className="rounded-2xl bg-[var(--color-med)]/15 px-3 py-3 text-center text-sm font-semibold text-[var(--color-med)] active:scale-[0.98]">
          + একটি ওষুধ
        </Link>
      </div>
      <div className="mb-4">
        <Segmented
          value={tab}
          onChange={setTab}
          options={[
            { value: "today", label: "আজকের ডোজ" },
            { value: "all", label: "সব ওষুধ" },
          ]}
        />
      </div>
      {tab === "today" ? <TodayTab /> : <AllTab />}
    </main>
  );
}

function TodayTab() {
  const data = useAppData();
  const { today, items } = useTodayDoses();
  const week = adherence(data.medicines, data.doseLogs, today, 7, nowMinutes());

  if (data.medicines.length === 0) {
    return <EmptyState icon="💊" title="এখনও কোনো ওষুধ নেই" text="ডাক্তার প্রেসক্রিপশন দিলে ‘প্রেসক্রিপশন যোগ’ চেপে ওষুধের নাম আর কখন কখন খাবেন লিখে দিন। সময়মতো রিমাইন্ডার আসবে।" />;
  }

  return (
    <>
      {week.percent !== null && (
        <Card className="mb-4 flex items-center justify-between">
          <div>
            <p className="text-sm font-bold">গত ৭ দিনে নিয়ম মানা</p>
            <p className="text-xs opacity-60">
              খেয়েছেন {toBn(week.taken)}টি · মিস {toBn(week.missed)}টি
            </p>
          </div>
          <span className={`text-2xl font-bold ${week.percent >= 80 ? "text-green-600" : week.percent >= 50 ? "text-amber-600" : "text-red-500"}`}>{toBn(week.percent)}%</span>
        </Card>
      )}
      {items.length === 0 ? (
        <EmptyState icon="🌿" title="আজ কোনো ওষুধ খাওয়ার নেই" />
      ) : (
        <div className="space-y-2">
          {items.map(({ dose, status }) => (
            <DoseRow
              key={dose.key}
              dose={dose}
              status={status}
              onTake={() => markDose(dose.medicine, dose.slot, dose.date, "taken")}
              onSkip={() => markDose(dose.medicine, dose.slot, dose.date, "skipped")}
              onUndo={() => undoDose(dose.key)}
            />
          ))}
        </div>
      )}
    </>
  );
}

function courseLabel(m: Medicine, today: string): string {
  if (!m.active) return "বিরতিতে আছে";
  if (m.startDate > today) return `${formatDateBn(m.startDate)} থেকে শুরু`;
  if (m.endDate === null) return "চলছে (ডাক্তার যতদিন বলেছেন)";
  if (m.endDate < today) return "কোর্স শেষ";
  return `আর ${toBn(diffDays(today, m.endDate) + 1)} দিন বাকি`;
}

function AllTab() {
  const data = useAppData();
  const confirm = useConfirm();
  const { today } = useTodayDoses();
  const logs = useMemo(() => logMap(data.doseLogs), [data.doseLogs]);

  const groups: { prescription: Prescription | null; meds: Medicine[] }[] = [
    ...[...data.prescriptions]
      .sort((a, b) => b.date.localeCompare(a.date))
      .map((p) => ({ prescription: p, meds: data.medicines.filter((m) => m.prescriptionId === p.id) }))
      .filter((g) => g.meds.length > 0),
    { prescription: null, meds: data.medicines.filter((m) => !m.prescriptionId || !data.prescriptions.some((p) => p.id === m.prescriptionId)) },
  ].filter((g) => g.meds.length > 0);

  if (groups.length === 0) return <EmptyState icon="💊" title="এখনও কোনো ওষুধ নেই" />;

  const removeMed = async (m: Medicine) => {
    if (await confirm({ title: `"${m.name}" মুছবেন?`, message: "এর রিমাইন্ডার বন্ধ হয়ে যাবে।", confirmText: "মুছুন", danger: true })) deleteMedicine(m.id);
  };
  const removeRx = async (p: Prescription) => {
    if (await confirm({ title: "পুরো প্রেসক্রিপশন মুছবেন?", message: "এর সব ওষুধ ও রিমাইন্ডার মুছে যাবে।", confirmText: "মুছুন", danger: true })) deletePrescription(p.id);
  };

  return (
    <div className="space-y-6">
      {groups.map((g) => (
        <section key={g.prescription?.id ?? "single"}>
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-sm font-bold">
              {g.prescription ? `📋 ${g.prescription.doctor ? `ডা. ${g.prescription.doctor}` : "প্রেসক্রিপশন"} · ${formatDateBn(g.prescription.date)}` : "অন্যান্য ওষুধ"}
            </h2>
            {g.prescription && (
              <button type="button" onClick={() => void removeRx(g.prescription!)} className="text-xs font-medium text-red-500">
                মুছুন
              </button>
            )}
          </div>
          {g.prescription?.note && <p className="mb-2 text-xs opacity-60">{g.prescription.note}</p>}
          <div className="space-y-3">
            {g.meds.map((m) => {
              const info = stockInfo(m, today, logs);
              return (
                <Card key={m.id} className={m.active ? "" : "opacity-60"}>
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-bold">
                        {FORM_ICONS[m.form]} {m.name}
                      </p>
                      <p className="mt-0.5 text-xs opacity-70">
                        {m.slots.map((s) => `${formatTimeBn(s.time)} (${formatDose(s.qty, m.form)})`).join(" · ")}
                      </p>
                      <p className="mt-0.5 text-xs opacity-60">
                        {m.relation !== "any" && `${RELATION_LABELS[m.relation]} · `}
                        {courseLabel(m, today)}
                      </p>
                      {m.stock !== null && <p className="mt-0.5 text-xs opacity-60">স্টক: {formatStock(m.stock, m.form)}</p>}
                      {info.warning && (
                        <p className="mt-1 text-xs font-medium text-amber-600">
                          ⚠️ {info.warning === "short" ? `কোর্স শেষ করতে আরও ${toBn(Math.ceil(info.missing))} লাগবে` : `আর প্রায় ${toBn(info.daysLeft ?? 0)} দিনের ওষুধ আছে`}
                        </p>
                      )}
                      {m.notes && <p className="mt-1 text-xs italic opacity-60">{m.notes}</p>}
                    </div>
                  </div>
                  <div className="mt-3 flex gap-2">
                    <Link to={`/medicine/${m.id}/edit`} className="rounded-full bg-black/5 px-3 py-1.5 text-xs font-semibold dark:bg-white/10">
                      ✏️ এডিট
                    </Link>
                    <Button variant="ghost" className="!rounded-full !px-3 !py-1.5 !text-xs" onClick={() => setMedicineActive(m.id, !m.active)}>
                      {m.active ? "⏸ বিরতি" : "▶️ চালু করুন"}
                    </Button>
                    <Button variant="danger" className="!rounded-full !px-3 !py-1.5 !text-xs" onClick={() => void removeMed(m)}>
                      🗑️
                    </Button>
                  </div>
                </Card>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
}
