import { useMemo, useState } from "react";
import { useConfirm } from "@/components/Feedback";
import { Button, Card, Chip, EmptyState, Field, IconPicker, inputClass, Modal, PageHeader, ProgressBar, Segmented } from "@/components/ui";
import { categoryTotals, formatTaka, groupByDay, inMonth, parseAmount, summarize } from "@/domain/ledger";
import type { LedgerCategory, LedgerEntry } from "@/domain/types";
import { formatDateBn, monthLabelBn, toBn } from "@/lib/bn";
import { pad, todayKey } from "@/lib/date";
import { uid } from "@/lib/id";
import { showToast } from "@/lib/toast";
import { deleteLedgerCategory, deleteLedgerEntry, saveLedgerCategory, saveLedgerEntry } from "@/store/actions";
import { useAppData } from "@/store/store";

type Kind = "income" | "expense";

export default function LedgerPage() {
  const { ledger, settings } = useAppData();
  const cats = settings.ledgerCategories;
  const now = new Date();
  const [cursor, setCursor] = useState({ year: now.getFullYear(), month: now.getMonth() + 1 });
  const [editing, setEditing] = useState<LedgerEntry | "new" | null>(null);
  const [catsOpen, setCatsOpen] = useState(false);

  const monthKey = `${cursor.year}-${pad(cursor.month)}`;
  const monthEntries = useMemo(() => inMonth(ledger, monthKey), [ledger, monthKey]);
  const month = summarize(monthEntries);
  const all = useMemo(() => summarize(ledger), [ledger]);
  const days = useMemo(() => groupByDay(monthEntries), [monthEntries]);
  const spending = useMemo(() => categoryTotals(monthEntries, "expense", cats), [monthEntries, cats]);

  const move = (delta: number) =>
    setCursor((p) => {
      const idx = p.year * 12 + (p.month - 1) + delta;
      return { year: Math.floor(idx / 12), month: (idx % 12) + 1 };
    });

  return (
    <main className="safe-top px-4 pb-6 pt-6">
      <PageHeader title="হিসাব-নিকাশ 💰" back right={<Button className="!px-3 !py-2" onClick={() => setEditing("new")}>+ নতুন</Button>} />

      <Card className="mb-4 flex items-center justify-between !py-3">
        <button type="button" onClick={() => move(-1)} aria-label="আগের মাস" className="px-3 text-lg active:scale-90">
          ‹
        </button>
        <span className="font-semibold">{monthLabelBn(cursor.year, cursor.month)}</span>
        <button type="button" onClick={() => move(1)} aria-label="পরের মাস" className="px-3 text-lg active:scale-90">
          ›
        </button>
      </Card>

      <div className="mb-3 grid grid-cols-3 gap-2.5 text-center">
        <div className="rounded-2xl bg-green-500/10 p-3">
          <p className="text-[10px] opacity-70">আয়</p>
          <p className="text-sm font-bold text-green-600">{formatTaka(month.income)}</p>
        </div>
        <div className="rounded-2xl bg-red-500/10 p-3">
          <p className="text-[10px] opacity-70">খরচ</p>
          <p className="text-sm font-bold text-red-500">{formatTaka(month.expense)}</p>
        </div>
        <div className="rounded-2xl bg-[var(--color-accent)]/10 p-3">
          <p className="text-[10px] opacity-70">এ মাসের উদ্বৃত্ত</p>
          <p className="text-sm font-bold">{formatTaka(month.balance)}</p>
        </div>
      </div>
      <p className="mb-4 text-center text-xs opacity-60">
        মোট জমা (সব সময়ের আয় − খরচ): <b>{formatTaka(all.balance)}</b>
      </p>

      {spending.length > 0 && (
        <Card className="mb-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-bold">কোথায় কত খরচ</h2>
            <button type="button" onClick={() => setCatsOpen(true)} className="text-xs font-semibold text-[var(--color-accent)]">
              ⚙️ ক্যাটাগরি
            </button>
          </div>
          <div className="space-y-2.5">
            {spending.map((s) => (
              <div key={s.id}>
                <div className="mb-1 flex justify-between text-xs">
                  <span>
                    {s.category?.icon ?? "📌"} {s.category?.name ?? "অন্যান্য"}
                  </span>
                  <span className="font-semibold">
                    {formatTaka(s.total)} ({toBn(Math.round((s.total / month.expense) * 100))}%)
                  </span>
                </div>
                <ProgressBar percent={(s.total / spending[0].total) * 100} color="#ef4444" />
              </div>
            ))}
          </div>
        </Card>
      )}

      {days.length === 0 ? (
        <EmptyState icon="💰" title="এ মাসে কোনো হিসাব নেই" text="আয় বা খরচ হলে ‘+ নতুন’ চেপে লিখে রাখুন — দিন ও মাসের হিসাব নিজে নিজে মিলে যাবে।" />
      ) : (
        <div className="space-y-5">
          {days.map((d) => (
            <section key={d.date}>
              <div className="mb-1.5 flex items-center justify-between text-xs">
                <span className="font-semibold opacity-70">{formatDateBn(d.date, { weekday: true })}</span>
                <span className="opacity-60">
                  {d.summary.income > 0 && <span className="text-green-600">+{formatTaka(d.summary.income)} </span>}
                  {d.summary.expense > 0 && <span className="text-red-500">−{formatTaka(d.summary.expense)}</span>}
                </span>
              </div>
              <div className="space-y-2">
                {d.entries.map((e) => {
                  const c = cats.find((x) => x.id === e.categoryId);
                  return (
                    <button key={e.id} type="button" onClick={() => setEditing(e)} className="flex w-full items-center gap-3 rounded-2xl bg-white/70 px-3 py-2.5 text-left shadow-sm active:scale-[0.99] dark:bg-white/5">
                      <span className="text-xl">{c?.icon ?? "📌"}</span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-semibold">{c?.name ?? "অন্যান্য"}</span>
                        {e.note && <span className="block truncate text-[11px] opacity-60">{e.note}</span>}
                      </span>
                      <span className={`text-sm font-bold ${e.type === "income" ? "text-green-600" : "text-red-500"}`}>
                        {e.type === "income" ? "+" : "−"}
                        {formatTaka(e.amount)}
                      </span>
                    </button>
                  );
                })}
              </div>
            </section>
          ))}
        </div>
      )}

      <Modal open={editing !== null} onClose={() => setEditing(null)} title={editing === "new" ? "নতুন হিসাব" : "হিসাব এডিট"}>
        {editing !== null && <LedgerForm key={editing === "new" ? "new" : editing.id} entry={editing === "new" ? null : editing} cats={cats} onClose={() => setEditing(null)} />}
      </Modal>
      <Modal open={catsOpen} onClose={() => setCatsOpen(false)} title="ক্যাটাগরি">
        <CategoryManager cats={cats} />
      </Modal>
    </main>
  );
}

function LedgerForm({ entry, cats, onClose }: { entry: LedgerEntry | null; cats: LedgerCategory[]; onClose: () => void }) {
  const confirm = useConfirm();
  const [type, setType] = useState<Kind>(entry?.type ?? "expense");
  const [amount, setAmount] = useState(entry ? String(entry.amount) : "");
  const [categoryId, setCategoryId] = useState(entry?.categoryId ?? "");
  const [date, setDate] = useState(entry?.date ?? todayKey());
  const [note, setNote] = useState(entry?.note ?? "");

  const options = cats.filter((c) => c.kind === type);
  const chosen = options.some((c) => c.id === categoryId) ? categoryId : (options[0]?.id ?? "");

  const save = (another: boolean) => {
    const value = parseAmount(amount);
    if (value === null) return showToast("সঠিক টাকার পরিমাণ লিখুন");
    saveLedgerEntry(entry?.id ?? null, { date: date || todayKey(), type, amount: value, categoryId: chosen, note: note.trim() });
    showToast(type === "income" ? "✅ আয় লেখা হয়েছে" : "✅ খরচ লেখা হয়েছে");
    if (another) {
      setAmount("");
      setNote("");
    } else onClose();
  };

  const remove = async () => {
    if (entry && (await confirm({ title: "এই হিসাব মুছবেন?", confirmText: "মুছুন", danger: true }))) {
      deleteLedgerEntry(entry.id);
      onClose();
    }
  };

  return (
    <div className="space-y-4 pb-2">
      <Segmented<Kind>
        value={type}
        onChange={setType}
        options={[
          { value: "expense", label: "➖ খরচ" },
          { value: "income", label: "➕ আয়" },
        ]}
      />
      <Field label="টাকা (৳)">
        <input className={`${inputClass} text-lg font-bold`} inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="০" autoFocus />
      </Field>
      <div className="flex flex-wrap gap-2">
        {options.map((c) => (
          <Chip key={c.id} active={chosen === c.id} onClick={() => setCategoryId(c.id)}>
            {c.icon} {c.name}
          </Chip>
        ))}
      </div>
      <Field label="তারিখ">
        <input type="date" className={inputClass} value={date} max={todayKey()} onChange={(e) => setDate(e.target.value)} />
      </Field>
      <Field label="নোট (ঐচ্ছিক)">
        <input className={inputClass} value={note} onChange={(e) => setNote(e.target.value)} placeholder="যেমন: বাজার, রিচার্জ" />
      </Field>
      <div className="flex gap-2 pt-1">
        {entry && (
          <Button variant="danger" onClick={() => void remove()}>
            🗑️
          </Button>
        )}
        <Button block onClick={() => save(false)}>
          💾 সংরক্ষণ
        </Button>
        {!entry && (
          <Button variant="soft" onClick={() => save(true)}>
            + আরেকটি
          </Button>
        )}
      </div>
    </div>
  );
}

function CategoryManager({ cats }: { cats: LedgerCategory[] }) {
  const confirm = useConfirm();
  const [name, setName] = useState("");
  const [icon, setIcon] = useState("📌");
  const [kind, setKind] = useState<Kind>("expense");

  const add = () => {
    if (!name.trim()) return showToast("নাম লিখুন");
    saveLedgerCategory({ id: uid(), name: name.trim(), icon: icon || "📌", kind });
    setName("");
  };
  const remove = async (c: LedgerCategory) => {
    if (await confirm({ title: `"${c.name}" মুছবেন?`, message: "এর হিসাবগুলো একই ধরনের প্রথম ক্যাটাগরিতে চলে যাবে।", confirmText: "মুছুন", danger: true })) deleteLedgerCategory(c.id);
  };

  return (
    <div className="space-y-4 pb-2">
      {(["expense", "income"] as const).map((k) => (
        <div key={k}>
          <p className="mb-1.5 text-xs font-semibold opacity-70">{k === "expense" ? "খরচের ক্যাটাগরি" : "আয়ের ক্যাটাগরি"}</p>
          <div className="space-y-1.5">
            {cats
              .filter((c) => c.kind === k)
              .map((c) => (
                <div key={c.id} className="flex items-center justify-between rounded-xl bg-white/60 px-3 py-2 text-sm dark:bg-white/5">
                  <span>
                    {c.icon} {c.name}
                  </span>
                  <button type="button" className="text-xs font-semibold text-red-500" onClick={() => void remove(c)}>
                    মুছুন
                  </button>
                </div>
              ))}
          </div>
        </div>
      ))}
      <div className="space-y-2 rounded-2xl border border-dashed border-[var(--color-accent)]/30 p-3">
        <Segmented<Kind>
          value={kind}
          onChange={setKind}
          options={[
            { value: "expense", label: "খরচ" },
            { value: "income", label: "আয়" },
          ]}
        />
        <input className={inputClass} value={name} onChange={(e) => setName(e.target.value.slice(0, 30))} placeholder="নতুন ক্যাটাগরির নাম" />
        <IconPicker value={icon} onChange={setIcon} />
        <Button variant="soft" block onClick={add}>
          + যোগ করুন
        </Button>
      </div>
    </div>
  );
}
