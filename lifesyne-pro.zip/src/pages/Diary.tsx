import { useMemo } from "react";
import { Link } from "react-router-dom";
import DiaryCover from "@/components/DiaryCover";
import EntryCard from "@/components/EntryCard";
import { Card } from "@/components/ui";
import { diaryStats, onThisDay, pageNumbers, sortEntries } from "@/domain/diary";
import { promptOfTheDay } from "@/domain/prompts";
import { formatDateBn, toBn } from "@/lib/bn";
import { todayKey } from "@/lib/date";
import { closeDiary } from "@/lib/diaryLock";
import { useAppData } from "@/store/store";

/** Inside the opened diary: the table of contents. */
export default function DiaryHomePage() {
  const data = useAppData();
  const { diary } = data.settings;
  const today = todayKey();

  const stats = diaryStats(data.entries, today);
  const recent = useMemo(() => sortEntries(data.entries).slice(0, 3), [data.entries]);
  const numbers = useMemo(() => pageNumbers(data.entries), [data.entries]);
  const memories = useMemo(() => onThisDay(data.entries, today), [data.entries, today]);
  const wroteToday = data.entries.some((e) => e.entryDate === today);

  const sections = [
    { to: "/new", icon: "✍️", title: "নতুন পাতা", sub: wroteToday ? "আরেকটা লিখুন" : "আজকের পাতা লিখুন" },
    { to: "/diary/pages", icon: "📖", title: "সব পাতা", sub: `${toBn(data.entries.length)}টি পাতা` },
    { to: "/diary/vault", icon: "🗂️", title: "ভল্ট", sub: `${toBn(data.vault.length)}টি ফাইল/নোট` },
    { to: "/diary/passwords", icon: "🔑", title: "পাসওয়ার্ড", sub: `${toBn(data.passwords.length)}টি সংরক্ষিত` },
    { to: "/diary/ledger", icon: "💰", title: "হিসাব-নিকাশ", sub: `${toBn(data.ledger.length)}টি এন্ট্রি` },
    { to: "/diary/customize", icon: "🎨", title: "কাস্টমাইজ", sub: "কভার, কাগজ, লক" },
  ];

  return (
    <main className="safe-top px-4 pb-6 pt-6">
      <header className="mb-5 flex items-center gap-4">
        <div className="shrink-0">
          <DiaryCover diary={diary} width={78} />
        </div>
        <div className="min-w-0 flex-1">
          <h1 className="font-diary-script truncate text-2xl">{diary.title}</h1>
          <p className="text-xs opacity-60">{diary.subtitle || "ব্যক্তিগত ডায়েরি"}</p>
          <p className="mt-1 text-[11px] opacity-60">
            🔥 {toBn(stats.streak)} দিন ধারাবাহিক · {toBn(stats.total)}টি পাতা
          </p>
          {diary.lock && (
            <button type="button" onClick={closeDiary} className="mt-2 rounded-full bg-black/5 px-3 py-1 text-[11px] font-semibold dark:bg-white/10">
              🔒 এখনই লক করুন
            </button>
          )}
        </div>
      </header>

      {recent.length > 0 && (
        <Link to={`/entry/${recent[0].id}`} className="mb-4 flex items-center justify-center gap-2 rounded-2xl bg-[var(--color-accent)] px-4 py-3.5 text-sm font-semibold text-white shadow-md shadow-[var(--color-accent)]/30 active:scale-[0.98]">
          📖 ডায়েরি পড়ুন <span className="text-xs font-normal opacity-80">(পাতা উল্টে উল্টে)</span>
        </Link>
      )}

      <div className="mb-5 grid grid-cols-2 gap-3">
        {sections.map((s) => (
          <Link key={s.to} to={s.to} className="rounded-2xl border border-[var(--color-accent)]/15 bg-white/70 p-4 shadow-sm transition active:scale-[0.97] dark:bg-white/5">
            <div className="text-2xl">{s.icon}</div>
            <p className="mt-1.5 text-sm font-bold">{s.title}</p>
            <p className="text-[11px] opacity-60">{s.sub}</p>
          </Link>
        ))}
      </div>

      {!wroteToday && (
        <Link to="/new" className="mb-5 block rounded-2xl bg-[var(--color-accent)]/10 px-4 py-3 text-sm">
          <span className="font-semibold">💡 আজকের প্রশ্ন:</span> {promptOfTheDay(today)}
        </Link>
      )}

      {memories.length > 0 && (
        <Card className="mb-5">
          <h2 className="mb-2 text-sm font-bold">🕰️ এই দিনে আগে…</h2>
          <div className="space-y-2">
            {memories.slice(0, 2).map(({ entry, yearsAgo }) => (
              <div key={entry.id}>
                <p className="mb-1 text-[11px] opacity-60">
                  {toBn(yearsAgo)} বছর আগে · {formatDateBn(entry.entryDate)}
                </p>
                <EntryCard entry={entry} pageNumber={numbers.get(entry.id)} />
              </div>
            ))}
          </div>
        </Card>
      )}

      <div className="mb-2 flex items-center justify-between">
        <h2 className="font-bold">সাম্প্রতিক পাতা</h2>
        <Link to="/diary/pages" className="text-xs font-semibold text-[var(--color-accent)]">
          সব দেখুন
        </Link>
      </div>
      {recent.length === 0 ? (
        <p className="py-6 text-center text-sm opacity-60">এখনও কোনো পাতা লেখা হয়নি — ‘নতুন পাতা’ চেপে শুরু করুন ✍️</p>
      ) : (
        <div className="space-y-3">
          {recent.map((e) => (
            <EntryCard key={e.id} entry={e} pageNumber={numbers.get(e.id)} />
          ))}
        </div>
      )}
    </main>
  );
}
