import { Card, PageHeader, ProgressBar } from "@/components/ui";
import { computeBadges } from "@/domain/achievements";
import { toBn } from "@/lib/bn";
import { todayKey } from "@/lib/date";
import { useAppData } from "@/store/store";

export default function AchievementsPage() {
  const data = useAppData();
  const badges = computeBadges(data, todayKey());
  const earned = badges.filter((b) => b.progress >= b.target).length;

  return (
    <main className="safe-top px-4 pt-6">
      <PageHeader title="ব্যাজ ও অর্জন 🏅" back />
      <p className="mb-4 text-sm opacity-70">
        আপনি পেয়েছেন {toBn(earned)}/{toBn(badges.length)}টি ব্যাজ
      </p>
      <div className="grid grid-cols-2 gap-3">
        {badges.map((b) => {
          const done = b.progress >= b.target;
          return (
            <Card key={b.id} className={done ? "ring-2 ring-[var(--color-accent)]/60" : "opacity-80"}>
              <div className={`text-3xl ${done ? "" : "grayscale"}`}>{b.icon}</div>
              <p className="mt-1 text-sm font-bold">{b.title}</p>
              <p className="mb-2 min-h-8 text-[11px] opacity-60">{b.description}</p>
              <ProgressBar percent={(b.progress / b.target) * 100} color={done ? "#22c55e" : "var(--color-accent)"} />
              <p className="mt-1 text-[10px] opacity-60">
                {toBn(b.progress)}/{toBn(b.target)} {done ? "✅" : ""}
              </p>
            </Card>
          );
        })}
      </div>
    </main>
  );
}
