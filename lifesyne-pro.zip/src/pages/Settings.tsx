import { useEffect, useRef, useState, type ChangeEvent } from "react";
import { useConfirm } from "@/components/Feedback";
import { Button, Card, Field, IconPicker, Modal, PageHeader, Segmented, SelectField, StylePicker, Toggle, inputClass } from "@/components/ui";
import { formatTimeBn, toBn } from "@/lib/bn";
import { getAutoLockSec, hasPin, removePin, setAutoLockSec, setPin as savePin } from "@/lib/security";
import { ACCENTS, getAccent, getTextSize, setAccent, setTextSize, setThemePref, TEXT_SIZES, useThemePref, type ThemePref } from "@/lib/theme";
import { showToast } from "@/lib/toast";
import { auth } from "@/firebase/client";
import { signOutUser } from "@/firebase/auth";
import { FIRESTORE_RULES } from "@/firebase/rules";
import { useSyncStatus } from "@/firebase/status";
import { exportBackup, parseBackup } from "@/native/backup";
import { isNative } from "@/native/platform";
import { getExactAlarmStatus, getNotificationPermission, openExactAlarmSettings, requestNotificationPermission, sendTestNotification, syncReminders, type PermissionStatus } from "@/native/notifications";
import { checkForUpdate, getAppVersion, startUpdate, updatesAvailable, useUpdater, type AppVersion } from "@/native/updater";
import { deleteCategory, saveCategory, updateSettings } from "@/store/actions";
import { uid } from "@/lib/id";
import type { NotifyStyle } from "@/domain/types";
import { getState, replaceAll, setState, useAppData } from "@/store/store";
import { normalizeEntry } from "@/store/normalize";

const AUTO_LOCK_OPTIONS = [
  { value: 0, label: "সাথে সাথে" },
  { value: 60, label: "১ মিনিট" },
  { value: 300, label: "৫ মিনিট" },
  { value: -1, label: "কখনো না" },
];

export default function SettingsPage() {
  const data = useAppData();
  const { settings } = data;
  return (
    <main className="safe-top px-4 pb-8 pt-6">
      <PageHeader title="সেটিংস ⚙️" back />
      <div className="space-y-5">
        <AccountCard />
        <ProfileCard />
        <Card className="space-y-4">
          <h2 className="font-bold">⏰ রিমাইন্ডার চালু/বন্ধ</h2>
          <Toggle checked={settings.medRemindersOn} onChange={(v) => updateSettings((s) => ({ ...s, medRemindersOn: v }))} label="ওষুধের রিমাইন্ডার" />
          <Toggle checked={settings.water.remindersOn} onChange={(v) => updateSettings((s) => ({ ...s, water: { ...s.water, remindersOn: v } }))} label="পানির রিমাইন্ডার" description="সময় ও ধরন ঠিক করুন: স্বাস্থ্য → পানি → ⚙️" />
          <Toggle checked={settings.diaryReminder.on} onChange={(v) => updateSettings((s) => ({ ...s, diaryReminder: { ...s.diaryReminder, on: v } }))} label="ডায়েরি লেখার রিমাইন্ডার" description={settings.diaryReminder.on ? `প্রতিদিন ${formatTimeBn(settings.diaryReminder.time)}` : undefined} />
          {settings.diaryReminder.on && (
            <Field label="ডায়েরি লেখার সময়">
              <input type="time" className={inputClass} value={settings.diaryReminder.time} onChange={(e) => e.target.value && updateSettings((s) => ({ ...s, diaryReminder: { ...s.diaryReminder, time: e.target.value } }))} />
            </Field>
          )}
          <MealTimes />
          <NotificationHealth />
        </Card>
        <NotifyCard />
        <CategoriesCard />
        <AppearanceCard />
        <PinCard />
        <BackupCard />
        <UpdateCard />
        <p className="pb-4 text-center text-[11px] opacity-40">LifeSyne Pro</p>
      </div>
    </main>
  );
}

function AccountCard() {
  const confirm = useConfirm();
  const status = useSyncStatus();
  const [showRules, setShowRules] = useState(false);

  const logout = async () => {
    const ok = await confirm({
      title: "লগআউট করবেন?",
      message: "ডেটা আপনার অ্যাকাউন্টে নিরাপদ থাকবে। এই ফোনের রিমাইন্ডার ও পিন বন্ধ হবে। আবার লগইন করলে সব ফিরে আসবে।",
      confirmText: "লগআউট",
      danger: true,
    });
    if (ok) await signOutUser();
  };

  const copyRules = async () => {
    try {
      await navigator.clipboard.writeText(FIRESTORE_RULES);
      showToast("✅ Rules কপি হয়েছে");
    } catch {
      showToast("কপি করা যায়নি — লেখাটা চেপে ধরে কপি করুন");
    }
  };

  const text =
    status.error === "permission"
      ? "❌ Firestore Rules সেট করা নেই"
      : status.error === "other"
        ? "⚠️ সিঙ্কে সমস্যা"
        : status.pending
          ? "⏳ কিছু ডেটা অনলাইনে এলে সিঙ্ক হবে"
          : status.fromCache
            ? "📴 অফলাইন (ফোনের ডেটা দেখাচ্ছে)"
            : "✅ সব ডেটা ক্লাউডে সিঙ্ক হয়েছে";

  return (
    <Card>
      <h2 className="mb-1 font-bold">☁️ অ্যাকাউন্ট ও ক্লাউড সিঙ্ক</h2>
      <p className="text-sm">{auth.currentUser?.email ?? "—"}</p>
      <p className="mt-1 text-xs opacity-70">{text}</p>
      <p className="mt-1 text-[11px] opacity-50">সব ডেটা আপনার Firebase অ্যাকাউন্টে জমা হয়। ইন্টারনেট না থাকলেও অ্যাপ চলে।</p>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <Button variant="ghost" onClick={() => setShowRules((v) => !v)}>
          🔐 Firestore Rules
        </Button>
        <Button variant="danger" onClick={() => void logout()}>
          লগআউট
        </Button>
      </div>
      {showRules && (
        <div className="mt-3">
          <p className="mb-2 text-[11px] opacity-60">Firebase Console → Firestore Database → Rules ট্যাবে এটি পেস্ট করে Publish করুন। এতে প্রত্যেকে শুধু নিজের ডেটা দেখতে পায়।</p>
          <pre className="overflow-x-auto rounded-xl bg-black/5 p-3 text-[11px] dark:bg-white/10">{FIRESTORE_RULES}</pre>
          <Button variant="soft" block className="mt-2" onClick={() => void copyRules()}>
            📋 কপি করুন
          </Button>
        </div>
      )}
    </Card>
  );
}

function ProfileCard() {
  const { settings } = useAppData();
  const [name, setName] = useState(settings.profile.name);
  return (
    <Card>
      <h2 className="mb-3 font-bold">👤 আমার নাম</h2>
      <input className={inputClass} value={name} maxLength={60} placeholder="হোম স্ক্রিনে শুভেচ্ছায় দেখাবে" onChange={(e) => { setName(e.target.value); updateSettings((s) => ({ ...s, profile: { ...s.profile, name: e.target.value.trim() } })); }} />
    </Card>
  );
}

function MealTimes() {
  const { meals } = useAppData().settings;
  const rows = [
    { key: "breakfast", label: "সকালের নাস্তা" },
    { key: "lunch", label: "দুপুরের খাবার" },
    { key: "dinner", label: "রাতের খাবার" },
    { key: "bed", label: "ঘুমানোর সময়" },
  ] as const;
  return (
    <div>
      <h3 className="mb-1 text-sm font-semibold">🍽️ খাবারের সময়</h3>
      <p className="mb-2 text-[11px] opacity-60">ওষুধের ‘খাবারের আগে/পরে’ সময় এখান থেকে হিসাব হয়। (নতুন ওষুধে প্রযোজ্য)</p>
      <div className="grid grid-cols-2 gap-3">
        {rows.map((r) => (
          <Field key={r.key} label={r.label}>
            <input type="time" className={inputClass} value={meals[r.key]} onChange={(e) => e.target.value && updateSettings((s) => ({ ...s, meals: { ...s.meals, [r.key]: e.target.value } }))} />
          </Field>
        ))}
      </div>
    </div>
  );
}

function NotificationHealth() {
  const [perm, setPerm] = useState<PermissionStatus>("unsupported");
  const [exact, setExact] = useState<PermissionStatus>("unsupported");
  const [count, setCount] = useState<number | null>(null);

  const refresh = async () => {
    setPerm(await getNotificationPermission());
    setExact(await getExactAlarmStatus());
  };
  useEffect(() => {
    void refresh();
  }, []);

  if (!isNative()) return <p className="text-[11px] opacity-60">রিমাইন্ডার শুধু ইনস্টল করা অ্যাপে কাজ করে।</p>;

  return (
    <div className="space-y-3 rounded-2xl bg-black/[0.03] p-3 text-xs dark:bg-white/5">
      <p>
        নোটিফিকেশন: <b>{perm === "granted" ? "✅ চালু" : "❌ বন্ধ"}</b>
        {perm !== "granted" && (
          <button type="button" className="ml-2 font-semibold text-[var(--color-accent)]" onClick={() => void requestNotificationPermission().then(refresh)}>
            চালু করুন
          </button>
        )}
      </p>
      {exact === "denied" || exact === "prompt" ? (
        <p>
          সঠিক সময়ে অ্যালার্ম: <b>❌ বন্ধ</b> (রিমাইন্ডার কয়েক মিনিট দেরিতে আসতে পারে){" "}
          <button type="button" className="font-semibold text-[var(--color-accent)]" onClick={() => void openExactAlarmSettings()}>
            চালু করুন
          </button>
        </p>
      ) : (
        <p>
          সঠিক সময়ে অ্যালার্ম: <b>✅ চালু</b>
        </p>
      )}
      <Button
        variant="soft"
        block
        onClick={() =>
          void syncReminders(getState(), true).then((n) => {
            setCount(n);
            showToast(`✅ ${toBn(n)}টি রিমাইন্ডার সেট করা আছে`);
          })
        }
      >
        🔄 রিমাইন্ডার আবার সেট করুন{count !== null ? ` (${toBn(count)}টি)` : ""}
      </Button>
      <p className="leading-relaxed opacity-70">
        💡 Xiaomi/Redmi, Realme, Oppo, Vivo, Infinix, Tecno ও Samsung ফোনে রিমাইন্ডার ঠিকমতো পেতে: ফোনের Settings → Apps → LifeSyne Pro → Battery → <b>Unrestricted / No restrictions</b> দিন এবং <b>Autostart</b> চালু করুন।
      </p>
    </div>
  );
}

function AppearanceCard() {
  const pref = useThemePref();
  const settings = useAppData().settings;
  const [accent, setAccentState] = useState(getAccent());
  const [size, setSize] = useState(getTextSize());
  return (
    <Card className="space-y-4">
      <h2 className="font-bold">🎨 চেহারা</h2>
      <Segmented<ThemePref>
        value={pref}
        onChange={setThemePref}
        options={[
          { value: "light", label: "☀️ লাইট" },
          { value: "dark", label: "🌙 ডার্ক" },
          { value: "system", label: "📱 ফোন অনুযায়ী" },
        ]}
      />
      <div>
        <p className="mb-2 text-xs font-semibold opacity-70">মূল রং</p>
        <div className="flex gap-3">
          {ACCENTS.map((a) => (
            <button
              key={a.value}
              type="button"
              aria-label={a.label}
              onClick={() => {
                setAccent(a.value);
                setAccentState(a.value);
              }}
              className={`h-9 w-9 rounded-full ${accent === a.value ? "ring-2 ring-offset-2 ring-[var(--color-ink)] dark:ring-white" : ""}`}
              style={{ backgroundColor: a.value }}
            />
          ))}
        </div>
      </div>
      <div>
        <p className="mb-2 text-xs font-semibold opacity-70">লেখার সাইজ</p>
        <Segmented
          value={String(size)}
          onChange={(v) => {
            setTextSize(Number(v));
            setSize(Number(v));
          }}
          options={TEXT_SIZES.map((t) => ({ value: String(t.value), label: t.label }))}
        />
      </div>
      <Toggle checked={settings.showQuotes} onChange={(v) => updateSettings((s) => ({ ...s, showQuotes: v }))} label="হোমে আজকের উক্তি দেখান" />
    </Card>
  );
}

const SNOOZE_OPTIONS = [5, 10, 15, 20, 30].map((v) => ({ value: v, label: `${toBn(v)} মিনিট` }));
const EARLY_OPTIONS = [{ value: 0, label: "লাগবে না" }, ...[5, 10, 15, 30].map((v) => ({ value: v, label: `${toBn(v)} মিনিট আগে` }))];
const FOLLOW_OPTIONS = [{ value: 0, label: "বন্ধ" }, ...[1, 2, 3, 5].map((v) => ({ value: v, label: `${toBn(v)} বার` }))];

function NotifyCard() {
  const { notify } = useAppData().settings;
  const patch = (p: Partial<typeof notify>) => updateSettings((s) => ({ ...s, notify: { ...s.notify, ...p } }));
  const test = (style: NotifyStyle) =>
    void sendTestNotification(style).then((ok) => showToast(ok ? "৩ সেকেন্ড পরে নোটিফিকেশন আসবে…" : "আগে নোটিফিকেশনের অনুমতি দিন (অ্যাপ ইনস্টল করা থাকতে হবে)"));

  const rows: { label: string; key: "medStyle" | "waterStyle" | "diaryStyle" | "reminderStyle" }[] = [
    { label: "💊 ওষুধ", key: "medStyle" },
    { label: "💧 পানি", key: "waterStyle" },
    { label: "📝 ডায়েরি", key: "diaryStyle" },
    { label: "⏰ নতুন রিমাইন্ডার/অভ্যাসের ডিফল্ট", key: "reminderStyle" },
  ];

  return (
    <Card className="space-y-4">
      <div>
        <h2 className="font-bold">🔔 নোটিফিকেশন ও অ্যালার্ম</h2>
        <p className="mt-1 text-[11px] opacity-60">কোনটার জন্য কেমন শব্দ হবে বেছে নিন। ‘অ্যালার্ম’ হলো প্রায় ২৮ সেকেন্ডের জোরালো সুর — জরুরি কাজের জন্য। প্রতিটি রিমাইন্ডারের নিজস্ব ধরনও আলাদা করে দেওয়া যায়।</p>
      </div>
      {rows.map((r) => (
        <div key={r.key}>
          <p className="mb-1.5 text-xs font-semibold opacity-70">{r.label}</p>
          <StylePicker value={notify[r.key]} onChange={(v) => patch({ [r.key]: v })} onTest={test} />
        </div>
      ))}
      <div className="grid grid-cols-2 gap-3">
        <Field label="ওষুধে ‘পরে মনে করান’">
          <SelectField value={notify.medSnoozeMin} onChange={(medSnoozeMin) => patch({ medSnoozeMin })} options={SNOOZE_OPTIONS} />
        </Field>
        <Field label="ওষুধের আগাম সতর্কতা">
          <SelectField value={notify.medEarlyMin} onChange={(medEarlyMin) => patch({ medEarlyMin })} options={EARLY_OPTIONS} />
        </Field>
        <Field label="‘খেয়েছেন তো?’ তাগাদা" >
          <SelectField value={notify.medFollowUps} onChange={(medFollowUps) => patch({ medFollowUps })} options={FOLLOW_OPTIONS} />
        </Field>
        {notify.medFollowUps > 0 && (
          <Field label="তাগাদা কতক্ষণ পরপর">
            <SelectField value={notify.medFollowEveryMin} onChange={(medFollowEveryMin) => patch({ medFollowEveryMin })} options={SNOOZE_OPTIONS} />
          </Field>
        )}
      </div>
      <p className="text-[11px] opacity-50">তাগাদা: ওষুধের সময়ের পর ‘খেয়েছি’ না চাপা পর্যন্ত নির্দিষ্ট বার আবার মনে করানো হবে।</p>
    </Card>
  );
}

function CategoriesCard() {
  const { categories } = useAppData().settings;
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [icon, setIcon] = useState("📌");

  const openFor = (id: string | null) => {
    const c = categories.find((x) => x.id === id);
    setEditId(id);
    setName(c?.name ?? "");
    setIcon(c?.icon ?? "📌");
    setOpen(true);
  };

  const save = () => {
    if (!name.trim()) return showToast("নাম লিখুন");
    saveCategory({ id: editId ?? uid(), name: name.trim(), icon: icon || "📌" });
    setOpen(false);
  };

  const remove = async (id: string, label: string) => {
    if (await confirm({ title: `"${label}" মুছবেন?`, message: "এই ক্যাটাগরির রিমাইন্ডারগুলো প্রথম ক্যাটাগরিতে চলে যাবে।", confirmText: "মুছুন", danger: true })) deleteCategory(id);
  };

  return (
    <Card>
      <h2 className="mb-3 font-bold">🏷️ রিমাইন্ডারের ক্যাটাগরি</h2>
      <div className="space-y-2">
        {categories.map((c) => (
          <div key={c.id} className="flex items-center justify-between rounded-2xl bg-white/60 px-3 py-2 text-sm dark:bg-white/5">
            <span>
              {c.icon} {c.name}
            </span>
            <span className="flex gap-3 text-xs">
              <button type="button" className="font-semibold text-[var(--color-accent)]" onClick={() => openFor(c.id)}>
                এডিট
              </button>
              {categories.length > 1 && (
                <button type="button" className="font-semibold text-red-500" onClick={() => void remove(c.id, c.name)}>
                  মুছুন
                </button>
              )}
            </span>
          </div>
        ))}
      </div>
      <Button variant="soft" block className="mt-3" onClick={() => openFor(null)}>
        + নতুন ক্যাটাগরি
      </Button>
      <Modal open={open} onClose={() => setOpen(false)} title={editId ? "ক্যাটাগরি এডিট" : "নতুন ক্যাটাগরি"}>
        <div className="space-y-3">
          <Field label="নাম">
            <input className={inputClass} value={name} onChange={(e) => setName(e.target.value.slice(0, 30))} />
          </Field>
          <IconPicker value={icon} onChange={setIcon} />
          <Button block onClick={save}>
            সংরক্ষণ করুন
          </Button>
        </div>
      </Modal>
    </Card>
  );
}

function PinCard() {
  const confirm = useConfirm();
  const [has, setHas] = useState(hasPin());
  const [p1, setP1] = useState("");
  const [p2, setP2] = useState("");
  const [lock, setLock] = useState(getAutoLockSec());
  const digits = (v: string) => v.replace(/\D/g, "").slice(0, 4);

  const enable = async () => {
    if (!/^\d{4}$/.test(p1)) return showToast("৪ ডিজিটের সংখ্যা দিন");
    if (p1 !== p2) return showToast("দুটি পিন মিলছে না");
    try {
      await savePin(p1);
      setHas(true);
      setP1("");
      setP2("");
      setLock(getAutoLockSec());
      showToast("✅ পিন চালু হয়েছে");
    } catch {
      showToast("এই ফোনে পিন লক চালু করা যায়নি");
    }
  };

  const disable = async () => {
    if (!(await confirm({ title: "পিন লক বন্ধ করবেন?", confirmText: "বন্ধ করুন", danger: true }))) return;
    removePin();
    setHas(false);
  };

  return (
    <Card>
      <h2 className="mb-1 font-bold">🔒 পিন লক</h2>
      <p className="mb-3 text-xs opacity-60">অ্যাপ খুলতে ৪ ডিজিটের পিন লাগবে। পিন এই ফোনেই সুরক্ষিতভাবে (এনক্রিপ্টেড হ্যাশ) থাকে।</p>
      {has ? (
        <div className="space-y-3">
          <Field label="কতক্ষণ পর আবার লক হবে?">
            <select className={inputClass} value={lock} onChange={(e) => { const v = Number(e.target.value); setLock(v); setAutoLockSec(v); }}>
              {AUTO_LOCK_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </Field>
          <Button variant="danger" block onClick={() => void disable()}>
            পিন লক বন্ধ করুন
          </Button>
        </div>
      ) : (
        <div className="space-y-2">
          <input className={`${inputClass} tracking-widest`} inputMode="numeric" value={p1} onChange={(e) => setP1(digits(e.target.value))} placeholder="নতুন ৪ ডিজিটের পিন" />
          <input className={`${inputClass} tracking-widest`} inputMode="numeric" value={p2} onChange={(e) => setP2(digits(e.target.value))} placeholder="পিন আবার লিখুন" />
          <Button block onClick={() => void enable()}>
            পিন চালু করুন
          </Button>
        </div>
      )}
    </Card>
  );
}

function BackupCard() {
  const confirm = useConfirm();
  const data = useAppData();
  const fileRef = useRef<HTMLInputElement>(null);

  const doExport = async () => {
    try {
      const mode = await exportBackup(getState());
      if (mode === "downloaded") showToast("✅ ব্যাকআপ ফাইল ডাউনলোড হয়েছে");
    } catch {
      showToast("ব্যাকআপ তৈরি করা যায়নি");
    }
  };

  const onFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      const parsed = parseBackup(await file.text());
      if (parsed.kind === "entries") {
        const existing = new Set(getState().entries.map((x) => `${x.entryDate}|${x.content}`));
        const fresh = parsed.entries.filter((x) => !existing.has(`${x.entryDate}|${x.content}`)).map((x) => normalizeEntry(x)!);
        setState((s) => ({ ...s, entries: [...fresh, ...s.entries] }));
        showToast(`✅ ${toBn(fresh.length)}টি পুরনো এন্ট্রি যোগ হয়েছে`);
        return;
      }
      const ok = await confirm({
        title: "ব্যাকআপ রিস্টোর করবেন?",
        message: `বর্তমান সব ডেটা মুছে ব্যাকআপের ডেটা বসবে (ডায়েরি ${toBn(parsed.data.entries.length)}টি, ওষুধ ${toBn(parsed.data.medicines.length)}টি)।`,
        confirmText: "রিস্টোর করুন",
        danger: true,
      });
      if (!ok) return;
      replaceAll(parsed.data);
      await syncReminders(getState(), true);
      showToast("✅ রিস্টোর সম্পন্ন");
    } catch (err) {
      showToast(err instanceof Error ? err.message : "রিস্টোর করা যায়নি");
    }
  };

  return (
    <Card>
      <h2 className="mb-1 font-bold">⬇️ ব্যাকআপ ও রিস্টোর</h2>
      <p className="mb-3 text-xs opacity-60">
        ডায়েরি, পানি ও ওষুধের সব ডেটা এক ফাইলে। ফোন বদলালে বা অ্যাপ মুছলে ডেটা হারাবে — তাই মাঝে মাঝে ব্যাকআপ নিয়ে Google Drive/WhatsApp-এ রাখুন। (ফাইলে ডায়েরি সাধারণ লেখা আকারে থাকে, নিরাপদ জায়গায় রাখুন।)
      </p>
      <div className="grid grid-cols-2 gap-2">
        <Button variant="ghost" onClick={() => void doExport()}>
          ⬆️ ব্যাকআপ নিন
        </Button>
        <Button variant="ghost" onClick={() => fileRef.current?.click()}>
          ⬇️ রিস্টোর
        </Button>
      </div>
      <input ref={fileRef} type="file" accept=".json,application/json" className="hidden" onChange={(e) => void onFile(e)} />
      <p className="mt-2 text-[11px] opacity-50">বর্তমানে: ডায়েরি {toBn(data.entries.length)}টি · ওষুধ {toBn(data.medicines.length)}টি</p>
    </Card>
  );
}

function UpdateCard() {
  const u = useUpdater();
  const [version, setVersion] = useState<AppVersion | null>(null);

  useEffect(() => {
    void getAppVersion().then(setVersion);
  }, []);

  const busy = u.status === "checking" || u.status === "downloading";
  return (
    <Card>
      <h2 className="mb-1 font-bold">🚀 অ্যাপ আপডেট</h2>
      <p className="mb-3 text-xs opacity-60">বর্তমান ভার্সন: {version ? toBn(version.name) : "…"}{version && version.build > 0 ? ` (বিল্ড ${toBn(version.build)})` : ""}</p>
      {!updatesAvailable() ? (
        <p className="text-xs opacity-60">আপডেট চেক শুধু ইনস্টল করা অ্যাপে (GitHub থেকে বিল্ড করা APK) কাজ করে।</p>
      ) : (
        <>
          {u.status === "available" && u.info && (
            <div className="mb-3 rounded-2xl bg-[var(--color-accent)]/10 p-3 text-sm">
              <p className="font-semibold">নতুন ভার্সন {toBn(u.info.versionName)} পাওয়া গেছে</p>
              {u.info.notes && <p className="mt-1 text-xs opacity-70">{u.info.notes}</p>}
            </div>
          )}
          {u.status === "uptodate" && <p className="mb-3 text-sm font-medium text-green-600">✅ আপনি সর্বশেষ ভার্সনে আছেন</p>}
          {u.status === "error" && <p className="mb-3 text-sm text-red-500">{u.error}</p>}
          {u.status === "downloading" && <p className="mb-3 text-sm">ডাউনলোড হচ্ছে… {toBn(u.progress)}%</p>}
          {u.status === "available" && u.info ? (
            <Button block onClick={() => void startUpdate()} disabled={busy}>
              ⬇️ আপডেট ইনস্টল করুন
            </Button>
          ) : (
            <Button variant="soft" block disabled={busy} onClick={() => void checkForUpdate(false)}>
              {u.status === "checking" ? "চেক হচ্ছে…" : "🔍 আপডেট আছে কিনা দেখুন"}
            </Button>
          )}
          <p className="mt-2 text-[11px] leading-relaxed opacity-60">
            আপডেট পুরনো অ্যাপের উপরেই বসে — আনইনস্টল লাগে না, ডেটা ঠিক থাকে। প্রথমবার ফোন ‘এই সোর্স থেকে ইনস্টলের অনুমতি’ চাইলে অনুমতি দিন।
          </p>
        </>
      )}
    </Card>
  );
}
