import { useState } from "react";
import { useNavigate } from "react-router-dom";
import MedicineFields from "@/components/MedicineFields";
import { Button, Card, Field, inputClass } from "@/components/ui";
import { FORM_ICONS, formatDose, validateMedicine } from "@/domain/medicine";
import { newMedicine } from "@/domain/medicineDraft";
import type { Medicine, Prescription } from "@/domain/types";
import { toBn } from "@/lib/bn";
import { todayKey } from "@/lib/date";
import { uid } from "@/lib/id";
import { showToast } from "@/lib/toast";
import { saveMedicines } from "@/store/actions";
import { useAppData } from "@/store/store";

/** One doctor's prescription with several medicines, entered in one go. */
export default function PrescriptionFormPage() {
  const { settings } = useAppData();
  const navigate = useNavigate();
  const [doctor, setDoctor] = useState("");
  const [date, setDate] = useState(todayKey());
  const [note, setNote] = useState("");
  const [drafts, setDrafts] = useState<Medicine[]>(() => [newMedicine(settings)]);
  const [open, setOpen] = useState(0);

  const update = (i: number, m: Medicine) => setDrafts((list) => list.map((d, idx) => (idx === i ? m : d)));
  const add = () => {
    setDrafts((list) => [...list, newMedicine(settings, { startDate: date })]);
    setOpen(drafts.length);
  };
  const remove = (i: number) => {
    setDrafts((list) => list.filter((_, idx) => idx !== i));
    setOpen(0);
  };

  const save = () => {
    for (let i = 0; i < drafts.length; i++) {
      const problem = validateMedicine({ ...drafts[i], name: drafts[i].name.trim() });
      if (problem) {
        setOpen(i);
        showToast(`${toBn(i + 1)} নম্বর ওষুধ: ${problem}`);
        return;
      }
    }
    const prescription: Prescription = { id: uid(), doctor: doctor.trim(), date, note: note.trim(), createdAt: new Date().toISOString() };
    saveMedicines(
      drafts.map((d) => ({ ...d, name: d.name.trim(), notes: d.notes.trim(), doctor: doctor.trim(), prescriptionId: prescription.id })),
      prescription,
    );
    showToast(`✅ ${toBn(drafts.length)}টি ওষুধ যোগ হয়েছে, রিমাইন্ডার চালু`);
    navigate("/medicine", { replace: true });
  };

  return (
    <main className="safe-top px-4 pb-28 pt-6">
      <header className="mb-5 flex items-center gap-2">
        <button type="button" onClick={() => (window.history.length > 1 ? navigate(-1) : navigate("/medicine"))} aria-label="ফিরে যান" className="-ml-1 rounded-full px-2 py-1 text-xl opacity-70 active:scale-90">
          ←
        </button>
        <h1 className="text-xl font-bold">প্রেসক্রিপশন 📋</h1>
      </header>

      <Card className="mb-4 space-y-3">
        <Field label="ডাক্তারের নাম (ঐচ্ছিক)">
          <input className={inputClass} value={doctor} onChange={(e) => setDoctor(e.target.value)} placeholder="যেমন: রহমান" />
        </Field>
        <Field label="প্রেসক্রিপশনের তারিখ">
          <input type="date" className={inputClass} value={date} max={todayKey()} onChange={(e) => e.target.value && setDate(e.target.value)} />
        </Field>
        <Field label="কী কারণে (ঐচ্ছিক)">
          <input className={inputClass} value={note} onChange={(e) => setNote(e.target.value)} placeholder="যেমন: জ্বর ও সর্দি" />
        </Field>
      </Card>

      <div className="space-y-3">
        {drafts.map((d, i) => (
          <Card key={d.id}>
            <div className="flex items-center justify-between">
              <button type="button" className="flex-1 text-left" onClick={() => setOpen(open === i ? -1 : i)}>
                <p className="text-sm font-bold">
                  {FORM_ICONS[d.form]} {toBn(i + 1)}. {d.name.trim() || "নতুন ওষুধ"}
                </p>
                {open !== i && d.slots.length > 0 && <p className="text-xs opacity-60">দিনে {toBn(d.slots.length)} বার · {formatDose(d.slots[0].qty, d.form)}</p>}
              </button>
              {drafts.length > 1 && (
                <button type="button" onClick={() => remove(i)} aria-label="এই ওষুধ সরান" className="px-2 text-red-500">
                  ✕
                </button>
              )}
            </div>
            {open === i && (
              <div className="mt-4">
                <MedicineFields value={d} onChange={(m) => update(i, m)} meals={settings.meals} showDoctor={false} />
              </div>
            )}
          </Card>
        ))}
      </div>

      <Button variant="soft" block className="mt-4" onClick={add}>
        + আরেকটি ওষুধ যোগ করুন
      </Button>

      <div className="safe-bottom fixed inset-x-0 bottom-0 z-30 border-t border-[var(--color-accent)]/20 bg-[var(--color-paper)]/95 px-4 py-3 backdrop-blur dark:bg-[var(--color-paper-dark)]/95">
        <div className="mx-auto max-w-xl">
          <Button block className="py-3.5" onClick={save}>
            💾 প্রেসক্রিপশন সংরক্ষণ করুন
          </Button>
        </div>
      </div>
    </main>
  );
}
