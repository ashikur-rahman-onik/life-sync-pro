import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useConfirm } from "@/components/Feedback";
import MoodPicker from "@/components/MoodPicker";
import { Button, EmptyState, inputClass } from "@/components/ui";
import { formatDateBn } from "@/lib/bn";
import { todayKey } from "@/lib/date";
import { getMood } from "@/lib/moods";
import { parseTags } from "@/lib/tags";
import { deleteEntry, updateEntry } from "@/store/actions";
import { useAppData } from "@/store/store";
import type { DiaryEntry } from "@/domain/types";

export default function EntryDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { entries } = useAppData();
  const entry = entries.find((e) => e.id === id);
  const navigate = useNavigate();

  if (!entry) {
    return (
      <main className="safe-top px-4 pt-10">
        <EmptyState icon="🔍" title="এন্ট্রিটি পাওয়া যায়নি" />
        <Button variant="soft" block onClick={() => navigate("/diary", { replace: true })}>
          ← ডায়েরিতে ফিরে যান
        </Button>
      </main>
    );
  }
  // key resets the edit form whenever a different entry is opened
  return <EntryView key={entry.id} entry={entry} />;
}

function EntryView({ entry }: { entry: DiaryEntry }) {
  const navigate = useNavigate();
  const confirm = useConfirm();
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(entry.title);
  const [content, setContent] = useState(entry.content);
  const [mood, setMood] = useState(entry.mood);
  const [tags, setTags] = useState(entry.tags.join(", "));
  const [date, setDate] = useState(entry.entryDate);
  const [error, setError] = useState("");
  const moodInfo = getMood(entry.mood);

  const save = () => {
    if (!content.trim()) {
      setError("লেখা খালি রাখা যাবে না");
      return;
    }
    updateEntry(entry.id, { title: title.trim(), content: content.trim(), mood, tags: parseTags(tags), entryDate: date || entry.entryDate });
    setError("");
    setEditing(false);
  };

  const cancel = () => {
    setTitle(entry.title);
    setContent(entry.content);
    setMood(entry.mood);
    setTags(entry.tags.join(", "));
    setDate(entry.entryDate);
    setError("");
    setEditing(false);
  };

  const remove = async () => {
    const ok = await confirm({ title: "এন্ট্রিটি মুছে ফেলবেন?", message: "এটি আর ফেরত পাওয়া যাবে না।", confirmText: "মুছে ফেলুন", danger: true });
    if (!ok) return;
    deleteEntry(entry.id);
    navigate("/diary", { replace: true });
  };

  return (
    <main className="safe-top px-4 pt-6">
      <div className="mb-4 flex items-center justify-between">
        <button type="button" onClick={() => (window.history.length > 1 ? navigate(-1) : navigate("/diary"))} className="text-sm font-medium opacity-60">
          ← ফিরে যান
        </button>
        <div className="flex gap-4 text-sm">
          {!editing && (
            <button type="button" onClick={() => setEditing(true)} className="font-semibold text-[var(--color-accent)]">
              ✏️ এডিট
            </button>
          )}
          <button type="button" onClick={() => void remove()} className="font-semibold text-red-500">
            🗑️ মুছুন
          </button>
        </div>
      </div>

      {!editing ? (
        <article className="animate-fade-in-up rounded-2xl border border-[var(--color-accent)]/15 bg-white/70 p-5 dark:bg-white/5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium opacity-60">{formatDateBn(entry.entryDate, { weekday: true })}</span>
            <span className="text-2xl">{moodInfo.emoji}</span>
          </div>
          {entry.title && <h1 className="mt-2 text-xl font-bold">{entry.title}</h1>}
          <p className="mt-3 whitespace-pre-wrap text-base leading-relaxed">{entry.content}</p>
          {entry.tags.length > 0 && (
            <div className="mt-4 flex flex-wrap gap-1.5">
              {entry.tags.map((t) => (
                <span key={t} className="rounded-full bg-[var(--color-accent)]/10 px-2.5 py-1 text-xs text-[var(--color-accent)]">
                  #{t}
                </span>
              ))}
            </div>
          )}
        </article>
      ) : (
        <div className="space-y-3">
          <input type="date" value={date} max={todayKey()} onChange={(e) => setDate(e.target.value)} className={inputClass} />
          <MoodPicker value={mood} onChange={setMood} />
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="শিরোনাম (ঐচ্ছিক)" className={`${inputClass} font-medium`} />
          <textarea value={content} onChange={(e) => setContent(e.target.value)} rows={10} className={`${inputClass} resize-none text-base leading-relaxed`} />
          <input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="ট্যাগ (কমা দিয়ে ভাগ করুন)" className={inputClass} />
          {error && <p className="text-sm font-medium text-red-500">{error}</p>}
          <div className="flex gap-2">
            <Button block onClick={save}>
              💾 সংরক্ষণ করুন
            </Button>
            <Button variant="ghost" onClick={cancel}>
              বাতিল
            </Button>
          </div>
        </div>
      )}
    </main>
  );
}
