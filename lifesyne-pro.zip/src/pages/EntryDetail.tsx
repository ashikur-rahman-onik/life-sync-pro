import { useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import BookReader from "@/components/BookReader";
import EntryEditor from "@/components/EntryEditor";
import { useConfirm } from "@/components/Feedback";
import { Button, EmptyState } from "@/components/ui";
import { chronological } from "@/domain/diary";
import { deleteEntry, updateEntry } from "@/store/actions";
import { useAppData } from "@/store/store";

/** Opens the diary as a full-screen book at this page. */
export default function EntryDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { entries, settings } = useAppData();
  const navigate = useNavigate();
  const confirm = useConfirm();
  const [editingId, setEditingId] = useState<string | null>(null);

  const ordered = useMemo(() => chronological(entries), [entries]);
  const editing = editingId ? entries.find((e) => e.id === editingId) : undefined;
  const exists = entries.some((e) => e.id === id);

  if (editing) {
    return (
      <main className="safe-top px-4 pb-8 pt-6">
        <h1 className="mb-4 text-xl font-bold">পাতা এডিট ✏️</h1>
        <EntryEditor
          initial={{ title: editing.title, content: editing.content, mood: editing.mood, tags: editing.tags, entryDate: editing.entryDate, favorite: editing.favorite, attachments: editing.attachments }}
          saveLabel="💾 সংরক্ষণ করুন"
          onCancel={() => setEditingId(null)}
          onSave={(values) => {
            updateEntry(editing.id, values);
            setEditingId(null);
          }}
        />
      </main>
    );
  }

  if (!exists || !id) {
    return (
      <main className="safe-top px-4 pt-10">
        <EmptyState icon="🔍" title="পাতাটি পাওয়া যায়নি" />
        <Button variant="soft" block onClick={() => navigate("/diary/pages", { replace: true })}>
          ← সব পাতায় ফিরে যান
        </Button>
      </main>
    );
  }

  return (
    <BookReader
      entries={ordered}
      startId={id}
      diary={settings.diary}
      onClose={() => (window.history.length > 1 ? navigate(-1) : navigate("/diary"))}
      onEdit={(e) => setEditingId(e.id)}
      onToggleBookmark={(e) => updateEntry(e.id, { favorite: !e.favorite })}
      onNew={() => navigate("/new")}
      onDelete={async (e) => {
        const ok = await confirm({ title: "এই পাতাটি মুছে ফেলবেন?", message: "এটি আর ফেরত পাওয়া যাবে না।", confirmText: "মুছে ফেলুন", danger: true });
        if (!ok) return;
        deleteEntry(e.id);
        navigate("/diary/pages", { replace: true });
      }}
    />
  );
}
