import { useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { AttachmentGallery } from "@/components/AttachmentViews";
import DiaryPaper from "@/components/DiaryPaper";
import EntryEditor from "@/components/EntryEditor";
import { useConfirm } from "@/components/Feedback";
import { Button, EmptyState } from "@/components/ui";
import { chronological, pageNumbers } from "@/domain/diary";
import type { DiaryEntry } from "@/domain/types";
import { formatDateBn, toBn, WEEKDAYS_BN } from "@/lib/bn";
import { parseDateKey } from "@/lib/date";
import { getMood } from "@/lib/moods";
import { deleteEntry, updateEntry } from "@/store/actions";
import { useAppData } from "@/store/store";

export default function EntryDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { entries } = useAppData();
  const navigate = useNavigate();
  const entry = entries.find((e) => e.id === id);

  if (!entry) {
    return (
      <main className="safe-top px-4 pt-10">
        <EmptyState icon="🔍" title="পাতাটি পাওয়া যায়নি" />
        <Button variant="soft" block onClick={() => navigate("/diary/pages", { replace: true })}>
          ← সব পাতায় ফিরে যান
        </Button>
      </main>
    );
  }
  // key restarts the page-turn animation and the edit form whenever another page opens
  return <PageView key={entry.id} entry={entry} />;
}

function PageView({ entry }: { entry: DiaryEntry }) {
  const navigate = useNavigate();
  const confirm = useConfirm();
  const { entries, settings } = useAppData();
  const [editing, setEditing] = useState(false);
  const mood = getMood(entry.mood);

  const { prev, next, number } = useMemo(() => {
    const ordered = chronological(entries);
    const i = ordered.findIndex((e) => e.id === entry.id);
    return { prev: ordered[i - 1] ?? null, next: ordered[i + 1] ?? null, number: pageNumbers(entries).get(entry.id) ?? 1 };
  }, [entries, entry.id]);

  const remove = async () => {
    const ok = await confirm({ title: "এই পাতাটি মুছে ফেলবেন?", message: "এটি আর ফেরত পাওয়া যাবে না।", confirmText: "মুছে ফেলুন", danger: true });
    if (!ok) return;
    deleteEntry(entry.id);
    navigate("/diary/pages", { replace: true });
  };

  if (editing) {
    return (
      <main className="safe-top px-4 pb-8 pt-6">
        <h1 className="mb-4 text-xl font-bold">পাতা এডিট ✏️</h1>
        <EntryEditor
          initial={{ title: entry.title, content: entry.content, mood: entry.mood, tags: entry.tags, entryDate: entry.entryDate, favorite: entry.favorite, attachments: entry.attachments }}
          saveLabel="💾 সংরক্ষণ করুন"
          onCancel={() => setEditing(false)}
          onSave={(values) => {
            updateEntry(entry.id, values);
            setEditing(false);
          }}
        />
      </main>
    );
  }

  const weekday = WEEKDAYS_BN[parseDateKey(entry.entryDate).getDay()];
  return (
    <main className="safe-top px-4 pb-8 pt-6">
      <div className="mb-3 flex items-center justify-between">
        <button type="button" onClick={() => (window.history.length > 1 ? navigate(-1) : navigate("/diary/pages"))} className="text-sm font-medium opacity-60">
          ← ফিরে যান
        </button>
        <div className="flex gap-4 text-sm">
          <button type="button" onClick={() => setEditing(true)} className="font-semibold text-[var(--color-accent)]">
            ✏️ এডিট
          </button>
          <button type="button" onClick={() => void remove()} className="font-semibold text-red-500">
            🗑️ মুছুন
          </button>
        </div>
      </div>

      <div className="animate-page-turn">
        <DiaryPaper diary={settings.diary} className="pb-6" minHeight="26rem">
          <div className="flex items-start justify-between pt-1">
            <div>
              <p className="text-[0.8em] opacity-60" style={{ lineHeight: "var(--lh)" }}>
                {weekday}
              </p>
              <p className="font-semibold" style={{ fontSize: "calc(var(--fs) * 1.15)", lineHeight: "var(--lh)" }}>
                {formatDateBn(entry.entryDate)}
              </p>
            </div>
            <div className="mr-1 flex flex-col items-center">
              <span className="flex h-12 w-12 -rotate-6 items-center justify-center rounded-full border-2 border-dashed border-current text-2xl opacity-80" title={mood.label}>
                {mood.emoji}
              </span>
              <span className="mt-1 text-[10px] opacity-50">পাতা {toBn(number)}</span>
            </div>
          </div>
          {entry.title && <h1 className="paper-title mt-1">{entry.title}</h1>}
          {entry.content && <p className="paper-text mt-1">{entry.content}</p>}
          {entry.attachments.length > 0 && (
            <div className="mt-3 pr-1">
              <AttachmentGallery attachments={entry.attachments} />
            </div>
          )}
          {entry.tags.length > 0 && (
            <div className="mt-5 flex flex-wrap gap-2 pr-1">
              {entry.tags.map((t, i) => (
                <span key={t} className="bg-amber-200/70 px-2.5 py-1 text-xs text-amber-950 shadow-sm" style={{ transform: `rotate(${i % 2 ? 2 : -2}deg)` }}>
                  #{t}
                </span>
              ))}
            </div>
          )}
          <button type="button" onClick={() => updateEntry(entry.id, { favorite: !entry.favorite })} aria-label="প্রিয় পাতা" className="absolute right-3 top-0 text-2xl drop-shadow" style={{ color: entry.favorite ? "#f5a623" : "rgba(0,0,0,0.25)" }}>
            {entry.favorite ? "🔖" : "🏷️"}
          </button>
        </DiaryPaper>
      </div>

      <div className="mt-4 flex items-center justify-between">
        <Button variant="ghost" disabled={!prev} onClick={() => prev && navigate(`/entry/${prev.id}`, { replace: true })}>
          ← আগের পাতা
        </Button>
        <Button variant="ghost" disabled={!next} onClick={() => next && navigate(`/entry/${next.id}`, { replace: true })}>
          পরের পাতা →
        </Button>
      </div>
    </main>
  );
}
