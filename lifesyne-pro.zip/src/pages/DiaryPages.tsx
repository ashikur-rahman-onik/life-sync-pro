import { useMemo, useState } from "react";
import EntryCard from "@/components/EntryCard";
import { Card, Chip, EmptyState, PageHeader, ProgressBar, Segmented, inputClass } from "@/components/ui";
import { diaryStats, filterEntries, groupByMonth, pageNumbers, sortEntries } from "@/domain/diary";
import type { DiaryEntry } from "@/domain/types";
import { monthLabelBn, toBn, WEEKDAYS_SHORT_BN } from "@/lib/bn";
import { pad, todayKey } from "@/lib/date";
import { getMood, MOODS } from "@/lib/moods";
import { useAppData } from "@/store/store";

type Tab = "list" | "calendar" | "stats";

export default function DiaryPagesPage() {
  const [tab, setTab] = useState<Tab>("list");
  return (
    <main className="safe-top px-4 pt-6">
      <PageHeader title="সব পাতা 📖" back />
      <div className="mb-4">
        <Segmented
          value={tab}
          onChange={setTab}
          options={[
            { value: "list", label: "📚 লেখা" },
            { value: "calendar", label: "📅 ক্যালেন্ডার" },
            { value: "stats", label: "📊 পরিসংখ্যান" },
          ]}
        />
      </div>
      {tab === "list" && <ListTab />}
      {tab === "calendar" && <CalendarTab />}
      {tab === "stats" && <StatsTab />}
    </main>
  );
}

function ListTab() {
  const { entries } = useAppData();
  const [search, setSearch] = useState("");
  const [mood, setMood] = useState<string | null>(null);
  const [onlyFavorites, setOnlyFavorites] = useState(false);

  const grouped = useMemo(() => groupByMonth(sortEntries(filterEntries(entries, search, mood, onlyFavorites))), [entries, search, mood, onlyFavorites]);
  const numbers = useMemo(() => pageNumbers(entries), [entries]);

  return (
    <>
      <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="🔍 লেখা খুঁজুন..." className={`${inputClass} mb-3`} />
      <div className="mb-5 flex gap-2 overflow-x-auto pb-1">
        <Chip active={mood === null && !onlyFavorites} onClick={() => { setMood(null); setOnlyFavorites(false); }}>
          সব
        </Chip>
        <Chip active={onlyFavorites} onClick={() => setOnlyFavorites((v) => !v)}>
          🔖 প্রিয়
        </Chip>
        {MOODS.map((m) => (
          <Chip key={m.key} active={mood === m.key} onClick={() => setMood((p) => (p === m.key ? null : m.key))}>
            {m.emoji} {m.label}
          </Chip>
        ))}
      </div>
      {grouped.length === 0 ? (
        <EmptyState icon="📔" title={entries.length === 0 ? "এখনও কোনো এন্ট্রি নেই" : "কিছু পাওয়া যায়নি"} text={entries.length === 0 ? "নিচের ➕ বাটনে চেপে ‘ডায়েরি লিখুন’ বেছে নিন" : undefined} />
      ) : (
        <div className="space-y-6">
          {grouped.map(([month, list]) => {
            const [y, m] = month.split("-").map(Number);
            return (
              <section key={month}>
                <h2 className="mb-2 text-xs font-semibold tracking-wide opacity-50">{monthLabelBn(y, m)}</h2>
                <div className="space-y-3">
                  {list.map((e) => (
                    <EntryCard key={e.id} entry={e} pageNumber={numbers.get(e.id)} />
                  ))}
                </div>
              </section>
            );
          })}
        </div>
      )}
    </>
  );
}

function CalendarTab() {
  const { entries } = useAppData();
  const [cursor, setCursor] = useState(() => {
    const now = new Date();
    return { year: now.getFullYear(), month: now.getMonth() + 1 };
  });
  const [selected, setSelected] = useState<string | null>(null);

  const prefix = `${cursor.year}-${pad(cursor.month)}`;
  const byDay = useMemo(() => {
    const map = new Map<string, DiaryEntry[]>();
    for (const e of sortEntries(entries)) {
      if (!e.entryDate.startsWith(prefix)) continue;
      map.set(e.entryDate, [...(map.get(e.entryDate) ?? []), e]);
    }
    return map;
  }, [entries, prefix]);

  const daysInMonth = new Date(cursor.year, cursor.month, 0).getDate();
  const firstWeekday = new Date(cursor.year, cursor.month - 1, 1).getDay();
  const cells: (number | null)[] = [...Array<null>(firstWeekday).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)];
  const today = todayKey();
  const monthEntries = [...byDay.values()].flat();
  const shown = selected ? (byDay.get(selected) ?? []) : monthEntries;

  const change = (delta: number) => {
    setSelected(null);
    setCursor((p) => {
      const idx = p.year * 12 + (p.month - 1) + delta;
      return { year: Math.floor(idx / 12), month: (idx % 12) + 1 };
    });
  };

  return (
    <>
      <Card className="mb-4 flex items-center justify-between !py-3">
        <button type="button" onClick={() => change(-1)} aria-label="আগের মাস" className="px-3 text-lg active:scale-90">
          ‹
        </button>
        <span className="font-semibold">{monthLabelBn(cursor.year, cursor.month)}</span>
        <button type="button" onClick={() => change(1)} aria-label="পরের মাস" className="px-3 text-lg active:scale-90">
          ›
        </button>
      </Card>
      <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-medium opacity-50">
        {WEEKDAYS_SHORT_BN.map((d) => (
          <div key={d} className="py-1">
            {d}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {cells.map((day, idx) => {
          if (day === null) return <div key={`b${idx}`} />;
          const key = `${prefix}-${pad(day)}`;
          const list = byDay.get(key);
          const isSel = key === selected;
          return (
            <button
              key={key}
              type="button"
              onClick={() => setSelected((p) => (p === key ? null : key))}
              className={`flex aspect-square flex-col items-center justify-center rounded-xl text-sm transition ${
                isSel ? "bg-[var(--color-accent)] text-white" : key === today ? "border border-[var(--color-accent)] font-semibold" : "bg-white/50 dark:bg-white/5"
              }`}
            >
              {toBn(day)}
              {list && <span className="mt-0.5 text-[10px]">{getMood(list[0].mood).emoji}</span>}
            </button>
          );
        })}
      </div>
      <div className="mt-6 space-y-3">
        {selected && shown.length === 0 && <p className="text-center text-sm opacity-50">এই দিনে কোনো এন্ট্রি নেই।</p>}
        {!selected && monthEntries.length === 0 && <p className="py-6 text-center text-sm opacity-50">এই মাসে কোনো এন্ট্রি নেই।</p>}
        {shown.map((e) => (
          <EntryCard key={e.id} entry={e} />
        ))}
      </div>
    </>
  );
}

function StatsTab() {
  const { entries } = useAppData();
  const stats = diaryStats(entries, todayKey());
  const max = Math.max(1, ...MOODS.map((m) => stats.moodCounts[m.key] ?? 0));

  return (
    <>
      <div className="mb-6 grid grid-cols-2 gap-3">
        {[
          { icon: "📚", label: "মোট এন্ট্রি", value: toBn(stats.total) },
          { icon: "🔥", label: "বর্তমান ধারাবাহিকতা", value: `${toBn(stats.streak)} দিন` },
          { icon: "🗓️", label: "এই মাসে লেখা", value: toBn(stats.entriesThisMonth) },
          { icon: "✨", label: "মোট দিন লেখা হয়েছে", value: toBn(stats.daysWritten) },
        ].map((s) => (
          <Card key={s.label}>
            <div className="text-xl">{s.icon}</div>
            <div className="mt-1 text-lg font-bold">{s.value}</div>
            <div className="text-[11px] opacity-60">{s.label}</div>
          </Card>
        ))}
      </div>
      <Card>
        <h2 className="mb-4 font-semibold">মুড বিশ্লেষণ</h2>
        <div className="space-y-3">
          {MOODS.map((m) => {
            const count = stats.moodCounts[m.key] ?? 0;
            const pct = stats.total ? Math.round((count / stats.total) * 100) : 0;
            return (
              <div key={m.key}>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span>
                    {m.emoji} {m.label}
                  </span>
                  <span className="opacity-60">
                    {toBn(count)} টি ({toBn(pct)}%)
                  </span>
                </div>
                <ProgressBar percent={(count / max) * 100} color={m.color} />
              </div>
            );
          })}
        </div>
      </Card>
      {stats.total === 0 && <p className="mt-8 text-center text-sm opacity-50">লেখা শুরু করলে এখানে আপনার পরিসংখ্যান দেখা যাবে।</p>}
    </>
  );
}
