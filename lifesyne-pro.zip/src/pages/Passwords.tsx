import { useMemo, useState } from "react";
import { useConfirm } from "@/components/Feedback";
import { Button, Chip, EmptyState, Field, inputClass, Modal, PageHeader } from "@/components/ui";
import type { PasswordItem } from "@/domain/types";
import { PASSWORD_TAGS, tagOf } from "@/domain/vaultMeta";
import { generatePassword, passwordStrength } from "@/lib/password";
import { showToast } from "@/lib/toast";
import { deletePasswordItem, savePasswordItem } from "@/store/actions";
import { useAppData } from "@/store/store";

async function copy(text: string, what: string): Promise<void> {
  try {
    await navigator.clipboard.writeText(text);
    showToast(`📋 ${what} কপি হয়েছে`);
  } catch {
    showToast("কপি করা যায়নি");
  }
}

export default function PasswordsPage() {
  const { passwords } = useAppData();
  const [search, setSearch] = useState("");
  const [tag, setTag] = useState<string | null>(null);
  const [editing, setEditing] = useState<PasswordItem | "new" | null>(null);

  const shown = useMemo(() => {
    const q = search.trim().toLowerCase();
    return passwords
      .filter((p) => (!tag || p.tag === tag) && (!q || p.title.toLowerCase().includes(q) || p.username.toLowerCase().includes(q)))
      .sort((a, b) => a.title.localeCompare(b.title, "bn"));
  }, [passwords, search, tag]);

  return (
    <main className="safe-top px-4 pb-6 pt-6">
      <PageHeader title="পাসওয়ার্ড 🔑" back right={<Button className="!px-3 !py-2" onClick={() => setEditing("new")}>+ যোগ</Button>} />
      <p className="mb-3 rounded-xl bg-amber-500/10 px-3 py-2 text-[11px] leading-relaxed">
        ⚠️ পাসওয়ার্ডগুলো আপনার Firebase অ্যাকাউন্টে জমা থাকে এবং ডায়েরির লকের আড়ালে দেখানো হয়। ব্যাংকের মূল পিন বা খুব স্পর্শকাতর পাসওয়ার্ড না রাখাই নিরাপদ।
      </p>
      <input className={`${inputClass} mb-3`} value={search} onChange={(e) => setSearch(e.target.value)} placeholder="🔍 খুঁজুন..." />
      <div className="mb-4 flex gap-2 overflow-x-auto pb-1">
        <Chip active={tag === null} onClick={() => setTag(null)}>
          সব
        </Chip>
        {PASSWORD_TAGS.map((t) => (
          <Chip key={t.id} active={tag === t.id} onClick={() => setTag((p) => (p === t.id ? null : t.id))}>
            {t.icon} {t.name}
          </Chip>
        ))}
      </div>

      {shown.length === 0 ? (
        <EmptyState icon="🔑" title={passwords.length === 0 ? "কোনো পাসওয়ার্ড জমা নেই" : "কিছু পাওয়া যায়নি"} text={passwords.length === 0 ? "অ্যাপ, ওয়েবসাইট বা ইমেইলের পাসওয়ার্ড এখানে রাখুন। শক্তিশালী পাসওয়ার্ড বানানোর টুলও আছে।" : undefined} />
      ) : (
        <div className="space-y-3">
          {shown.map((p) => (
            <PasswordCard key={p.id} item={p} onEdit={() => setEditing(p)} />
          ))}
        </div>
      )}

      <Modal open={editing !== null} onClose={() => setEditing(null)} title={editing === "new" ? "নতুন পাসওয়ার্ড" : "পাসওয়ার্ড এডিট"}>
        {editing !== null && <PasswordForm key={editing === "new" ? "new" : editing.id} item={editing === "new" ? null : editing} onClose={() => setEditing(null)} />}
      </Modal>
    </main>
  );
}

function PasswordCard({ item, onEdit }: { item: PasswordItem; onEdit: () => void }) {
  const [open, setOpen] = useState(false);
  const [reveal, setReveal] = useState(false);
  const t = tagOf(PASSWORD_TAGS, item.tag);

  return (
    <div className="rounded-2xl border border-[var(--color-accent)]/15 bg-white/70 p-4 shadow-sm dark:bg-white/5">
      <button type="button" className="flex w-full items-center justify-between gap-2 text-left" onClick={() => { setOpen((v) => !v); setReveal(false); }}>
        <span className="min-w-0">
          <span className="block truncate font-bold">
            {t.icon} {item.title}
          </span>
          {item.username && <span className="block truncate text-xs opacity-60">{item.username}</span>}
        </span>
        <span className="text-xs opacity-50">{open ? "▲" : "▼"}</span>
      </button>
      {open && (
        <div className="mt-3 space-y-2 border-t border-black/5 pt-3 text-sm dark:border-white/10">
          {item.username && (
            <div className="flex items-center justify-between gap-2">
              <span className="min-w-0 truncate">👤 {item.username}</span>
              <button type="button" className="shrink-0 text-xs font-semibold text-[var(--color-accent)]" onClick={() => void copy(item.username, "ইউজারনেম")}>
                কপি
              </button>
            </div>
          )}
          <div className="flex items-center justify-between gap-2">
            <span className="min-w-0 truncate font-mono">🔑 {reveal ? item.password : "•".repeat(Math.min(12, Math.max(6, item.password.length)))}</span>
            <span className="flex shrink-0 gap-3 text-xs font-semibold text-[var(--color-accent)]">
              <button type="button" onClick={() => setReveal((v) => !v)}>
                {reveal ? "লুকান" : "দেখুন"}
              </button>
              <button type="button" onClick={() => void copy(item.password, "পাসওয়ার্ড")}>
                কপি
              </button>
            </span>
          </div>
          {item.url && (
            <a href={/^https?:\/\//.test(item.url) ? item.url : `https://${item.url}`} target="_blank" rel="noopener noreferrer" className="block truncate text-xs text-[var(--color-accent)] underline">
              🌐 {item.url}
            </a>
          )}
          {item.note && <p className="text-xs opacity-70">📝 {item.note}</p>}
          <Button variant="soft" className="!py-1.5 !text-xs" onClick={onEdit}>
            ✏️ এডিট / মুছুন
          </Button>
        </div>
      )}
    </div>
  );
}

function PasswordForm({ item, onClose }: { item: PasswordItem | null; onClose: () => void }) {
  const confirm = useConfirm();
  const [title, setTitle] = useState(item?.title ?? "");
  const [username, setUsername] = useState(item?.username ?? "");
  const [password, setPassword] = useState(item?.password ?? "");
  const [url, setUrl] = useState(item?.url ?? "");
  const [note, setNote] = useState(item?.note ?? "");
  const [tag, setTag] = useState(item?.tag ?? PASSWORD_TAGS[0].id);
  const [show, setShow] = useState(item === null);
  const strength = passwordStrength(password);

  const save = () => {
    if (!title.trim()) return showToast("কোন সাইট/অ্যাপের জন্য? নাম দিন");
    if (!password) return showToast("পাসওয়ার্ড লিখুন");
    savePasswordItem(item?.id ?? null, { title: title.trim(), username: username.trim(), password, url: url.trim(), note: note.trim(), tag });
    showToast("✅ সংরক্ষিত");
    onClose();
  };

  const remove = async () => {
    if (item && (await confirm({ title: `"${item.title}" মুছবেন?`, confirmText: "মুছুন", danger: true }))) {
      deletePasswordItem(item.id);
      onClose();
    }
  };

  return (
    <div className="space-y-3 pb-2">
      <Field label="সাইট / অ্যাপের নাম">
        <input className={inputClass} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="যেমন: Facebook" />
      </Field>
      <div className="flex flex-wrap gap-2">
        {PASSWORD_TAGS.map((t) => (
          <Chip key={t.id} active={tag === t.id} onClick={() => setTag(t.id)}>
            {t.icon} {t.name}
          </Chip>
        ))}
      </div>
      <Field label="ইউজারনেম / ইমেইল / নম্বর">
        <input className={inputClass} value={username} autoComplete="off" onChange={(e) => setUsername(e.target.value)} />
      </Field>
      <Field label="পাসওয়ার্ড">
        <div className="flex gap-2">
          <input className={`${inputClass} font-mono`} type={show ? "text" : "password"} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <button type="button" onClick={() => setShow((v) => !v)} className="shrink-0 rounded-2xl bg-black/5 px-3 text-sm dark:bg-white/10" aria-label="দেখান/লুকান">
            {show ? "🙈" : "👁️"}
          </button>
        </div>
      </Field>
      {password && (
        <div>
          <div className="flex h-1.5 gap-1">
            {[1, 2, 3, 4].map((n) => (
              <span key={n} className="flex-1 rounded-full" style={{ backgroundColor: strength.score >= n ? strength.color : "rgba(128,128,128,0.2)" }} />
            ))}
          </div>
          <p className="mt-1 text-[11px]" style={{ color: strength.color }}>
            {strength.label}
          </p>
        </div>
      )}
      <Button
        variant="soft"
        block
        onClick={() => {
          setPassword(generatePassword(14));
          setShow(true);
        }}
      >
        🎲 শক্তিশালী পাসওয়ার্ড বানান
      </Button>
      <Field label="ওয়েবসাইট (ঐচ্ছিক)">
        <input className={inputClass} value={url} inputMode="url" onChange={(e) => setUrl(e.target.value)} placeholder="example.com" />
      </Field>
      <Field label="নোট (ঐচ্ছিক)">
        <input className={inputClass} value={note} onChange={(e) => setNote(e.target.value)} />
      </Field>
      <div className="flex gap-2 pt-1">
        {item && (
          <Button variant="danger" onClick={() => void remove()}>
            🗑️
          </Button>
        )}
        <Button block onClick={save}>
          💾 সংরক্ষণ করুন
        </Button>
      </div>
    </div>
  );
}
