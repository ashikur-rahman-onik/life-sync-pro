import { useState } from "react";
import { useConfirm } from "@/components/Feedback";
import WaterRing from "@/components/WaterRing";
import { Button, Card, Chip, EmptyState, Field, Modal, PageHeader, Segmented, Toggle, inputClass } from "@/components/ui";
import { effectiveWaterGoal } from "@/domain/reminders";
import { ACTIVITY_LABELS, calcWaterGoalMl, glassesNeeded, planWaterTimes, waterHistory, waterTotalForDate } from "@/domain/water";
import type { Activity } from "@/domain/types";
import { formatMl, formatTimeBn, toBn, WEEKDAYS_SHORT_BN } from "@/lib/bn";
import { parseDateKey, todayKey } from "@/lib/date";
import { uid } from "@/lib/id";
import { showToast } from "@/lib/toast";
import { addWater, deleteContainer, removeWaterLog, saveContainer, updateSettings } from "@/store/actions";
import { useAppData } from "@/store/store";

const ICONS = ["🥛", "🥤", "🧴", "🍶", "☕", "🫗"];

export default function WaterPage() {
  const data = useAppData();
  const confirm = useConfirm();
  const [sheet, setSheet] = useState<"settings" | "custom" | null>(null);
  const [customMl, setCustomMl] = useState("");
  const today = todayKey();
  const { settings, containers } = data;

  const goal = effectiveWaterGoal(settings);
  const drunk = waterTotalForDate(data.waterLogs, today);
  const todayLogs = data.waterLogs.filter((l) => l.date === today).sort((a, b) => b.at.localeCompare(a.at));
  const defaultContainer = containers.find((c) => c.id === settings.water.defaultContainerId) ?? containers[0];
  const history = waterHistory(data.waterLogs, today, 7);
  const maxBar = Math.max(goal ?? 0, ...history.map((h) => h.ml), 1);

  const drink = (ml: number, name: string) => {
    addWater(ml, name);
    showToast(`💧 ${formatMl(ml)} পানি যোগ হয়েছে`);
  };

  const addCustom = () => {
    const ml = parseInt(customMl, 10);
    if (!(ml >= 10 && ml <= 5000)) {
      showToast("১০ থেকে ৫০০০ মি.লি. এর মধ্যে লিখুন");
      return;
    }
    drink(ml, "অন্য পরিমাণ");
    setCustomMl("");
    setSheet(null);
  };

  const remove = async (id: string) => {
    if (await confirm({ title: "এই এন্ট্রি মুছবেন?", confirmText: "মুছুন", danger: true })) removeWaterLog(id);
  };

  return (
    <main className="safe-top px-4 pt-6">
      <PageHeader
        title="পানির হিসাব 💧"
        right={
          <button type="button" onClick={() => setSheet("settings")} aria-label="পানির সেটিংস" className="rounded-full bg-white/70 p-2.5 text-lg shadow-sm active:scale-90 dark:bg-white/10">
            ⚙️
          </button>
        }
      />

      {goal === null ? (
        <Card className="mb-4 text-center">
          <p className="font-semibold">আপনার দৈনিক পানির লক্ষ্য ঠিক করি</p>
          <p className="mt-1 text-xs opacity-60">বয়স ও ওজন দিলে প্রতিদিন কত লিটার পানি লাগবে এবং কখন কখন খেতে হবে তা হিসাব করে রিমাইন্ডার দেব।</p>
          <Button className="mt-3" onClick={() => setSheet("settings")}>
            বয়স ও ওজন দিন
          </Button>
        </Card>
      ) : (
        <Card className="mb-4">
          <div className="flex items-center gap-4">
            <WaterRing valueMl={drunk} goalMl={goal} />
            <div className="min-w-0 flex-1 text-sm">
              {drunk >= goal ? (
                <p className="font-semibold text-green-600">🎉 আজকের লক্ষ্য পূরণ!</p>
              ) : (
                <>
                  <p className="font-semibold">আরও {formatMl(goal - drunk)} বাকি</p>
                  {defaultContainer && (
                    <p className="mt-0.5 text-xs opacity-60">
                      প্রায় {toBn(glassesNeeded(goal - drunk, defaultContainer.ml))}টি {defaultContainer.name}
                    </p>
                  )}
                </>
              )}
              <p className="mt-2 text-xs opacity-60">দৈনিক লক্ষ্য: {formatMl(goal)}</p>
            </div>
          </div>
        </Card>
      )}

      <h2 className="mb-2 text-sm font-bold">কী দিয়ে খেলেন? (ট্যাপ করলেই যোগ হবে)</h2>
      <div className="mb-5 grid grid-cols-3 gap-2.5">
        {containers.map((c) => (
          <button key={c.id} type="button" onClick={() => drink(c.ml, c.name)} className="rounded-2xl border border-[var(--color-water)]/25 bg-white/70 px-2 py-3 text-center transition active:scale-95 dark:bg-white/5">
            <div className="text-2xl">{c.icon}</div>
            <div className="mt-1 text-xs font-semibold">{c.name}</div>
            <div className="text-[11px] opacity-60">{formatMl(c.ml)}</div>
          </button>
        ))}
        <button type="button" onClick={() => setSheet("custom")} className="rounded-2xl border border-dashed border-[var(--color-water)]/40 px-2 py-3 text-center active:scale-95">
          <div className="text-2xl">➕</div>
          <div className="mt-1 text-xs font-semibold">অন্য পরিমাণ</div>
        </button>
      </div>

      <Card className="mb-5">
        <h2 className="mb-3 text-sm font-bold">গত ৭ দিন</h2>
        <div className="flex h-28 items-end justify-between gap-2">
          {history.map((h) => {
            const reached = goal !== null && h.ml >= goal;
            return (
              <div key={h.date} className="flex flex-1 flex-col items-center justify-end gap-1">
                <span className="text-[9px] opacity-60">{h.ml > 0 ? toBn((h.ml / 1000).toFixed(1)) : ""}</span>
                <div className="w-full rounded-t-lg" style={{ height: `${Math.max(3, (h.ml / maxBar) * 80)}px`, backgroundColor: reached ? "#22c55e" : "var(--color-water)", opacity: h.ml ? 1 : 0.2 }} />
                <span className="text-[10px] opacity-60">{WEEKDAYS_SHORT_BN[parseDateKey(h.date).getDay()]}</span>
              </div>
            );
          })}
        </div>
        <p className="mt-2 text-[10px] opacity-50">সংখ্যাগুলো লিটারে। সবুজ মানে লক্ষ্য পূরণ হয়েছে।</p>
      </Card>

      <h2 className="mb-2 text-sm font-bold">আজকের হিসাব</h2>
      {todayLogs.length === 0 ? (
        <EmptyState icon="🥛" title="আজ এখনও পানি খাওয়া হয়নি" text="উপরের পাত্রে ট্যাপ করে হিসাব শুরু করুন" />
      ) : (
        <div className="space-y-2">
          {todayLogs.map((l) => (
            <div key={l.id} className="flex items-center justify-between rounded-2xl bg-white/70 px-4 py-3 text-sm dark:bg-white/5">
              <span>
                💧 {l.containerName} · <b>{formatMl(l.ml)}</b>
              </span>
              <span className="flex items-center gap-3">
                <span className="text-xs opacity-60">{formatTimeBn(`${String(new Date(l.at).getHours()).padStart(2, "0")}:${String(new Date(l.at).getMinutes()).padStart(2, "0")}`)}</span>
                <button type="button" onClick={() => void remove(l.id)} aria-label="মুছুন" className="text-red-500">
                  ✕
                </button>
              </span>
            </div>
          ))}
        </div>
      )}

      <Modal open={sheet === "custom"} onClose={() => setSheet(null)} title="অন্য পরিমাণ পানি">
        <Field label="কত মি.লি.?">
          <input className={inputClass} inputMode="numeric" value={customMl} onChange={(e) => setCustomMl(e.target.value.replace(/\D/g, "").slice(0, 4))} placeholder="যেমন: ৩০০" autoFocus />
        </Field>
        <Button block className="mt-4" onClick={addCustom}>
          যোগ করুন
        </Button>
      </Modal>

      <Modal open={sheet === "settings"} onClose={() => setSheet(null)} title="পানির সেটিংস">
        <WaterSettings />
      </Modal>
    </main>
  );
}

function NumberInput({ value, onChange, placeholder, max }: { value: number | null; onChange: (v: number | null) => void; placeholder: string; max: number }) {
  const [text, setText] = useState(value === null ? "" : String(value));
  return (
    <input
      className={inputClass}
      inputMode="decimal"
      value={text}
      placeholder={placeholder}
      onChange={(e) => {
        const raw = e.target.value.replace(/[^\d.]/g, "").slice(0, 5);
        setText(raw);
        const n = parseFloat(raw);
        onChange(raw === "" || Number.isNaN(n) || n <= 0 || n > max ? null : n);
      }}
    />
  );
}

function WaterSettings() {
  const { settings, containers } = useAppData();
  const confirm = useConfirm();
  const { profile, water } = settings;
  const [newName, setNewName] = useState("");
  const [newMl, setNewMl] = useState("");
  const [newIcon, setNewIcon] = useState(ICONS[0]);
  const [manual, setManual] = useState(water.goalOverrideMl !== null);

  const auto = calcWaterGoalMl(profile);
  const goal = effectiveWaterGoal(settings);
  const glass = containers.find((c) => c.id === water.defaultContainerId) ?? containers[0];
  const times = goal !== null && glass ? planWaterTimes(water.wake, water.sleep, glassesNeeded(goal, glass.ml)) : [];

  const setProfile = (patch: Partial<typeof profile>) => updateSettings((s) => ({ ...s, profile: { ...s.profile, ...patch } }));
  const setWater = (patch: Partial<typeof water>) => updateSettings((s) => ({ ...s, water: { ...s.water, ...patch } }));

  const addContainer = () => {
    const ml = parseInt(newMl, 10);
    if (!newName.trim() || !(ml >= 10 && ml <= 5000)) {
      showToast("নাম ও ১০–৫০০০ মি.লি. এর মধ্যে পরিমাণ লিখুন");
      return;
    }
    saveContainer({ id: uid(), name: newName.trim(), ml, icon: newIcon });
    setNewName("");
    setNewMl("");
  };

  const removeContainer = async (id: string, name: string) => {
    if (await confirm({ title: `"${name}" মুছবেন?`, message: "আগের হিসাব ঠিক থাকবে।", confirmText: "মুছুন", danger: true })) deleteContainer(id);
  };

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3">
        <Field label="বয়স (বছর)">
          <NumberInput value={profile.age} onChange={(v) => setProfile({ age: v === null ? null : Math.round(v) })} placeholder="যেমন: ২৫" max={119} />
        </Field>
        <Field label="ওজন (কেজি)">
          <NumberInput value={profile.weightKg} onChange={(v) => setProfile({ weightKg: v })} placeholder="যেমন: ৬৫" max={399} />
        </Field>
      </div>

      <Field label="কাজকর্ম / পরিশ্রম">
        <select className={inputClass} value={profile.activity} onChange={(e) => setProfile({ activity: e.target.value as Activity })}>
          {(Object.keys(ACTIVITY_LABELS) as Activity[]).map((a) => (
            <option key={a} value={a}>
              {ACTIVITY_LABELS[a]}
            </option>
          ))}
        </select>
      </Field>
      <Toggle checked={profile.hotWeather} onChange={(v) => setProfile({ hotWeather: v })} label="গরমের দিন" description="গরমে ঘাম বেশি হয়, তাই আরও ০.৫ লিটার ধরা হয়" />

      <div className="rounded-2xl bg-[var(--color-water)]/10 p-3 text-sm">
        {auto === null && !manual ? (
          <p className="opacity-70">বয়স ও ওজন দিলে লক্ষ্য হিসাব হবে।</p>
        ) : (
          <p>
            আপনার দৈনিক লক্ষ্য: <b>{goal !== null ? formatMl(goal) : "—"}</b>
            {glass && goal !== null && <span className="opacity-70"> (প্রায় {toBn(glassesNeeded(goal, glass.ml))}টি {glass.name})</span>}
          </p>
        )}
        <p className="mt-1 text-[11px] opacity-60">এটি সাধারণ নির্দেশিকা। কিডনি, হার্ট বা অন্য রোগ থাকলে ডাক্তারের পরামর্শ অনুযায়ী চলুন।</p>
      </div>

      <div>
        <Segmented
          value={manual ? "manual" : "auto"}
          onChange={(v) => {
            setManual(v === "manual");
            setWater({ goalOverrideMl: v === "manual" ? (auto ?? 2000) : null });
          }}
          options={[
            { value: "auto", label: "স্বয়ংক্রিয় হিসাব" },
            { value: "manual", label: "নিজে ঠিক করব" },
          ]}
        />
        {manual && (
          <div className="mt-3">
            <Field label="দৈনিক লক্ষ্য (মি.লি.)">
              <NumberInput value={water.goalOverrideMl} onChange={(v) => setWater({ goalOverrideMl: v === null ? null : Math.round(v) })} placeholder="যেমন: ২৫০০" max={8000} />
            </Field>
          </div>
        )}
      </div>

      <div className="space-y-3 rounded-2xl bg-black/[0.03] p-3 dark:bg-white/5">
        <Toggle checked={water.remindersOn} onChange={(v) => setWater({ remindersOn: v })} label="পানি খাওয়ার রিমাইন্ডার" description="জেগে থাকার সময়ের মধ্যে সমান ভাগে নোটিফিকেশন আসবে" />
        <div className="grid grid-cols-2 gap-3">
          <Field label="ঘুম থেকে ওঠা">
            <input type="time" className={inputClass} value={water.wake} onChange={(e) => e.target.value && setWater({ wake: e.target.value })} />
          </Field>
          <Field label="ঘুমাতে যাওয়া">
            <input type="time" className={inputClass} value={water.sleep} onChange={(e) => e.target.value && setWater({ sleep: e.target.value })} />
          </Field>
        </div>
        {water.remindersOn && times.length > 0 && (
          <p className="text-[11px] leading-relaxed opacity-70">রিমাইন্ডারের সময়: {times.map((t) => formatTimeBn(t)).join(" · ")}</p>
        )}
      </div>

      <div>
        <h3 className="mb-2 text-sm font-bold">আমার পাত্র (গ্লাস/বোতল)</h3>
        <p className="mb-2 text-[11px] opacity-60">যেটা ট্যাপ করবেন সেটা রিমাইন্ডারের জন্য ধরা হবে।</p>
        <div className="space-y-2">
          {containers.map((c) => (
            <div key={c.id} className="flex items-center justify-between rounded-2xl bg-white/60 px-3 py-2 dark:bg-white/5">
              <button type="button" onClick={() => setWater({ defaultContainerId: c.id })} className="flex items-center gap-2 text-left text-sm">
                <span>{water.defaultContainerId === c.id ? "🔘" : "⚪"}</span>
                <span>
                  {c.icon} {c.name} · {formatMl(c.ml)}
                </span>
              </button>
              {containers.length > 1 && (
                <button type="button" onClick={() => void removeContainer(c.id, c.name)} aria-label={`${c.name} মুছুন`} className="px-1 text-red-500">
                  ✕
                </button>
              )}
            </div>
          ))}
        </div>
        <div className="mt-3 space-y-2 rounded-2xl border border-dashed border-[var(--color-accent)]/30 p-3">
          <div className="flex flex-wrap gap-2">
            {ICONS.map((i) => (
              <Chip key={i} active={newIcon === i} onClick={() => setNewIcon(i)}>
                {i}
              </Chip>
            ))}
          </div>
          <div className="grid grid-cols-5 gap-2">
            <input className={`${inputClass} col-span-3`} value={newName} onChange={(e) => setNewName(e.target.value.slice(0, 24))} placeholder="নাম (যেমন: মগ)" />
            <input className={`${inputClass} col-span-2`} inputMode="numeric" value={newMl} onChange={(e) => setNewMl(e.target.value.replace(/\D/g, "").slice(0, 4))} placeholder="মি.লি." />
          </div>
          <Button variant="soft" block onClick={addContainer}>
            + নতুন পাত্র যোগ করুন
          </Button>
        </div>
      </div>
    </div>
  );
}
