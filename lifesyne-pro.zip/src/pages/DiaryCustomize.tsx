import { useState } from "react";
import { useConfirm } from "@/components/Feedback";
import AttachmentPicker from "@/components/AttachmentPicker";
import DiaryCover from "@/components/DiaryCover";
import DiaryPaper from "@/components/DiaryPaper";
import { Button, Card, Field, IconPicker, inputClass, PageHeader, SelectField, Segmented } from "@/components/ui";
import type { Attachment, CoverStyle, DiaryFont, DiarySettings, DiaryTextSize, PaperStyle, PaperTone, RelockPolicy } from "@/domain/types";
import { toBn } from "@/lib/bn";
import { createLockRecord, DIARY_PASSWORD_MIN, isValidDiaryPassword, verifyDiaryPassword } from "@/lib/diaryLock";
import { showToast } from "@/lib/toast";
import { updateSettings } from "@/store/actions";
import { useAppData } from "@/store/store";

const COVER_COLORS = ["#5b3a29", "#1f3a5f", "#1e5a46", "#7a1f2b", "#222222", "#0e6b78", "#6b3fa0", "#b0527a", "#8a6d3b", "#3a4a2a"];
const RIBBON_COLORS = ["#c0392b", "#e8a317", "#2b7de9", "#16a05d", "#8e44ad", "#ffffff"];

const RELOCK_OPTIONS: { value: RelockPolicy; label: string }[] = [
  { value: "leave", label: "ডায়েরি থেকে বের হলেই" },
  { value: "1m", label: "বের হওয়ার ১ মিনিট পর" },
  { value: "5m", label: "বের হওয়ার ৫ মিনিট পর" },
  { value: "session", label: "অ্যাপ বন্ধ না হওয়া পর্যন্ত খোলা থাকবে" },
];

export default function DiaryCustomizePage() {
  const { diary } = useAppData().settings;
  const set = (patch: Partial<DiarySettings>) => updateSettings((s) => ({ ...s, diary: { ...s.diary, ...patch } }));
  const setCover = (list: Attachment[]) => set({ coverImage: list[list.length - 1] ?? null });

  return (
    <main className="safe-top px-4 pb-8 pt-6">
      <PageHeader title="ডায়েরি কাস্টমাইজ 🎨" back />

      <div className="mb-6 py-2">
        <DiaryCover diary={diary} width={170} />
      </div>

      <div className="space-y-5">
        <Card className="space-y-4">
          <h2 className="font-bold">📕 কভার</h2>
          <Field label="ডায়েরির নাম">
            <input className={inputClass} value={diary.title} maxLength={40} onChange={(e) => set({ title: e.target.value })} />
          </Field>
          <Field label="নিচের লেখা (যেমন: আপনার নাম, সাল)">
            <input className={inputClass} value={diary.subtitle} maxLength={50} onChange={(e) => set({ subtitle: e.target.value })} />
          </Field>
          <div>
            <p className="mb-1.5 text-xs font-semibold opacity-70">প্রতীক</p>
            <IconPicker value={diary.emblem} onChange={(emblem) => set({ emblem })} />
          </div>
          <div>
            <p className="mb-1.5 text-xs font-semibold opacity-70">কভারের ধরন</p>
            <Segmented<CoverStyle>
              value={diary.coverStyle}
              onChange={(coverStyle) => set({ coverStyle })}
              options={[
                { value: "leather", label: "চামড়া" },
                { value: "cloth", label: "কাপড়" },
                { value: "plain", label: "সাদামাটা" },
              ]}
            />
          </div>
          <div>
            <p className="mb-1.5 text-xs font-semibold opacity-70">কভারের রং</p>
            <div className="flex flex-wrap items-center gap-2.5">
              {COVER_COLORS.map((c) => (
                <button key={c} type="button" aria-label={`রং ${c}`} onClick={() => set({ coverColor: c })} className={`h-8 w-8 rounded-full ${diary.coverColor === c ? "ring-2 ring-offset-2 ring-[var(--color-ink)] dark:ring-white" : ""}`} style={{ backgroundColor: c }} />
              ))}
              <input type="color" value={diary.coverColor} onChange={(e) => set({ coverColor: e.target.value })} aria-label="নিজের পছন্দের রং" className="h-8 w-10 rounded" />
            </div>
          </div>
          <div>
            <p className="mb-1.5 text-xs font-semibold opacity-70">বুকমার্ক ফিতার রং</p>
            <div className="flex gap-2.5">
              {RIBBON_COLORS.map((c) => (
                <button key={c} type="button" aria-label={`ফিতা ${c}`} onClick={() => set({ ribbon: c })} className={`h-7 w-7 rounded-full border border-black/10 ${diary.ribbon === c ? "ring-2 ring-offset-2 ring-[var(--color-ink)] dark:ring-white" : ""}`} style={{ backgroundColor: c }} />
              ))}
            </div>
          </div>
          <div>
            <p className="mb-1.5 text-xs font-semibold opacity-70">কভারে নিজের ছবি</p>
            <AttachmentPicker value={diary.coverImage ? [diary.coverImage] : []} onChange={setCover} imagesOnly max={1} />
            <p className="mt-1 text-[11px] opacity-60">ছবি Cloudinary-তে জমা হয় (সেটিংসে Cloudinary দেওয়া থাকলে)। কভারের ছবি লক ছাড়াই দেখা যায়, তাই ব্যক্তিগত ছবি না দেওয়াই ভালো।</p>
          </div>
        </Card>

        <PaperCard diary={diary} set={set} />
        <LockCard diary={diary} set={set} />
      </div>
    </main>
  );
}

function PaperCard({ diary, set }: { diary: DiarySettings; set: (p: Partial<DiarySettings>) => void }) {
  return (
    <Card className="space-y-4">
      <h2 className="font-bold">📄 কাগজ ও লেখা</h2>
      <DiaryPaper diary={diary} className="pb-3">
        <p className="paper-text">আজ মনটা বেশ ভালো ছিল।</p>
        <p className="paper-text">এভাবেই পাতায় লেখা দেখাবে।</p>
      </DiaryPaper>
      <div>
        <p className="mb-1.5 text-xs font-semibold opacity-70">পাতার ধরন</p>
        <Segmented<PaperStyle>
          value={diary.paper}
          onChange={(paper) => set({ paper })}
          options={[
            { value: "ruled", label: "লাইন" },
            { value: "dotted", label: "ডট" },
            { value: "grid", label: "গ্রিড" },
            { value: "plain", label: "সাদা" },
          ]}
        />
      </div>
      <div>
        <p className="mb-1.5 text-xs font-semibold opacity-70">কাগজের রং (ডার্ক মোডে অন্ধকার কাগজ আসে)</p>
        <Segmented<PaperTone>
          value={diary.paperTone}
          onChange={(paperTone) => set({ paperTone })}
          options={[
            { value: "cream", label: "ক্রিম" },
            { value: "white", label: "সাদা" },
            { value: "yellow", label: "হলুদ" },
          ]}
        />
      </div>
      <div>
        <p className="mb-1.5 text-xs font-semibold opacity-70">হাতের লেখার ধরন</p>
        <Segmented<DiaryFont>
          value={diary.font}
          onChange={(font) => set({ font })}
          options={[
            { value: "hand", label: "হাতের লেখা" },
            { value: "script", label: "কলমের লেখা" },
            { value: "serif", label: "ছাপার ধাঁচ" },
          ]}
        />
      </div>
      <div>
        <p className="mb-1.5 text-xs font-semibold opacity-70">লেখার সাইজ</p>
        <Segmented<DiaryTextSize>
          value={diary.textSize}
          onChange={(textSize) => set({ textSize })}
          options={[
            { value: "sm", label: "ছোট" },
            { value: "md", label: "মাঝারি" },
            { value: "lg", label: "বড়" },
          ]}
        />
      </div>
    </Card>
  );
}

type LockMode = "idle" | "set" | "change" | "remove";

function LockCard({ diary, set }: { diary: DiarySettings; set: (p: Partial<DiarySettings>) => void }) {
  const confirm = useConfirm();
  const [mode, setMode] = useState<LockMode>("idle");
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [again, setAgain] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const lock = diary.lock;

  const reset = () => {
    setMode("idle");
    setCurrent("");
    setNext("");
    setAgain("");
    setError("");
  };

  const submit = async () => {
    setError("");
    setBusy(true);
    try {
      if (lock && (mode === "change" || mode === "remove")) {
        const check = await verifyDiaryPassword(lock, current);
        if (!check.ok) return setError(check.waitMs > 0 ? `কিছুক্ষণ পরে চেষ্টা করুন (${toBn(Math.ceil(check.waitMs / 1000))} সেকেন্ড)` : "বর্তমান পাসওয়ার্ড সঠিক নয়");
      }
      if (mode === "remove") {
        set({ lock: null });
        showToast("🔓 ডায়েরি লক বন্ধ হয়েছে");
        return reset();
      }
      if (!isValidDiaryPassword(next)) return setError(`কমপক্ষে ${toBn(DIARY_PASSWORD_MIN)} অক্ষরের পাসওয়ার্ড দিন`);
      if (next !== again) return setError("দুটি পাসওয়ার্ড মিলছে না");
      set({ lock: await createLockRecord(next) });
      showToast("🔒 ডায়েরির পাসওয়ার্ড সেট হয়েছে");
      reset();
    } catch {
      setError("সেভ করা যায়নি, আবার চেষ্টা করুন");
    } finally {
      setBusy(false);
    }
  };

  const confirmRemove = async () => {
    if (await confirm({ title: "ডায়েরির লক বন্ধ করবেন?", message: "এরপর ডায়েরি পাসওয়ার্ড ছাড়াই খুলবে।", confirmText: "এগিয়ে যান", danger: true })) setMode("remove");
  };

  return (
    <Card className="space-y-4">
      <div>
        <h2 className="font-bold">🔒 ডায়েরির আলাদা পাসওয়ার্ড</h2>
        <p className="mt-1 text-[11px] opacity-60">অ্যাপ লক না থাকলেও এটি আলাদাভাবে কাজ করে। পাসওয়ার্ড ভুলে গেলে লগইনের (Firebase অ্যাকাউন্টের) পাসওয়ার্ড দিয়ে খোলা যাবে। ডায়েরির লেখা, ভল্ট, পাসওয়ার্ড ও হিসাব সবই এই লকের আড়ালে থাকে।</p>
      </div>

      {lock && (
        <Field label="কখন আবার লক হবে?">
          <SelectField value={diary.relock} onChange={(relock) => set({ relock })} options={RELOCK_OPTIONS} />
        </Field>
      )}

      {mode === "idle" ? (
        lock ? (
          <div className="grid grid-cols-2 gap-2">
            <Button variant="ghost" onClick={() => setMode("change")}>
              পাসওয়ার্ড বদলান
            </Button>
            <Button variant="danger" onClick={() => void confirmRemove()}>
              লক বন্ধ করুন
            </Button>
          </div>
        ) : (
          <Button block onClick={() => setMode("set")}>
            🔒 ডায়েরিতে পাসওয়ার্ড দিন
          </Button>
        )
      ) : (
        <div className="space-y-2">
          {(mode === "change" || mode === "remove") && <input type="password" className={inputClass} value={current} onChange={(e) => setCurrent(e.target.value)} placeholder="বর্তমান পাসওয়ার্ড" />}
          {mode !== "remove" && (
            <>
              <input type="password" className={inputClass} value={next} onChange={(e) => setNext(e.target.value)} placeholder={`নতুন পাসওয়ার্ড (কমপক্ষে ${toBn(DIARY_PASSWORD_MIN)} অক্ষর)`} />
              <input type="password" className={inputClass} value={again} onChange={(e) => setAgain(e.target.value)} placeholder="আবার লিখুন" />
            </>
          )}
          {error && <p className="text-xs font-medium text-red-500">{error}</p>}
          <div className="flex gap-2">
            <Button variant="ghost" block onClick={reset}>
              বাতিল
            </Button>
            <Button block disabled={busy} onClick={() => void submit()}>
              {mode === "remove" ? "লক বন্ধ করুন" : "সংরক্ষণ"}
            </Button>
          </div>
        </div>
      )}
    </Card>
  );
}
