import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import AgendaRow from "@/components/AgendaRow";
import { useConfirm } from "@/components/Feedback";
import PermissionBanner from "@/components/PermissionBanner";
import { Button, Card, Chip, EmptyState, PageHeader, Segmented } from "@/components/ui";
import { habitLogMap, habitStats, isScheduled } from "@/domain/habits";
import { countdownLabel, describeSchedule, nextDate } from "@/domain/schedule";
import { buildAgenda } from "@/domain/today";
import type { Habit, Reminder } from "@/domain/types";
import { toBn } from "@/lib/bn";
import { dateKey, nowMinutes } from "@/lib/date";
import { useNow } from "@/lib/useNow";
import { changeHabitCount, deleteHabit, deleteReminder, setHabitArchived, setReminderActive } from "@/store/actions";
import { useAppData } from "@/store/store";

type Tab = "today" | "reminders" | "habits";
const STYLE_ICON = { normal: "🔔", chime: "🎵", alarm: "⏰" } as const;

export default function RemindersPage() {
  const [tab, setTab] = useState<Tab>("today");
  return (
    <main className="safe-top px-4 pt-6">
      <PageHeader title="রিমাইন্ডার ও অভ্যাস" />
      <PermissionBanner />
      <div className="mb-4 grid grid-cols-2 gap-2">
        <Link to="/reminders/new" className="rounded-2xl bg-[var(--color-accent)] px-3 py-3 text-center text-sm font-semibold text-white shadow-md active:scale-[0.98]">
          ⏰ নতুন রিমাইন্ডার
        </Link>
        <Link to="/habits/new" className="rounded-2xl bg-[var(--color-accent)]/12 px-3 py-3 text-center text-sm font-semibold text-[var(--color-accent)] active:scale-[0.98]">
          🔁 নতুন অভ্যাস
        </Link>
      </div>
      <div className="mb-4">
        <Segmented
          value={tab}
          onChange={setTab}
          options={[
            { value: "today", label: "আজকের সূচি" },
            { value: "reminders", label: "রিমাইন্ডার" },
            { value: "habits", label: "অভ্যাস" },
          ]}
        />
      </div>
      {tab === "today" && <TodayTab />}
      {tab === "reminders" && <ReminderListTab />}
      {tab === "habits" && <HabitsTab />}
    </main>
  );
}

function TodayTab() {
  const data = useAppData();
  const now = useNow();
  const items = useMemo(() => buildAgenda(data, dateKey(now), nowMinutes(now)), [data, now]);

  if (items.length === 0) return <EmptyState icon="🌿" title="আজ কিছু নির্ধারিত নেই" text="রিমাইন্ডার, অভ্যাস বা ওষুধ যোগ করলে এখানে আজকের পুরো সূচি দেখা যাবে।" />;
  return (
    <div className="space-y-2">
      {items.map((i) => (
        <AgendaRow key={`${i.kind}:${i.key}`} item={i} />
      ))}
    </div>
  );
}

function ReminderListTab() {
  const { reminders, settings } = useAppData();
  const confirm = useConfirm();
  const [cat, setCat] = useState<string | null>(null);
  const today = dateKey(useNow(60_000));

  const shown = useMemo(() => {
    const list = reminders.filter((r) => !cat || r.categoryId === cat);
    return list
      .map((r) => ({ r, next: r.active ? nextDate(r, today) : null }))
      .sort((a, b) => (a.next ?? "9999").localeCompare(b.next ?? "9999") || a.r.title.localeCompare(b.r.title, "bn"));
  }, [reminders, cat, today]);

  if (reminders.length === 0) return <EmptyState icon="⏰" title="এখনও কোনো রিমাইন্ডার নেই" text="জন্মদিন, বিল, মিটিং, অ্যালার্ম — যেকোনো কিছুর রিমাইন্ডার নিজের মতো করে বানান।" />;

  const remove = async (r: Reminder) => {
    if (await confirm({ title: `"${r.title}" মুছবেন?`, confirmText: "মুছুন", danger: true })) deleteReminder(r.id);
  };

  return (
    <>
      <div className="mb-4 flex gap-2 overflow-x-auto pb-1">
        <Chip active={cat === null} onClick={() => setCat(null)}>
          সব
        </Chip>
        {settings.categories.map((c) => (
          <Chip key={c.id} active={cat === c.id} onClick={() => setCat((p) => (p === c.id ? null : c.id))}>
            {c.icon} {c.name}
          </Chip>
        ))}
      </div>
      <div className="space-y-3">
        {shown.map(({ r, next }) => (
          <Card key={r.id} className={r.active ? "" : "opacity-60"}>
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="font-bold">
                  {r.icon} {r.title} <span className="text-xs">{STYLE_ICON[r.style]}</span>
                </p>
                <p className="mt-0.5 text-xs opacity-70">{describeSchedule(r)}</p>
                {r.earlyMin > 0 && <p className="text-[11px] opacity-50">আগাম সতর্কতা: {r.earlyMin === 1440 ? "১ দিন আগে" : `${toBn(r.earlyMin)} মিনিট আগে`}</p>}
                <p className="mt-1 text-xs font-semibold text-[var(--color-accent)]">
                  {!r.active ? "বিরতিতে আছে" : next ? `পরেরবার: ${countdownLabel(today, next)}` : "আর কোনো তারিখ নেই (শেষ)"}
                </p>
              </div>
            </div>
            <div className="mt-3 flex gap-2">
              <Link to={`/reminders/${r.id}/edit`} className="rounded-full bg-black/5 px-3 py-1.5 text-xs font-semibold dark:bg-white/10">
                ✏️ এডিট
              </Link>
              <Button variant="ghost" className="!rounded-full !px-3 !py-1.5 !text-xs" onClick={() => setReminderActive(r.id, !r.active)}>
                {r.active ? "⏸ বিরতি" : "▶️ চালু করুন"}
              </Button>
              <Button variant="danger" className="!rounded-full !px-3 !py-1.5 !text-xs" onClick={() => void remove(r)}>
                🗑️
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </>
  );
}

const DOT: Record<string, string> = { done: "bg-green-500", missed: "bg-red-400/70", off: "bg-black/10 dark:bg-white/10", pending: "bg-amber-400" };

function HabitsTab() {
  const { habits, habitLogs } = useAppData();
  const confirm = useConfirm();
  const today = dateKey(useNow(60_000));
  const counts = useMemo(() => habitLogMap(habitLogs), [habitLogs]);
  const [showArchived, setShowArchived] = useState(false);

  const active = habits.filter((h) => !h.archived);
  const archived = habits.filter((h) => h.archived);
  if (habits.length === 0) return <EmptyState icon="🔁" title="এখনও কোনো অভ্যাস নেই" text="রোজ ব্যায়াম, বই পড়া, পানি পান — অভ্যাস তৈরি করুন, ধারাবাহিকতা (streak) দেখুন।" />;

  const remove = async (h: Habit) => {
    if (await confirm({ title: `"${h.name}" মুছবেন?`, message: "এর সব ইতিহাসও মুছে যাবে।", confirmText: "মুছুন", danger: true })) deleteHabit(h.id);
  };

  const card = (h: Habit) => {
    const stats = habitStats(h, counts, today);
    const count = counts.get(`${h.id}|${today}`) ?? 0;
    const scheduled = isScheduled(h, today);
    return (
      <Card key={h.id} className={h.archived ? "opacity-60" : ""}>
        <div className="flex items-center justify-between gap-2">
          <p className="min-w-0 truncate font-bold">
            {h.icon} {h.name}
          </p>
          <span className="shrink-0 text-xs font-semibold" style={{ color: h.color }}>
            🔥 {toBn(stats.streak)} দিন
          </span>
        </div>
        <p className="mt-0.5 text-[11px] opacity-60">
          সেরা: {toBn(stats.best)} দিন{stats.rate30 !== null ? ` · গত ৩০ দিনে ${toBn(stats.rate30)}%` : ""}
        </p>
        <div className="mt-2 flex gap-1">
          {stats.last14.map((d) => (
            <span key={d.date} title={d.date} className={`h-3 flex-1 rounded-sm ${DOT[d.state]}`} />
          ))}
        </div>
        {!h.archived && scheduled && (
          <div className="mt-3 flex items-center gap-2">
            <button type="button" className="rounded-full bg-black/5 px-3 py-1 text-sm font-bold dark:bg-white/10" disabled={count === 0} onClick={() => changeHabitCount(h.id, today, -1)} aria-label="কমান">
              −
            </button>
            <span className="min-w-12 text-center text-sm font-bold">
              {toBn(count)}/{toBn(h.target)}
            </span>
            <button type="button" className="flex-1 rounded-full px-3 py-1.5 text-xs font-semibold text-white active:scale-95" style={{ backgroundColor: h.color }} onClick={() => changeHabitCount(h.id, today, 1)}>
              ✅ আজ করেছি
            </button>
          </div>
        )}
        {!scheduled && !h.archived && <p className="mt-2 text-[11px] opacity-50">আজ এই অভ্যাসের দিন নয়।</p>}
        <div className="mt-3 flex gap-2">
          <Link to={`/habits/${h.id}/edit`} className="rounded-full bg-black/5 px-3 py-1.5 text-xs font-semibold dark:bg-white/10">
            ✏️ এডিট
          </Link>
          <Button variant="ghost" className="!rounded-full !px-3 !py-1.5 !text-xs" onClick={() => setHabitArchived(h.id, !h.archived)}>
            {h.archived ? "↩︎ ফিরিয়ে আনুন" : "📦 আর্কাইভ"}
          </Button>
          <Button variant="danger" className="!rounded-full !px-3 !py-1.5 !text-xs" onClick={() => void remove(h)}>
            🗑️
          </Button>
        </div>
      </Card>
    );
  };

  return (
    <div className="space-y-3">
      {active.map(card)}
      {archived.length > 0 && (
        <>
          <button type="button" onClick={() => setShowArchived((v) => !v)} className="w-full pt-2 text-center text-xs font-semibold text-[var(--color-accent)]">
            {showArchived ? "আর্কাইভ লুকান" : `আর্কাইভ করা ${toBn(archived.length)}টি দেখুন`}
          </button>
          {showArchived && archived.map(card)}
        </>
      )}
    </div>
  );
}
