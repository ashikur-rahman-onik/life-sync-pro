import { useState } from "react";
import { useNavigate } from "react-router-dom";
import MoodPicker from "@/components/MoodPicker";
import { Button, inputClass } from "@/components/ui";
import { todayKey } from "@/lib/date";
import { parseTags } from "@/lib/tags";
import { addEntry } from "@/store/actions";

export default function NewEntryPage() {
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [mood, setMood] = useState("neutral");
  const [tags, setTags] = useState("");
  const [entryDate, setEntryDate] = useState(todayKey());
  const [error, setError] = useState("");

  const save = () => {
    if (!content.trim()) {
      setError("কিছু একটা লিখুন প্রথমে 🙂");
      return;
    }
    const id = addEntry({ title: title.trim(), content: content.trim(), mood, tags: parseTags(tags), entryDate: entryDate || todayKey() });
    navigate(`/entry/${id}`, { replace: true });
  };

  return (
    <main className="safe-top px-4 pb-8 pt-6">
      <header className="mb-5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button type="button" onClick={() => (window.history.length > 1 ? navigate(-1) : navigate("/"))} aria-label="ফিরে যান" className="-ml-1 rounded-full px-2 py-1 text-xl opacity-70 active:scale-90">
            ←
          </button>
          <h1 className="text-xl font-bold">নতুন এন্ট্রি ✍️</h1>
        </div>
        <input type="date" value={entryDate} max={todayKey()} onChange={(e) => setEntryDate(e.target.value)} className="rounded-xl border border-[var(--color-accent)]/20 bg-white/70 px-2.5 py-1.5 text-xs dark:bg-white/5" />
      </header>

      <div className="mb-4">
        <MoodPicker value={mood} onChange={setMood} />
      </div>
      <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="শিরোনাম (ঐচ্ছিক)" className={`${inputClass} mb-3 font-medium`} />
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="আজকের অনুভূতি, ঘটনা বা মনের কথা লিখুন..."
        rows={10}
        className={`${inputClass} resize-none text-base leading-relaxed`}
      />
      <input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="ট্যাগ (কমা দিয়ে ভাগ করুন, যেমন: পরিবার, কাজ)" className={`${inputClass} mt-3`} />
      {error && <p className="mt-3 text-sm font-medium text-red-500">{error}</p>}
      <Button block className="mt-5 py-3.5" onClick={save}>
        💾 এন্ট্রি সেভ করুন
      </Button>
    </main>
  );
}
