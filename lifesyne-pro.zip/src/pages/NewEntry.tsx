import { useNavigate } from "react-router-dom";
import EntryEditor from "@/components/EntryEditor";
import { addEntry } from "@/store/actions";

export default function NewEntryPage() {
  const navigate = useNavigate();
  return (
    <main className="safe-top px-4 pb-8 pt-6">
      <header className="mb-4 flex items-center gap-2">
        <button type="button" onClick={() => (window.history.length > 1 ? navigate(-1) : navigate("/diary"))} aria-label="ফিরে যান" className="-ml-1 rounded-full px-2 py-1 text-xl opacity-70 active:scale-90">
          ←
        </button>
        <h1 className="text-xl font-bold">নতুন পাতা ✍️</h1>
      </header>
      <EntryEditor saveLabel="💾 পাতাটি সেভ করুন" onSave={(values) => navigate(`/entry/${addEntry(values)}`, { replace: true })} />
    </main>
  );
}
