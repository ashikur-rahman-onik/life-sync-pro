import { useMemo, useState } from "react";
import AttachmentPicker from "@/components/AttachmentPicker";
import { useConfirm } from "@/components/Feedback";
import { Button, Chip, EmptyState, Field, inputClass, Modal, PageHeader } from "@/components/ui";
import { formatBytes } from "@/domain/attachments";
import type { Attachment, VaultItem } from "@/domain/types";
import { tagOf, VAULT_TAGS } from "@/domain/vaultMeta";
import { formatDateBn, toBn } from "@/lib/bn";
import { showToast } from "@/lib/toast";
import { useUploadStatus } from "@/media/uploader";
import { deleteVaultItem, saveVaultItem } from "@/store/actions";
import { useAppData } from "@/store/store";

export default function VaultPage() {
  const { vault } = useAppData();
  const upload = useUploadStatus();
  const [search, setSearch] = useState("");
  const [tag, setTag] = useState<string | null>(null);
  const [editing, setEditing] = useState<VaultItem | "new" | null>(null);

  const shown = useMemo(() => {
    const q = search.trim().toLowerCase();
    return vault.filter((v) => (!tag || v.tag === tag) && (!q || v.title.toLowerCase().includes(q) || v.note.toLowerCase().includes(q)));
  }, [vault, search, tag]);

  const total = vault.reduce((sum, v) => sum + v.attachments.reduce((s, a) => s + a.bytes, 0), 0);

  return (
    <main className="safe-top px-4 pb-6 pt-6">
      <PageHeader title="ভল্ট 🗂️" back right={<Button className="!px-3 !py-2" onClick={() => setEditing("new")}>+ যোগ</Button>} />
      <p className="mb-3 text-[11px] opacity-60">
        ডকুমেন্ট, ছবি, ফাইল আর গোপন নোট। ফাইল Cloudinary-তে জমা হয় · মোট {formatBytes(total)}
        {upload.pending > 0 && ` · ⏳ ${toBn(upload.pending)}টি আপলোড বাকি`}
      </p>
      <input className={`${inputClass} mb-3`} value={search} onChange={(e) => setSearch(e.target.value)} placeholder="🔍 খুঁজুন..." />
      <div className="mb-4 flex gap-2 overflow-x-auto pb-1">
        <Chip active={tag === null} onClick={() => setTag(null)}>
          সব
        </Chip>
        {VAULT_TAGS.map((t) => (
          <Chip key={t.id} active={tag === t.id} onClick={() => setTag((p) => (p === t.id ? null : t.id))}>
            {t.icon} {t.name}
          </Chip>
        ))}
      </div>

      {shown.length === 0 ? (
        <EmptyState icon="🗂️" title={vault.length === 0 ? "ভল্ট এখনও খালি" : "কিছু পাওয়া যায়নি"} text={vault.length === 0 ? "আইডি কার্ড, সার্টিফিকেট, ব্যাংকের কাগজ, ছবি বা যেকোনো ফাইল এখানে নিরাপদে রাখুন।" : undefined} />
      ) : (
        <div className="space-y-3">
          {shown.map((v) => {
            const t = tagOf(VAULT_TAGS, v.tag);
            return (
              <button key={v.id} type="button" onClick={() => setEditing(v)} className="block w-full rounded-2xl border border-[var(--color-accent)]/15 bg-white/70 p-4 text-left shadow-sm active:scale-[0.99] dark:bg-white/5">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate font-bold">
                    {t.icon} {v.title}
                  </p>
                  <span className="shrink-0 text-[10px] opacity-50">{formatDateBn(v.updatedAt.slice(0, 10))}</span>
                </div>
                {v.note && <p className="mt-1 line-clamp-2 text-xs opacity-70">{v.note}</p>}
                {v.attachments.length > 0 && (
                  <p className="mt-1.5 text-[11px] opacity-60">
                    📎 {toBn(v.attachments.length)}টি · {v.attachments.some((a) => a.url === null) ? "⏳ আপলোড বাকি" : "☁️ জমা আছে"}
                  </p>
                )}
              </button>
            );
          })}
        </div>
      )}

      <Modal open={editing !== null} onClose={() => setEditing(null)} title={editing === "new" ? "নতুন আইটেম" : "আইটেম"}>
        {editing !== null && <VaultForm key={editing === "new" ? "new" : editing.id} item={editing === "new" ? null : editing} onClose={() => setEditing(null)} />}
      </Modal>
    </main>
  );
}

function VaultForm({ item, onClose }: { item: VaultItem | null; onClose: () => void }) {
  const confirm = useConfirm();
  const [title, setTitle] = useState(item?.title ?? "");
  const [note, setNote] = useState(item?.note ?? "");
  const [tag, setTag] = useState(item?.tag ?? VAULT_TAGS[0].id);
  const [attachments, setAttachments] = useState<Attachment[]>(item?.attachments ?? []);

  const save = () => {
    if (!title.trim()) return showToast("একটা নাম দিন");
    saveVaultItem(item?.id ?? null, { title: title.trim(), note: note.trim(), tag, attachments });
    showToast("✅ ভল্টে সংরক্ষিত");
    onClose();
  };

  const remove = async () => {
    if (!item) return;
    if (await confirm({ title: `"${item.title}" মুছবেন?`, message: "ক্লাউডে আপলোড করা ফাইলের লিংকও এই অ্যাপ থেকে সরে যাবে।", confirmText: "মুছুন", danger: true })) {
      deleteVaultItem(item.id);
      onClose();
    }
  };

  return (
    <div className="space-y-4 pb-2">
      <Field label="নাম">
        <input className={inputClass} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="যেমন: জাতীয় পরিচয়পত্র" />
      </Field>
      <div className="flex flex-wrap gap-2">
        {VAULT_TAGS.map((t) => (
          <Chip key={t.id} active={tag === t.id} onClick={() => setTag(t.id)}>
            {t.icon} {t.name}
          </Chip>
        ))}
      </div>
      <Field label="নোট (ঐচ্ছিক)">
        <textarea className={`${inputClass} min-h-24 resize-y`} value={note} onChange={(e) => setNote(e.target.value)} placeholder="যেকোনো তথ্য, নম্বর বা মনে রাখার কথা" />
      </Field>
      <div>
        <span className="mb-1 block text-xs font-semibold opacity-70">ছবি ও ফাইল</span>
        <AttachmentPicker value={attachments} onChange={setAttachments} />
      </div>
      <div className="flex gap-2 pt-1">
        {item && (
          <Button variant="danger" onClick={() => void remove()}>
            🗑️
          </Button>
        )}
        <Button block onClick={save}>
          💾 সংরক্ষণ করুন
        </Button>
      </div>
    </div>
  );
}
