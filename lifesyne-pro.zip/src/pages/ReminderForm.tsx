import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button, Chip, EmptyState, Field, IconPicker, inputClass, Modal, SelectField, Stepper, StylePicker, TimeListField, WeekdayPicker } from "@/components/ui";
import { REMINDER_TEMPLATES } from "@/domain/templates";
import { REPEAT_LABELS } from "@/domain/schedule";
import type { Reminder, RepeatType } from "@/domain/types";
import { toBn } from "@/lib/bn";
import { addDays, timeToMinutes, todayKey } from "@/lib/date";
import { uid } from "@/lib/id";
import { showToast } from "@/lib/toast";
import { sendTestNotification } from "@/native/notifications";
import { saveCategory, saveReminder } from "@/store/actions";
import { useAppData } from "@/store/store";

const SNOOZE_OPTIONS = [5, 10, 15, 30, 60].map((v) => ({ value: v, label: `${toBn(v)} মিনিট পরে` }));
const EARLY_OPTIONS = [
  { value: 0, label: "লাগবে না" },
  ...[5, 10, 15, 30, 60, 120].map((v) => ({ value: v, label: `${toBn(v)} মিনিট আগে` })),
  { value: 1440, label: "১ দিন আগে" },
];
const TYPES = Object.keys(REPEAT_LABELS) as RepeatType[];

function dateLabel(type: RepeatType): string {
  if (type === "once") return "কোন তারিখে";
  if (type === "yearly") return "কোন তারিখে (প্রতি বছর)";
  if (type === "monthly") return "যে তারিখে (প্রতি মাসের ওই দিনে)";
  return "শুরুর তারিখ";
}

export function validateReminder(r: Reminder, now: Date = new Date()): string | null {
  if (!r.title.trim()) return "রিমাইন্ডারের নাম লিখুন";
  if (r.times.length === 0) return "কমপক্ষে একটি সময় দিন";
  if (r.type === "once") {
    const [y, m, d] = r.date.split("-").map(Number);
    const latest = Math.max(...r.times.map(timeToMinutes));
    if (new Date(y, m - 1, d, Math.floor(latest / 60), latest % 60).getTime() <= now.getTime()) return "অতীতের সময় দেওয়া যাবে না — ভবিষ্যতের তারিখ/সময় দিন";
  }
  if (r.endDate !== null && r.endDate < r.date) return "শেষের তারিখ শুরুর আগে হতে পারে না";
  return null;
}

export default function ReminderFormPage() {
  const { id } = useParams<{ id: string }>();
  const data = useAppData();
  const navigate = useNavigate();
  const existing = id ? data.reminders.find((r) => r.id === id) : undefined;

  if (id && !existing) {
    return (
      <main className="safe-top px-4 pt-10">
        <EmptyState icon="🔍" title="রিমাইন্ডারটি পাওয়া যায়নি" />
        <Button variant="soft" block onClick={() => navigate("/reminders", { replace: true })}>
          ← ফিরে যান
        </Button>
      </main>
    );
  }
  return <Form key={id ?? "new"} initial={existing} />;
}

function Form({ initial }: { initial?: Reminder }) {
  const navigate = useNavigate();
  const { settings } = useAppData();
  const [r, setR] = useState<Reminder>(
    () =>
      initial ?? {
        id: uid(),
        title: "",
        note: "",
        icon: "⏰",
        categoryId: settings.categories[0]?.id ?? "personal",
        type: "once",
        date: todayKey(),
        times: ["09:00"],
        weekdays: [],
        intervalDays: 2,
        endDate: null,
        style: settings.notify.reminderStyle,
        snoozeMin: 10,
        earlyMin: 0,
        active: true,
        createdAt: new Date().toISOString(),
      },
  );
  const [catOpen, setCatOpen] = useState(false);
  const [catName, setCatName] = useState("");
  const [catIcon, setCatIcon] = useState("📌");
  const set = (patch: Partial<Reminder>) => setR((prev) => ({ ...prev, ...patch }));

  const addCategory = () => {
    if (!catName.trim()) return showToast("ক্যাটাগরির নাম লিখুন");
    const id = uid();
    saveCategory({ id, name: catName.trim(), icon: catIcon || "📌" });
    set({ categoryId: id });
    setCatName("");
    setCatOpen(false);
  };

  const save = () => {
    const clean = { ...r, title: r.title.trim(), note: r.note.trim() };
    const problem = validateReminder(clean);
    if (problem) return showToast(problem);
    saveReminder(clean);
    showToast(initial ? "✅ রিমাইন্ডার আপডেট হয়েছে" : "✅ রিমাইন্ডার সেট হয়েছে");
    navigate("/reminders", { replace: true });
  };

  return (
    <main className="safe-top px-4 pb-28 pt-6">
      <header className="mb-5 flex items-center gap-2">
        <button type="button" onClick={() => (window.history.length > 1 ? navigate(-1) : navigate("/reminders"))} aria-label="ফিরে যান" className="-ml-1 rounded-full px-2 py-1 text-xl opacity-70 active:scale-90">
          ←
        </button>
        <h1 className="text-xl font-bold">{initial ? "রিমাইন্ডার এডিট" : "নতুন রিমাইন্ডার"} ⏰</h1>
      </header>

      <div className="space-y-4">
        {!initial && (
          <div>
            <span className="mb-1.5 block text-xs font-semibold opacity-70">দ্রুত শুরু (টেমপ্লেট)</span>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {REMINDER_TEMPLATES.map((t) => (
                <Chip key={t.label} active={false} onClick={() => set({ ...t.patch, date: todayKey(), weekdays: t.patch.weekdays ?? [] })}>
                  {t.label}
                </Chip>
              ))}
            </div>
          </div>
        )}

        <Field label="কী মনে করাতে হবে?">
          <input className={inputClass} value={r.title} onChange={(e) => set({ title: e.target.value })} placeholder="যেমন: বিদ্যুৎ বিল দেওয়া" />
        </Field>
        <div>
          <span className="mb-1.5 block text-xs font-semibold opacity-70">আইকন</span>
          <IconPicker value={r.icon} onChange={(icon) => set({ icon })} />
        </div>

        <div>
          <span className="mb-1.5 block text-xs font-semibold opacity-70">ক্যাটাগরি</span>
          <div className="flex flex-wrap gap-2">
            {settings.categories.map((c) => (
              <Chip key={c.id} active={r.categoryId === c.id} onClick={() => set({ categoryId: c.id })}>
                {c.icon} {c.name}
              </Chip>
            ))}
            <Chip active={false} onClick={() => setCatOpen(true)}>
              + নতুন
            </Chip>
          </div>
        </div>

        <div>
          <span className="mb-1.5 block text-xs font-semibold opacity-70">কতবার?</span>
          <div className="flex flex-wrap gap-2">
            {TYPES.map((t) => (
              <Chip key={t} active={r.type === t} onClick={() => set({ type: t, endDate: t === "once" ? null : r.endDate })}>
                {REPEAT_LABELS[t]}
              </Chip>
            ))}
          </div>
        </div>

        <Field label={dateLabel(r.type)}>
          <input type="date" className={inputClass} value={r.date} onChange={(e) => e.target.value && set({ date: e.target.value })} />
        </Field>
        {r.type === "weekly" && (
          <div>
            <span className="mb-1.5 block text-xs font-semibold opacity-70">কোন কোন বার? (বাছাই না করলে শুরুর তারিখের বার)</span>
            <WeekdayPicker value={r.weekdays} onChange={(weekdays) => set({ weekdays })} />
          </div>
        )}
        {r.type === "interval" && (
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">প্রতি কত দিন পরপর</span>
            <Stepper value={r.intervalDays} onChange={(intervalDays) => set({ intervalDays })} min={2} max={365} format={(v) => `${toBn(v)} দিন`} />
          </div>
        )}

        <div>
          <span className="mb-1.5 block text-xs font-semibold opacity-70">সময় (একাধিক দেওয়া যায়)</span>
          <TimeListField value={r.times} onChange={(times) => set({ times })} min={1} />
        </div>

        {r.type !== "once" && (
          <div>
            <label className="flex items-center gap-2 text-sm font-medium">
              <input type="checkbox" checked={r.endDate !== null} onChange={(e) => set({ endDate: e.target.checked ? addDays(r.date, 30) : null })} />
              শেষের তারিখ আছে
            </label>
            {r.endDate !== null && <input type="date" className={`${inputClass} mt-2`} value={r.endDate} min={r.date} onChange={(e) => e.target.value && set({ endDate: e.target.value })} />}
          </div>
        )}

        <div>
          <span className="mb-1.5 block text-xs font-semibold opacity-70">কীভাবে জানাবে?</span>
          <StylePicker value={r.style} onChange={(style) => set({ style })} onTest={(s) => void sendTestNotification(s).then((ok) => showToast(ok ? "৩ সেকেন্ড পরে শব্দ আসবে…" : "আগে নোটিফিকেশনের অনুমতি দিন"))} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="‘পরে মনে করান’ কতক্ষণ পর?">
            <SelectField value={r.snoozeMin} onChange={(snoozeMin) => set({ snoozeMin })} options={SNOOZE_OPTIONS} />
          </Field>
          <Field label="আগাম সতর্কতা">
            <SelectField value={r.earlyMin} onChange={(earlyMin) => set({ earlyMin })} options={EARLY_OPTIONS} />
          </Field>
        </div>
        <Field label="নোট (ঐচ্ছিক)">
          <input className={inputClass} value={r.note} onChange={(e) => set({ note: e.target.value })} placeholder="নোটিফিকেশনে দেখাবে" />
        </Field>
      </div>

      <div className="safe-bottom fixed inset-x-0 bottom-0 z-30 border-t border-[var(--color-accent)]/20 bg-[var(--color-paper)]/95 px-4 py-3 backdrop-blur dark:bg-[var(--color-paper-dark)]/95">
        <div className="mx-auto max-w-xl">
          <Button block className="py-3.5" onClick={save}>
            💾 সংরক্ষণ করুন
          </Button>
        </div>
      </div>

      <Modal open={catOpen} onClose={() => setCatOpen(false)} title="নতুন ক্যাটাগরি">
        <div className="space-y-3">
          <Field label="নাম">
            <input className={inputClass} value={catName} onChange={(e) => setCatName(e.target.value.slice(0, 30))} placeholder="যেমন: ব্যবসা" />
          </Field>
          <IconPicker value={catIcon} onChange={setCatIcon} />
          <Button block onClick={addCategory}>
            যোগ করুন
          </Button>
        </div>
      </Modal>
    </main>
  );
}
