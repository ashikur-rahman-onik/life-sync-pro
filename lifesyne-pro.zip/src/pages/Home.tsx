import { Link, useNavigate } from "react-router-dom";
import DoseRow from "@/components/DoseRow";
import EntryCard from "@/components/EntryCard";
import UpdateBanner from "@/components/UpdateBanner";
import WaterRing from "@/components/WaterRing";
import { useTodayDoses } from "@/components/useDoses";
import { Card } from "@/components/ui";
import { diaryStats, sortEntries } from "@/domain/diary";
import { logMap, stockInfo } from "@/domain/medicine";
import { effectiveWaterGoal } from "@/domain/reminders";
import { waterTotalForDate } from "@/domain/water";
import { formatDateBn, formatMl, toBn } from "@/lib/bn";
import { showToast } from "@/lib/toast";
import { addWater, markDose, undoDose } from "@/store/actions";
import { useAppData } from "@/store/store";

function greeting(hour: number): string {
  if (hour < 12) return "শুভ সকাল";
  if (hour < 17) return "শুভ অপরাহ্ন";
  if (hour < 20) return "শুভ সন্ধ্যা";
  return "শুভ রাত্রি";
}

export default function HomePage() {
  const data = useAppData();
  const navigate = useNavigate();
  const { today, items } = useTodayDoses();
  const { settings } = data;

  const stats = diaryStats(data.entries, today);
  const recent = sortEntries(data.entries).slice(0, 3);
  const goal = effectiveWaterGoal(settings);
  const drunk = waterTotalForDate(data.waterLogs, today);
  const container = data.containers.find((c) => c.id === settings.water.defaultContainerId) ?? data.containers[0];

  const pending = items.filter((i) => i.status !== "taken" && i.status !== "skipped");
  const focus = pending.filter((i) => i.status === "due" || i.status === "missed").concat(pending.filter((i) => i.status === "upcoming")).slice(0, 3);
  const takenCount = items.filter((i) => i.status === "taken").length;

  const logs = logMap(data.doseLogs);
  const warnings = data.medicines.map((m) => ({ m, info: stockInfo(m, today, logs) })).filter((x) => x.info.warning);

  const quickDrink = () => {
    if (!container) return;
    addWater(container.ml, container.name);
    showToast(`💧 ${formatMl(container.ml)} পানি যোগ হয়েছে`);
  };

  return (
    <main className="safe-top px-4 pt-6">
      <header className="mb-5 flex items-start justify-between">
        <div>
          <p className="text-sm opacity-60">
            {greeting(new Date().getHours())}
            {settings.profile.name ? `, ${settings.profile.name}` : ""}
          </p>
          <h1 className="mt-0.5 text-2xl font-bold">আজ কেমন কাটছে? 📝</h1>
          <p className="mt-0.5 text-xs opacity-50">{formatDateBn(today, { weekday: true })}</p>
        </div>
        <Link to="/settings" aria-label="সেটিংস" className="rounded-full bg-white/70 p-2.5 text-lg shadow-sm active:scale-90 dark:bg-white/10">
          ⚙️
        </Link>
      </header>

      <UpdateBanner />

      <Card className="mb-4">
        <div className="flex items-center gap-4">
          <Link to="/water" aria-label="পানির হিসাব">
            <WaterRing valueMl={drunk} goalMl={goal} size={116} />
          </Link>
          <div className="min-w-0 flex-1">
            <h2 className="font-bold">💧 আজকের পানি</h2>
            {goal === null ? (
              <p className="mt-1 text-xs opacity-60">বয়স ও ওজন দিলে প্রতিদিন কত পানি লাগবে হিসাব করে দেব।</p>
            ) : drunk >= goal ? (
              <p className="mt-1 text-xs font-medium text-green-600">🎉 আজকের লক্ষ্য পূরণ হয়েছে!</p>
            ) : (
              <p className="mt-1 text-xs opacity-60">আরও {formatMl(goal - drunk)} বাকি</p>
            )}
            <div className="mt-3 flex gap-2">
              {goal !== null && container && (
                <button type="button" onClick={quickDrink} className="rounded-full bg-[var(--color-water)] px-3 py-1.5 text-xs font-semibold text-white active:scale-95">
                  + {container.name} ({formatMl(container.ml)})
                </button>
              )}
              {goal === null && (
                <Link to="/water" className="rounded-full bg-[var(--color-water)] px-3 py-1.5 text-xs font-semibold text-white">
                  লক্ষ্য ঠিক করুন
                </Link>
              )}
            </div>
          </div>
        </div>
      </Card>

      <Card className="mb-4">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-bold">💊 আজকের ওষুধ</h2>
          {items.length > 0 && (
            <span className="text-xs opacity-60">
              {toBn(takenCount)}/{toBn(items.length)} খাওয়া হয়েছে
            </span>
          )}
        </div>
        {items.length === 0 ? (
          <p className="text-xs opacity-60">
            আজকের জন্য কোনো ওষুধ নেই।{" "}
            <Link to="/medicine" className="font-semibold text-[var(--color-accent)]">
              ওষুধ যোগ করুন
            </Link>
          </p>
        ) : focus.length === 0 ? (
          <p className="text-sm font-medium text-green-600">✅ আজকের সব ওষুধ শেষ!</p>
        ) : (
          <div className="space-y-2">
            {focus.map(({ dose, status }) => (
              <DoseRow
                key={dose.key}
                dose={dose}
                status={status}
                onTake={() => markDose(dose.medicine, dose.slot, dose.date, "taken")}
                onSkip={() => markDose(dose.medicine, dose.slot, dose.date, "skipped")}
                onUndo={() => undoDose(dose.key)}
              />
            ))}
            <button type="button" onClick={() => navigate("/medicine")} className="w-full pt-1 text-center text-xs font-semibold text-[var(--color-accent)]">
              সব দেখুন →
            </button>
          </div>
        )}
        {warnings.map(({ m, info }) => (
          <p key={m.id} className="mt-3 rounded-xl bg-amber-500/15 px-3 py-2 text-xs text-amber-700 dark:text-amber-400">
            ⚠️ {m.name}: {info.warning === "short" ? `কোর্স শেষ করতে আরও ${toBn(Math.ceil(info.missing))} লাগবে` : `আর প্রায় ${toBn(info.daysLeft ?? 0)} দিনের ওষুধ আছে`} — কিনে নিন
          </p>
        ))}
      </Card>

      <div className="mb-3 grid grid-cols-3 gap-2.5">
        {[
          { icon: "📚", label: "মোট লেখা", value: toBn(stats.total) },
          { icon: "🔥", label: "ধারাবাহিকতা", value: `${toBn(stats.streak)} দিন` },
          { icon: "🗓️", label: "এই মাসে", value: toBn(stats.entriesThisMonth) },
        ].map((s) => (
          <div key={s.label} className="rounded-2xl border border-[var(--color-accent)]/15 bg-white/70 p-3 text-center dark:bg-white/5">
            <div className="text-lg">{s.icon}</div>
            <div className="mt-0.5 text-sm font-bold">{s.value}</div>
            <div className="text-[10px] opacity-60">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="mb-2 flex items-center justify-between">
        <h2 className="font-bold">📔 সাম্প্রতিক লেখা</h2>
        <Link to="/diary" className="text-xs font-semibold text-[var(--color-accent)]">
          সব দেখুন
        </Link>
      </div>
      {recent.length === 0 ? (
        <p className="py-6 text-center text-sm opacity-60">এখনও কোনো এন্ট্রি নেই — নিচের ✍️ বাটনে চেপে আজকের প্রথম এন্ট্রি লিখুন</p>
      ) : (
        <div className="space-y-3">
          {recent.map((e) => (
            <EntryCard key={e.id} entry={e} />
          ))}
        </div>
      )}
    </main>
  );
}
