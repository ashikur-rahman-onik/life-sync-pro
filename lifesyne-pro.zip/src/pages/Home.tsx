import { useMemo } from "react";
import { Link } from "react-router-dom";
import AgendaRow from "@/components/AgendaRow";
import { drinkWater } from "@/components/QuickAddSheet";
import EntryCard from "@/components/EntryCard";
import ProgressRing from "@/components/ProgressRing";
import UpdateBanner from "@/components/UpdateBanner";
import WaterRing from "@/components/WaterRing";
import { Card } from "@/components/ui";
import { diaryStats, sortEntries } from "@/domain/diary";
import { quoteOfTheDay } from "@/domain/quotes";
import { logMap, stockInfo } from "@/domain/medicine";
import { effectiveWaterGoal } from "@/domain/reminders";
import { buildAgenda, dayScore, isFinished } from "@/domain/today";
import { waterTotalForDate } from "@/domain/water";
import { formatDateBn, formatMl, toBn } from "@/lib/bn";
import { dateKey, nowMinutes } from "@/lib/date";
import { useDiaryOpen } from "@/lib/diaryLock";
import { useNow } from "@/lib/useNow";
import { useAppData } from "@/store/store";

function greeting(hour: number): string {
  if (hour < 12) return "শুভ সকাল";
  if (hour < 17) return "শুভ অপরাহ্ন";
  if (hour < 20) return "শুভ সন্ধ্যা";
  return "শুভ রাত্রি";
}

const ORDER = { due: 0, missed: 1, upcoming: 2, open: 3, taken: 4, done: 4, skipped: 4 } as const;

export default function HomePage() {
  const data = useAppData();
  const now = useNow();
  const today = dateKey(now);
  const { settings } = data;

  const agenda = useMemo(() => buildAgenda(data, today, nowMinutes(now)), [data, today, now]);
  const pending = agenda.filter((i) => !isFinished(i)).sort((a, b) => ORDER[a.status] - ORDER[b.status]);
  const finishedCount = agenda.length - pending.length;
  const score = useMemo(() => dayScore(data, today), [data, today]);

  const stats = diaryStats(data.entries, today);
  const recent = sortEntries(data.entries).slice(0, 3);
  // the private diary never previews its pages while it is locked
  const diaryOpen = useDiaryOpen();
  const showPages = !settings.diary.lock || diaryOpen;
  const goal = effectiveWaterGoal(settings);
  const drunk = waterTotalForDate(data.waterLogs, today);
  const container = data.containers.find((c) => c.id === settings.water.defaultContainerId) ?? data.containers[0];

  const logs = logMap(data.doseLogs);
  const warnings = data.medicines.map((m) => ({ m, info: stockInfo(m, today, logs) })).filter((x) => x.info.warning);

  return (
    <main className="safe-top px-4 pt-6">
      <header className="mb-5 flex items-start justify-between">
        <div>
          <p className="text-sm opacity-60">
            {greeting(now.getHours())}
            {settings.profile.name ? `, ${settings.profile.name}` : ""}
          </p>
          <h1 className="mt-0.5 text-2xl font-bold">
            LifeSyne <span className="text-[#16c060]">Pro</span>
          </h1>
          <p className="mt-0.5 text-xs opacity-50">{formatDateBn(today, { weekday: true })}</p>
        </div>
        <Link to="/settings" aria-label="সেটিংস" className="rounded-full bg-white/70 p-2.5 text-lg shadow-sm active:scale-90 dark:bg-white/10">
          ⚙️
        </Link>
      </header>

      <UpdateBanner />

      {score.percent !== null && (
        <Card className="mb-4">
          <div className="flex items-center gap-4">
            <ProgressRing ratio={score.percent / 100} size={96} color={score.percent >= 80 ? "#22c55e" : "var(--color-accent)"}>
              <span className="text-xl font-bold leading-none">{toBn(score.percent)}%</span>
              <span className="text-[10px] opacity-60">আজকের স্কোর</span>
            </ProgressRing>
            <div className="grid min-w-0 flex-1 grid-cols-2 gap-x-3 gap-y-1.5">
              {score.parts.map((p) => (
                <div key={p.label} className="text-xs">
                  <div className="flex justify-between">
                    <span>
                      {p.icon} {p.label}
                    </span>
                    <span className="font-semibold">{toBn(p.percent)}%</span>
                  </div>
                  <div className="mt-0.5 h-1.5 overflow-hidden rounded-full bg-black/5 dark:bg-white/10">
                    <div className="h-full rounded-full bg-[var(--color-accent)]" style={{ width: `${p.percent}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      )}

      <Card className="mb-4">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-bold">📋 আজকের সূচি</h2>
          {agenda.length > 0 && (
            <span className="text-xs opacity-60">
              {toBn(finishedCount)}/{toBn(agenda.length)} সম্পন্ন
            </span>
          )}
        </div>
        {agenda.length === 0 ? (
          <p className="text-xs opacity-60">
            আজ কিছু নির্ধারিত নেই।{" "}
            <Link to="/reminders/new" className="font-semibold text-[var(--color-accent)]">
              রিমাইন্ডার যোগ করুন
            </Link>
          </p>
        ) : pending.length === 0 ? (
          <p className="text-sm font-medium text-green-600">✅ আজকের সব কাজ শেষ!</p>
        ) : (
          <div className="space-y-2">
            {pending.slice(0, 4).map((i) => (
              <AgendaRow key={`${i.kind}:${i.key}`} item={i} />
            ))}
            <Link to="/reminders" className="block w-full pt-1 text-center text-xs font-semibold text-[var(--color-accent)]">
              {pending.length > 4 ? `আরও ${toBn(pending.length - 4)}টি দেখুন →` : "সব দেখুন →"}
            </Link>
          </div>
        )}
        {warnings.map(({ m, info }) => (
          <p key={m.id} className="mt-3 rounded-xl bg-amber-500/15 px-3 py-2 text-xs text-amber-700 dark:text-amber-400">
            ⚠️ {m.name}: {info.warning === "short" ? `কোর্স শেষ করতে আরও ${toBn(Math.ceil(info.missing))} লাগবে` : `আর প্রায় ${toBn(info.daysLeft ?? 0)} দিনের ওষুধ আছে`} — কিনে নিন
          </p>
        ))}
      </Card>

      <Card className="mb-4">
        <div className="flex items-center gap-4">
          <Link to="/water" aria-label="পানির হিসাব">
            <WaterRing valueMl={drunk} goalMl={goal} size={104} />
          </Link>
          <div className="min-w-0 flex-1">
            <h2 className="font-bold">💧 আজকের পানি</h2>
            {goal === null ? (
              <p className="mt-1 text-xs opacity-60">বয়স ও ওজন দিলে প্রতিদিন কত পানি লাগবে হিসাব করে দেব।</p>
            ) : drunk >= goal ? (
              <p className="mt-1 text-xs font-medium text-green-600">🎉 আজকের লক্ষ্য পূরণ হয়েছে!</p>
            ) : (
              <p className="mt-1 text-xs opacity-60">আরও {formatMl(goal - drunk)} বাকি</p>
            )}
            <div className="mt-3">
              {goal !== null && container ? (
                <button type="button" onClick={() => drinkWater(container.ml, container.name, drunk, goal)} className="rounded-full bg-[var(--color-water)] px-3 py-1.5 text-xs font-semibold text-white active:scale-95">
                  + {container.name} ({formatMl(container.ml)})
                </button>
              ) : (
                <Link to="/water" className="rounded-full bg-[var(--color-water)] px-3 py-1.5 text-xs font-semibold text-white">
                  লক্ষ্য ঠিক করুন
                </Link>
              )}
            </div>
          </div>
        </div>
      </Card>

      {settings.showQuotes && (
        <div className="mb-4 rounded-2xl bg-[var(--color-accent)]/10 px-4 py-3 text-center text-sm leading-relaxed">
          <span className="mr-1">💬</span>
          {quoteOfTheDay(today)}
        </div>
      )}

      <div className="mb-3 grid grid-cols-3 gap-2.5">
        {[
          { icon: "📚", label: "মোট লেখা", value: toBn(stats.total) },
          { icon: "🔥", label: "ধারাবাহিকতা", value: `${toBn(stats.streak)} দিন` },
          { icon: "🏅", label: "ব্যাজ দেখুন", value: "→", to: "/achievements" },
        ].map((s) => {
          const body = (
            <>
              <div className="text-lg">{s.icon}</div>
              <div className="mt-0.5 text-sm font-bold">{s.value}</div>
              <div className="text-[10px] opacity-60">{s.label}</div>
            </>
          );
          const cls = "rounded-2xl border border-[var(--color-accent)]/15 bg-white/70 p-3 text-center dark:bg-white/5";
          return s.to ? (
            <Link key={s.label} to={s.to} className={`${cls} active:scale-95`}>
              {body}
            </Link>
          ) : (
            <div key={s.label} className={cls}>
              {body}
            </div>
          );
        })}
      </div>

      <div className="mb-2 flex items-center justify-between">
        <h2 className="font-bold">📔 {settings.diary.title}</h2>
        <Link to="/diary" className="text-xs font-semibold text-[var(--color-accent)]">
          খুলুন
        </Link>
      </div>
      {!showPages ? (
        <Link to="/diary" className="flex items-center gap-3 rounded-2xl border border-[var(--color-accent)]/15 bg-white/70 p-4 active:scale-[0.99] dark:bg-white/5">
          <span className="text-3xl">🔒</span>
          <span>
            <span className="block text-sm font-semibold">ব্যক্তিগত ডায়েরি লক করা আছে</span>
            <span className="block text-xs opacity-60">দেখতে ডায়েরির পাসওয়ার্ড লাগবে</span>
          </span>
        </Link>
      ) : recent.length === 0 ? (
        <p className="py-6 text-center text-sm opacity-60">এখনও কোনো পাতা নেই — নিচের ➕ বাটনে চেপে ‘ডায়েরি লিখুন’ বেছে নিন</p>
      ) : (
        <div className="space-y-3">
          {recent.map((e) => (
            <EntryCard key={e.id} entry={e} />
          ))}
        </div>
      )}
    </main>
  );
}
