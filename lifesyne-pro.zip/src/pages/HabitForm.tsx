import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button, Chip, EmptyState, Field, IconPicker, inputClass, Stepper, StylePicker, TimeListField, Toggle, WeekdayPicker } from "@/components/ui";
import { HABIT_COLORS, HABIT_TEMPLATES } from "@/domain/templates";
import type { Habit } from "@/domain/types";
import { toBn } from "@/lib/bn";
import { todayKey } from "@/lib/date";
import { uid } from "@/lib/id";
import { showToast } from "@/lib/toast";
import { sendTestNotification } from "@/native/notifications";
import { saveHabit } from "@/store/actions";
import { useAppData } from "@/store/store";

export default function HabitFormPage() {
  const { id } = useParams<{ id: string }>();
  const data = useAppData();
  const navigate = useNavigate();
  const existing = id ? data.habits.find((h) => h.id === id) : undefined;

  if (id && !existing) {
    return (
      <main className="safe-top px-4 pt-10">
        <EmptyState icon="🔍" title="অভ্যাসটি পাওয়া যায়নি" />
        <Button variant="soft" block onClick={() => navigate("/reminders", { replace: true })}>
          ← ফিরে যান
        </Button>
      </main>
    );
  }
  return <Form key={id ?? "new"} initial={existing} />;
}

function Form({ initial }: { initial?: Habit }) {
  const navigate = useNavigate();
  const { settings } = useAppData();
  const [h, setH] = useState<Habit>(
    () =>
      initial ?? {
        id: uid(),
        name: "",
        icon: "✅",
        color: HABIT_COLORS[0],
        target: 1,
        weekdays: [],
        times: [],
        reminderOn: false,
        style: settings.notify.reminderStyle,
        startDate: todayKey(),
        archived: false,
        createdAt: new Date().toISOString(),
      },
  );
  const set = (patch: Partial<Habit>) => setH((prev) => ({ ...prev, ...patch }));

  const save = () => {
    const name = h.name.trim();
    if (!name) return showToast("অভ্যাসের নাম লিখুন");
    if (h.reminderOn && h.times.length === 0) return showToast("রিমাইন্ডারের জন্য কমপক্ষে একটি সময় দিন");
    saveHabit({ ...h, name });
    showToast(initial ? "✅ অভ্যাস আপডেট হয়েছে" : "✅ নতুন অভ্যাস যোগ হয়েছে");
    navigate("/reminders", { replace: true });
  };

  return (
    <main className="safe-top px-4 pb-28 pt-6">
      <header className="mb-5 flex items-center gap-2">
        <button type="button" onClick={() => (window.history.length > 1 ? navigate(-1) : navigate("/reminders"))} aria-label="ফিরে যান" className="-ml-1 rounded-full px-2 py-1 text-xl opacity-70 active:scale-90">
          ←
        </button>
        <h1 className="text-xl font-bold">{initial ? "অভ্যাস এডিট" : "নতুন অভ্যাস"} 🔁</h1>
      </header>

      <div className="space-y-4">
        {!initial && (
          <div>
            <span className="mb-1.5 block text-xs font-semibold opacity-70">দ্রুত শুরু</span>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {HABIT_TEMPLATES.map((t) => (
                <Chip key={t.name} active={false} onClick={() => set({ name: t.name, icon: t.icon, color: t.color, target: t.target, times: t.times, reminderOn: t.times.length > 0 })}>
                  {t.icon} {t.name}
                </Chip>
              ))}
            </div>
          </div>
        )}
        <Field label="অভ্যাসের নাম">
          <input className={inputClass} value={h.name} onChange={(e) => set({ name: e.target.value })} placeholder="যেমন: রোজ বই পড়া" />
        </Field>
        <div>
          <span className="mb-1.5 block text-xs font-semibold opacity-70">আইকন</span>
          <IconPicker value={h.icon} onChange={(icon) => set({ icon })} />
        </div>
        <div>
          <span className="mb-1.5 block text-xs font-semibold opacity-70">রং</span>
          <div className="flex gap-2">
            {HABIT_COLORS.map((c) => (
              <button key={c} type="button" onClick={() => set({ color: c })} aria-label={`রং ${c}`} className={`h-8 w-8 rounded-full ${h.color === c ? "ring-2 ring-offset-2 ring-[var(--color-ink)] dark:ring-white" : ""}`} style={{ backgroundColor: c }} />
            ))}
          </div>
        </div>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold">দিনে কতবার করলে সম্পূর্ণ?</p>
            <p className="text-[11px] opacity-60">যেমন পানি ৮ বার, ব্যায়াম ১ বার</p>
          </div>
          <Stepper value={h.target} onChange={(target) => set({ target })} min={1} max={50} format={(v) => `${toBn(v)} বার`} />
        </div>
        <div>
          <span className="mb-1.5 block text-xs font-semibold opacity-70">কোন কোন বার? (ফাঁকা থাকলে প্রতিদিন)</span>
          <WeekdayPicker value={h.weekdays} onChange={(weekdays) => set({ weekdays })} />
        </div>

        <div className="space-y-3 rounded-2xl bg-black/[0.03] p-3 dark:bg-white/5">
          <Toggle checked={h.reminderOn} onChange={(reminderOn) => set({ reminderOn, times: reminderOn && h.times.length === 0 ? ["08:00"] : h.times })} label="রিমাইন্ডার চালু" />
          {h.reminderOn && (
            <>
              <TimeListField value={h.times} onChange={(times) => set({ times })} min={1} />
              <StylePicker value={h.style} onChange={(style) => set({ style })} onTest={(s) => void sendTestNotification(s).then((ok) => showToast(ok ? "৩ সেকেন্ড পরে শব্দ আসবে…" : "আগে নোটিফিকেশনের অনুমতি দিন"))} />
            </>
          )}
        </div>
      </div>

      <div className="safe-bottom fixed inset-x-0 bottom-0 z-30 border-t border-[var(--color-accent)]/20 bg-[var(--color-paper)]/95 px-4 py-3 backdrop-blur dark:bg-[var(--color-paper-dark)]/95">
        <div className="mx-auto max-w-xl">
          <Button block className="py-3.5" onClick={save}>
            💾 সংরক্ষণ করুন
          </Button>
        </div>
      </div>
    </main>
  );
}
