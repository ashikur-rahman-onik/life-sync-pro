import { useEffect, useState } from "react";
import {
  EmailAuthProvider,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  reauthenticateWithCredential,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
  type User,
} from "firebase/auth";
import { emptyData } from "@/domain/defaults";
import { removePin } from "@/lib/security";
import { syncReminders } from "@/native/notifications";
import { auth } from "./client";

export type AuthState = { status: "loading" } | { status: "out" } | { status: "in"; user: User };

export function useAuthState(): AuthState {
  const [state, setState] = useState<AuthState>({ status: "loading" });
  useEffect(
    () => onAuthStateChanged(auth, (user) => setState(user ? { status: "in", user } : { status: "out" })),
    [],
  );
  return state;
}

const ERROR_MESSAGES: Record<string, string> = {
  "auth/invalid-email": "ইমেইল ঠিকভাবে লিখুন",
  "auth/missing-password": "পাসওয়ার্ড লিখুন",
  "auth/invalid-credential": "ইমেইল বা পাসওয়ার্ড ভুল",
  "auth/wrong-password": "ইমেইল বা পাসওয়ার্ড ভুল",
  "auth/user-not-found": "এই ইমেইলে কোনো অ্যাকাউন্ট নেই",
  "auth/email-already-in-use": "এই ইমেইলে আগেই অ্যাকাউন্ট খোলা হয়েছে — লগইন করুন",
  "auth/weak-password": "পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের দিন",
  "auth/network-request-failed": "ইন্টারনেট সংযোগ নেই — অনলাইনে এসে আবার চেষ্টা করুন",
  "auth/too-many-requests": "অনেকবার চেষ্টা হয়েছে, কিছুক্ষণ পরে আবার চেষ্টা করুন",
  "auth/operation-not-allowed": "Firebase Console-এ Authentication → Sign-in method থেকে Email/Password চালু করুন",
};

export function authErrorMessage(error: unknown): string {
  const code = typeof error === "object" && error !== null ? (error as { code?: string }).code : undefined;
  return (code && ERROR_MESSAGES[code]) || "কিছু একটা সমস্যা হয়েছে, আবার চেষ্টা করুন";
}

export async function signIn(email: string, password: string): Promise<void> {
  await signInWithEmailAndPassword(auth, email.trim(), password);
}

export async function signUp(email: string, password: string): Promise<void> {
  await createUserWithEmailAndPassword(auth, email.trim(), password);
}

export async function requestPasswordReset(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email.trim());
}

/** Checks the account password again (used to reset a forgotten PIN). */
export async function verifyAccountPassword(password: string): Promise<void> {
  const user = auth.currentUser;
  if (!user?.email) throw new Error("not signed in");
  await reauthenticateWithCredential(user, EmailAuthProvider.credential(user.email, password));
}

/** Logs out and removes this phone's reminders and PIN. Cloud data stays safe in the account. */
export async function signOutUser(): Promise<void> {
  await syncReminders(emptyData(), true).catch(() => 0);
  removePin();
  await signOut(auth);
}
