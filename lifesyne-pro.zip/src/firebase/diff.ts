import type { AppData } from "@/domain/types";

export const COLLECTION_NAMES = ["entries", "waterLogs", "medicines", "prescriptions", "doseLogs", "snoozes", "containers", "reminders", "reminderLogs", "habits", "habitLogs", "vault", "passwords", "ledger"] as const;
export type CollectionName = (typeof COLLECTION_NAMES)[number];

export type IdMap = Map<string, string>;

/** What we believe Firestore currently holds (id → canonical JSON). */
export type Shadow = Record<CollectionName, IdMap> & { settings: string | null };

export interface Op {
  collection: CollectionName | "settings";
  id: string;
  kind: "set" | "delete";
  data?: unknown;
}

export const emptyShadow = (): Shadow => ({
  entries: new Map(),
  waterLogs: new Map(),
  medicines: new Map(),
  prescriptions: new Map(),
  doseLogs: new Map(),
  snoozes: new Map(),
  containers: new Map(),
  reminders: new Map(),
  reminderLogs: new Map(),
  habits: new Map(),
  habitLogs: new Map(),
  vault: new Map(),
  passwords: new Map(),
  ledger: new Map(),
  settings: null,
});

/** JSON with sorted keys, so two equal objects always give the same text. */
export function stable(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stable).join(",")}]`;
  if (value && typeof value === "object") {
    const obj = value as Record<string, unknown>;
    return `{${Object.keys(obj)
      .sort()
      .map((k) => `${JSON.stringify(k)}:${stable(obj[k])}`)
      .join(",")}}`;
  }
  return JSON.stringify(value) ?? "null";
}

export function mapOf(items: { id: string }[]): IdMap {
  return new Map(items.map((i) => [i.id, stable(i)]));
}

export function sameMap(a: IdMap, b: IdMap): boolean {
  if (a.size !== b.size) return false;
  for (const [id, text] of a) if (b.get(id) !== text) return false;
  return true;
}

/** Writes needed to make Firestore match `data`. */
export function diffData(shadow: Shadow, data: AppData): { ops: Op[]; next: Shadow } {
  const ops: Op[] = [];
  const next = emptyShadow();

  for (const name of COLLECTION_NAMES) {
    const items = data[name] as { id: string }[];
    const current = mapOf(items);
    const previous = shadow[name];
    for (const item of items) {
      if (previous.get(item.id) !== current.get(item.id)) ops.push({ collection: name, id: item.id, kind: "set", data: item });
    }
    for (const id of previous.keys()) {
      if (!current.has(id)) ops.push({ collection: name, id, kind: "delete" });
    }
    next[name] = current;
  }

  const settings = stable(data.settings);
  if (settings !== shadow.settings) ops.push({ collection: "settings", id: "settings", kind: "set", data: data.settings });
  next.settings = settings;

  return { ops, next };
}
