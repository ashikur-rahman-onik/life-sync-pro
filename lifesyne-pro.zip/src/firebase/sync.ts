import { collection, doc, onSnapshot, writeBatch, type DocumentData, type FirestoreError, type SnapshotMetadata, type Unsubscribe } from "firebase/firestore";
import { DEFAULT_CONTAINERS, defaultSettings } from "@/domain/defaults";
import type { AppData } from "@/domain/types";
import {
  normalizeContainer,
  normalizeDoseLog,
  normalizeEntry,
  normalizeHabit,
  normalizeHabitLog,
  normalizeMedicine,
  normalizePrescription,
  normalizeReminder,
  normalizeReminderLog,
  normalizeSettings,
  normalizeSnooze,
  normalizeWaterLog,
} from "@/store/normalize";
import { applyRemote, getState, setLocalChangeHandler } from "@/store/store";
import { db } from "./client";
import { COLLECTION_NAMES, diffData, emptyShadow, mapOf, sameMap, stable, type CollectionName, type Op } from "./diff";
import { INITIAL_STATUS, setSyncStatus, type SyncStatus } from "./status";

type Normalizer = (raw: unknown) => { id: string } | null;

const NORMALIZERS: Record<CollectionName, Normalizer> = {
  entries: normalizeEntry,
  waterLogs: normalizeWaterLog,
  medicines: normalizeMedicine,
  prescriptions: normalizePrescription,
  doseLogs: normalizeDoseLog,
  snoozes: normalizeSnooze,
  containers: normalizeContainer,
  reminders: normalizeReminder,
  reminderLogs: normalizeReminderLog,
  habits: normalizeHabit,
  habitLogs: normalizeHabitLog,
};

/** Firestore returns documents ordered by id; restore a sensible order for the UI. */
const SORTERS: Partial<Record<CollectionName, (a: never, b: never) => number>> = {
  medicines: ((a: { createdAt: string }, b: { createdAt: string }) => a.createdAt.localeCompare(b.createdAt)) as (a: never, b: never) => number,
  containers: ((a: { ml: number; name: string }, b: { ml: number; name: string }) => a.ml - b.ml || a.name.localeCompare(b.name)) as (a: never, b: never) => number,
  reminders: ((a: { createdAt: string }, b: { createdAt: string }) => a.createdAt.localeCompare(b.createdAt)) as (a: never, b: never) => number,
  habits: ((a: { createdAt: string }, b: { createdAt: string }) => a.createdAt.localeCompare(b.createdAt)) as (a: never, b: never) => number,
  waterLogs: ((a: { at: string }, b: { at: string }) => a.at.localeCompare(b.at)) as (a: never, b: never) => number,
};

const BATCH_LIMIT = 400;
const READY_TIMEOUT_MS = 8000;
const SETTINGS_SOURCE = "settings";

/**
 * Connects the in-memory store to Firestore for one signed-in user:
 *   users/{uid}/{entries|waterLogs|medicines|prescriptions|doseLogs|snoozes|containers}/{id}
 *   users/{uid}/meta/settings
 * Returns a function that stops everything (used on logout).
 */
export function startSync(uid: string): () => void {
  const shadow = emptyShadow();
  const meta = new Map<string, SnapshotMetadata>();
  const firstSnapshot = new Set<string>();
  const totalSources = COLLECTION_NAMES.length + 1;
  let stopped = false;
  let error: SyncStatus["error"] = null;
  let ready = false;

  const publish = () => {
    const all = [...meta.values()];
    setSyncStatus({
      ready,
      error,
      pending: all.some((m) => m.hasPendingWrites),
      fromCache: all.some((m) => m.fromCache),
    });
  };

  const markFirst = (source: string) => {
    firstSnapshot.add(source);
    if (!ready && firstSnapshot.size >= totalSources) {
      ready = true;
      publish();
    }
  };

  const fail = (e: FirestoreError | { code?: string }) => {
    error = e.code === "permission-denied" ? "permission" : "other";
    ready = true; // let the app open from whatever is on the phone
    publish();
  };

  const colRef = (name: CollectionName) => collection(db, "users", uid, name);
  const settingsRef = doc(db, "users", uid, "meta", "settings");

  /* ---- local changes -> Firestore ---- */
  const flush = () => {
    if (stopped) return;
    const { ops, next } = diffData(shadow, getState());
    Object.assign(shadow, next);
    for (let i = 0; i < ops.length; i += BATCH_LIMIT) commit(ops.slice(i, i + BATCH_LIMIT));
  };

  const commit = (ops: Op[]) => {
    const batch = writeBatch(db);
    for (const op of ops) {
      const ref = op.collection === "settings" ? settingsRef : doc(colRef(op.collection), encodeURIComponent(op.id));
      if (op.kind === "set") batch.set(ref, op.data as DocumentData);
      else batch.delete(ref);
    }
    // Offline this promise stays pending until the server confirms — never await it in the UI.
    batch.commit().catch((e: FirestoreError) => fail(e));
  };

  setLocalChangeHandler(() => queueMicrotask(flush));

  /* ---- Firestore -> memory ---- */
  const unsubscribers: Unsubscribe[] = COLLECTION_NAMES.map((name) =>
    onSnapshot(
      colRef(name),
      { includeMetadataChanges: true },
      (snap) => {
        if (stopped) return;
        const normalize = NORMALIZERS[name];
        const seen = new Set<string>();
        let items: { id: string }[] = [];
        for (const d of snap.docs) {
          const item = normalize(d.data());
          if (item && !seen.has(item.id)) {
            seen.add(item.id);
            items.push(item);
          }
        }
        const sorter = SORTERS[name];
        if (sorter) items = [...items].sort(sorter as never);

        let seedDefaults = false;
        let shadowItems = items;
        if (name === "containers" && items.length === 0) {
          // Brand-new account: show the default glasses/bottles, and save them once the server confirms it is empty.
          items = DEFAULT_CONTAINERS.map((c) => ({ ...c }));
          shadowItems = snap.metadata.fromCache ? items : [];
          seedDefaults = !snap.metadata.fromCache;
        }

        const current = mapOf(getState()[name] as { id: string }[]);
        if (!sameMap(current, mapOf(items))) applyRemote((s) => ({ ...s, [name]: items }) as AppData);
        shadow[name] = mapOf(shadowItems);
        meta.set(name, snap.metadata);
        publish();
        markFirst(name);
        if (seedDefaults) queueMicrotask(flush);
      },
      fail,
    ),
  );

  unsubscribers.push(
    onSnapshot(
      settingsRef,
      { includeMetadataChanges: true },
      (snap) => {
        if (stopped) return;
        const settings = snap.exists() ? normalizeSettings(snap.data()) : defaultSettings();
        const text = stable(settings);
        if (stable(getState().settings) !== text) applyRemote((s) => ({ ...s, settings }));
        shadow.settings = text;
        meta.set(SETTINGS_SOURCE, snap.metadata);
        publish();
        markFirst(SETTINGS_SOURCE);
      },
      fail,
    ),
  );

  // Never leave the user on a loading screen: open the app from the cache if the server is slow.
  const timer = setTimeout(() => {
    if (!ready) {
      ready = true;
      publish();
    }
  }, READY_TIMEOUT_MS);

  return () => {
    stopped = true;
    clearTimeout(timer);
    unsubscribers.forEach((u) => u());
    setLocalChangeHandler(null);
    setSyncStatus(INITIAL_STATUS);
  };
}
