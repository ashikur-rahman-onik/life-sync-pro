import { useSyncExternalStore } from "react";

export interface SyncStatus {
  /** First data from the cache/server has arrived. */
  ready: boolean;
  /** Some changes are saved on the phone and still waiting to reach the server. */
  pending: boolean;
  /** Not confirmed by the server (usually: no internet). */
  fromCache: boolean;
  /** "permission" = Firestore rules block access; "other" = any other sync problem. */
  error: "permission" | "other" | null;
}

export const INITIAL_STATUS: SyncStatus = { ready: false, pending: false, fromCache: false, error: null };

let status: SyncStatus = INITIAL_STATUS;
const listeners = new Set<() => void>();

export function setSyncStatus(next: SyncStatus): void {
  if (next.ready === status.ready && next.pending === status.pending && next.fromCache === status.fromCache && next.error === status.error) return;
  status = next;
  listeners.forEach((l) => l());
}

export const getSyncStatus = (): SyncStatus => status;

export function useSyncStatus(): SyncStatus {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => {
        listeners.delete(l);
      };
    },
    getSyncStatus,
    getSyncStatus,
  );
}
