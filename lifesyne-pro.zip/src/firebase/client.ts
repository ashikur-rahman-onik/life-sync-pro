import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { initializeFirestore, persistentLocalCache, persistentSingleTabManager } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCubprft2COZatWOOX4_TRTLbY11DiCGiY",
  authDomain: "lifesyne-pro.firebaseapp.com",
  projectId: "lifesyne-pro",
  storageBucket: "lifesyne-pro.firebasestorage.app",
  messagingSenderId: "806423534609",
  appId: "1:806423534609:web:b85c6c0d82712432f0e5b0",
};

export const firebaseApp = initializeApp(firebaseConfig);

/** Stays signed in until the user logs out — also works with no internet. */
export const auth = getAuth(firebaseApp);

/**
 * Firestore with a persistent on-device cache: reads and writes keep working offline,
 * and queued writes are sent automatically when the internet comes back.
 */
export const db = initializeFirestore(firebaseApp, {
  localCache: persistentLocalCache({ tabManager: persistentSingleTabManager(undefined) }),
  experimentalAutoDetectLongPolling: true,
});
