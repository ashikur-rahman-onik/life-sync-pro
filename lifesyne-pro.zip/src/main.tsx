import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import { applyAppearance, applyTheme } from "@/lib/theme";
import App from "./App";

applyTheme();
applyAppearance();

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
